"""
collect_data.py
Interactive webcam tool for building the gesture training dataset.
Run from the project root: python collect_data.py

Hold a label key while making the corresponding gesture; every frame
while the key is held, the current hand's normalized landmark features
are appended to config.DATASET_PATH.

Keys:
  o open_palm   p pinch        f fist         c peace        v victory
  t thumbs_up   e estop        k rock         i index_point  m middle_point
  3 three_fingers  4 four_fingers   x ok_sign
  r other (random/relaxed hand shapes -- teaches the model to say
    "none of the above" instead of forcing every frame into a class)
  q quit
"""

import csv
import os

import cv2
import mediapipe as mp

from perception.feature_utils import landmarks_to_features
import config as C

LABEL_KEYS = {
    ord('o'): "open_palm", ord('p'): "pinch", ord('f'): "fist",
    ord('c'): "peace", ord('v'): "victory", ord('t'): "thumbs_up",
    ord('e'): "estop", ord('k'): "rock", ord('i'): "index_point",
    ord('m'): "middle_point", ord('3'): "three_fingers", ord('4'): "four_fingers",
    ord('x'): "ok_sign", ord('r'): "other",
}

mp_hands = mp.solutions.hands
mp_drawing = mp.solutions.drawing_utils
mp_styles = mp.solutions.drawing_styles


def main():
    os.makedirs(os.path.dirname(C.DATASET_PATH) or ".", exist_ok=True)
    file_exists = os.path.exists(C.DATASET_PATH)
    f = open(C.DATASET_PATH, "a", newline="")
    writer = csv.writer(f)
    if not file_exists:
        writer.writerow([f"f{i}" for i in range(63)] + ["label"])

    cap = cv2.VideoCapture(C.CAMERA_INDEX)
    hands = mp_hands.Hands(
        max_num_hands=1, model_complexity=C.MEDIAPIPE_MODEL_COMPLEXITY,
        min_detection_confidence=C.MEDIAPIPE_MIN_DETECTION_CONF,
        min_tracking_confidence=C.MEDIAPIPE_MIN_TRACKING_CONF,
    )

    counts = {name: 0 for name in LABEL_KEYS.values()}
    active_label = None
    print("Hold a key to record that gesture:", {chr(k): v for k, v in LABEL_KEYS.items()})

    while cap.isOpened():
        ok, frame = cap.read()
        if not ok:
            break
        frame = cv2.flip(frame, 1)
        rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        result = hands.process(rgb)

        key = cv2.waitKey(1) & 0xFF
        if key == ord('q'):
            break
        active_label = LABEL_KEYS.get(key, None)

        if active_label and result.multi_hand_landmarks:
            landmarks = result.multi_hand_landmarks[0].landmark
            feats = landmarks_to_features(landmarks)
            writer.writerow(list(feats) + [active_label])
            counts[active_label] += 1
            mp_drawing.draw_landmarks(
                frame, result.multi_hand_landmarks[0], mp_hands.HAND_CONNECTIONS,
                mp_styles.get_default_hand_landmarks_style(),
                mp_styles.get_default_hand_connections_style(),
            )

        y = 30
        cv2.putText(frame, f"recording: {active_label or '-'}", (10, y),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 0, 255) if active_label else (200, 200, 200), 2)
        for name, n in counts.items():
            y += 20
            cv2.putText(frame, f"{name}: {n}", (10, y), cv2.FONT_HERSHEY_SIMPLEX, 0.45, (0, 255, 0), 1)

        cv2.imshow("Data Collection (hold key to record, q=quit)", frame)

    f.close()
    cap.release()
    cv2.destroyAllWindows()
    print("Saved to", C.DATASET_PATH, "-- counts:", counts)


if __name__ == "__main__":
    main()
