"""
webots/controllers/webots_controller/webots_controller.py
Runs INSIDE Webots as the robot's controller.

Webots only puts this file's own directory on sys.path, but the project
modules (config, robotics.*, communication.*) live at the project root --
so we add the project root to sys.path before importing anything else.
Adjust _PROJECT_ROOT_LEVELS_UP if you move this file to a different
depth inside your Webots project.

Startup safety: the robot begins with mode=IDLE and motion disabled
(handled naturally -- MotionPlanner never advances joints on an IDLE/
non-motion-enabling mode message, see the mode check below). It also
never moves without having received at least one valid, connected,
non-timed-out UDP message.

Every commanded pose passes through SafetyManager + MotionPlanner exactly
as it does in the previously-verified standalone version -- workspace
clamp, IK, joint limits, collision check, velocity/acceleration limiting.
A UDP timeout, emergency-stop flag, or IDLE/PAUSED mode all freeze the
arm at its last known-safe position rather than continuing to act on
stale data.
"""

import os
import sys

_PROJECT_ROOT_LEVELS_UP = 3  # webots/controllers/webots_controller/ -> project root
_this_dir = os.path.dirname(os.path.abspath(__file__))
_project_root = _this_dir
for _ in range(_PROJECT_ROOT_LEVELS_UP):
    _project_root = os.path.dirname(_project_root)
if _project_root not in sys.path:
    sys.path.insert(0, _project_root)

from controller import Robot  # Webots API -- only importable inside Webots

import config as C
from robotics.safety_manager import SafetyManager
from robotics.motion_planner import MotionPlanner
from communication.udp_controller import UDPReceiver

TIME_STEP = C.TIME_STEP_MS


def main():
    robot = Robot()

    motors = [robot.getDevice(name) for name in C.MOTOR_NAMES]
    grippers = [robot.getDevice(name) for name in C.GRIPPER_MOTOR_NAMES]
    roll_motor = None
    if C.WRIST_ROLL_MOTOR_NAME:
        try:
            roll_motor = robot.getDevice(C.WRIST_ROLL_MOTOR_NAME)
        except Exception:
            roll_motor = None

    for m in motors:
        m.setVelocity(2.0)

    safety = SafetyManager()
    planner = MotionPlanner(safety)
    receiver = UDPReceiver()

    current_command = None  # last valid message received
    print("[webots_controller] Ready. Waiting for UDP commands on "
          f"{C.UDP_HOST}:{C.UDP_PORT}. Robot will not move until a "
          "connected, motion-enabling command arrives.")

    while robot.step(TIME_STEP) != -1:
        msg = receiver.poll_latest()
        if msg is not None:
            current_command = msg

        connected = receiver.is_connected()

        if not connected:
            # Comms lost: freeze in place, don't guess.
            gripper_target = C.GRIPPER_OPEN_POS
            for g in grippers:
                g.setPosition(gripper_target)
            continue

        if current_command is None:
            continue  # connected but nothing received yet -- stay put

        mode = current_command.get("mode", "IDLE")
        estop_flag = current_command.get("emergency_stop", False)

        if estop_flag and not safety.is_estopped():
            safety.trigger_estop()

        motion_enabled = mode in ("TRACKING", "PRECISION", "PLAYBACK") and not estop_flag

        if motion_enabled:
            x, y, z = current_command.get("position", [0.2, 0.2, 0.2])
            orientation = current_command.get("orientation", [0.0, 0.0, 0.0])
            wrist_pitch = orientation[1] if len(orientation) > 1 else 0.0
            wrist_roll = orientation[0] if len(orientation) > 0 else 0.0

            speed_scale = C.PRECISION_SPEED_SCALE if mode == "PRECISION" else 1.0
            result = planner.plan((x, y, z), wrist_pitch_offset=wrist_pitch,
                                   dt=TIME_STEP / 1000.0, speed_scale=speed_scale)

            for motor, angle in zip(motors, result.angles):
                motor.setPosition(angle)
            if roll_motor is not None:
                roll_motor.setPosition(wrist_roll)

            gripper_val = current_command.get("gripper", 0.0)
            # gripper_val: 0.0 (open) .. 1.0 (closed) -> motor position range
            gripper_pos = C.GRIPPER_OPEN_POS + gripper_val * (C.GRIPPER_CLOSED_POS - C.GRIPPER_OPEN_POS)
            for g in grippers:
                g.setPosition(gripper_pos)
        else:
            # IDLE/PAUSED/CALIBRATION/e-stop: hold last commanded position,
            # don't advance the planner, and keep the gripper safe/open.
            for g in grippers:
                g.setPosition(C.GRIPPER_OPEN_POS)


if __name__ == "__main__":
    main()
