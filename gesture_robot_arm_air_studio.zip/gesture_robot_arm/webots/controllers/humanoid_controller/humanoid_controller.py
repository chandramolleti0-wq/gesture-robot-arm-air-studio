"""
webots/controllers/humanoid_controller/humanoid_controller.py
Runs INSIDE Webots as the humanoid's controller. Same sys.path pattern as
the arm project's webots_controller.py (Webots only puts this file's own
directory on sys.path; project modules live at the project root).

Not executable/verifiable outside a real Webots process -- same honesty
caveat as the arm project's controller: the logic it calls
(JointController, SafetyController, HumanoidUDPReceiver) is independently
unit-tested, but this file's actual behavior driving real Webots motors
has not been run.

Startup safety: begins with all active joints at 0 (neutral_pose), and
GESTURE/MIRROR/MANUAL commands are only applied once a connected,
non-estopped command has been received -- an IDLE-equivalent hold, same
principle as the arm controller.
"""

import os
import sys

_PROJECT_ROOT_LEVELS_UP = 3
_this_dir = os.path.dirname(os.path.abspath(__file__))
_project_root = _this_dir
for _ in range(_PROJECT_ROOT_LEVELS_UP):
    _project_root = os.path.dirname(_project_root)
if _project_root not in sys.path:
    sys.path.insert(0, _project_root)

from controller import Robot  # Webots API -- only importable inside Webots

import config as C
from robotics.humanoid_controller import neutral_pose
from robotics.joint_controller import JointController
from robotics.safety_controller import SafetyController, SAFE
from communication.udp_sender import HumanoidUDPReceiver

TIME_STEP = C.TIME_STEP_MS


def main():
    robot = Robot()

    motors = {}
    for joint_name in C.ACTIVE_HUMANOID_JOINTS + ["left_hand", "right_hand"]:
        device_name = C.HUMANOID_JOINTS.get(joint_name)
        if device_name is None:
            continue
        try:
            motors[joint_name] = robot.getDevice(device_name)
            motors[joint_name].setVelocity(2.0)
        except Exception:
            print(f"[humanoid_controller] WARNING: motor device '{device_name}' "
                  f"for joint '{joint_name}' not found on this robot -- skipping. "
                  f"Check config.HUMANOID_JOINTS against your Webots model's actual device names.")

    joint_ctrl = JointController(C.ACTIVE_HUMANOID_JOINTS)
    safety = SafetyController()
    receiver = HumanoidUDPReceiver()

    current_command = None
    print(f"[humanoid_controller] Ready. Waiting for commands on "
          f"{C.UDP_HOST}:{C.UDP_PORT}. Robot holds neutral pose until a "
          f"connected, non-estopped command arrives.")

    while robot.step(TIME_STEP) != -1:
        msg = receiver.poll_latest()
        if msg is not None:
            current_command = msg
            safety.frame_received()  # a command arriving counts as "still connected"

        if not receiver.is_connected() or current_command is None:
            continue  # comms lost or nothing yet -- hold last commanded pose, don't guess

        if current_command.emergency_stop and not safety.is_estopped():
            safety.trigger_estop()

        target_joints = current_command.to_joint_dict()
        status, safe_joints = safety.evaluate(target_joints, confidence=current_command.confidence)

        if status == SAFE:
            limited = joint_ctrl.limit_acceleration(safe_joints, dt=TIME_STEP / 1000.0)
            for name, angle in limited.items():
                if name in motors:
                    motors[name].setPosition(angle)

            left_hand_pos = current_command.left_hand   # 0..1, motor range assumed to match
            right_hand_pos = current_command.right_hand
            if "left_hand" in motors:
                motors["left_hand"].setPosition(left_hand_pos)
            if "right_hand" in motors:
                motors["right_hand"].setPosition(right_hand_pos)
        # else: SAFE check failed (estop/tracking lost/low confidence) --
        # motors simply aren't commanded this step, holding their last position.


if __name__ == "__main__":
    main()
