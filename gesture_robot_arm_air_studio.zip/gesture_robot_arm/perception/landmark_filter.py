"""
perception/landmark_filter.py
Implements the shared pipeline:

    raw landmark/angle -> dead-zone -> exponential/One-Euro smoothing -> filtered value

used by both hand-based gesture mapping (control/gesture_mapper.py,
already existed) and the new humanoid arm-angle mapping
(control/motion_mapper.py). Consolidating it here means both paths use
identically-behaved smoothing rather than two subtly different
implementations drifting apart.
"""

import time

from perception.one_euro_filter import OneEuroFilter
import config as C


class DeadZoneOneEuroFilter:
    """
    Applies a dead-zone around the *previous filtered output* (not a fixed
    center) before One-Euro smoothing -- appropriate for continuous joint
    angles that can sit anywhere in their range, unlike the hand-position
    mapper's dead-zone which is centered on a fixed workspace midpoint.
    """

    def __init__(self, dead_zone_rad=0.0, min_cutoff=None, beta=None, d_cutoff=None):
        self.dead_zone_rad = dead_zone_rad
        self.min_cutoff = min_cutoff if min_cutoff is not None else C.FILTER_MIN_CUTOFF
        self.beta = beta if beta is not None else C.FILTER_BETA
        self.d_cutoff = d_cutoff if d_cutoff is not None else C.FILTER_D_CUTOFF
        self._filter = None
        self._last_output = None

    def update(self, raw_value, t=None):
        t = t if t is not None else time.time()

        if self._last_output is not None and abs(raw_value - self._last_output) < self.dead_zone_rad:
            raw_value = self._last_output  # inside dead-zone: hold, don't chase jitter

        if self._filter is None:
            self._filter = OneEuroFilter(t, raw_value, self.min_cutoff, self.beta, self.d_cutoff)
            self._last_output = raw_value
            return raw_value

        filtered = self._filter(t, raw_value)
        self._last_output = filtered
        return filtered

    def reset(self):
        self._filter = None
        self._last_output = None


class JointFilterBank:
    """A named collection of DeadZoneOneEuroFilters, one per joint, so
    callers can filter a whole joint-angle dict in one call."""

    def __init__(self, joint_names, dead_zone_rad=0.0):
        self.filters = {name: DeadZoneOneEuroFilter(dead_zone_rad) for name in joint_names}

    def update(self, raw_angles: dict, t=None) -> dict:
        return {name: self.filters[name].update(value, t) for name, value in raw_angles.items() if name in self.filters}

    def reset(self):
        for f in self.filters.values():
            f.reset()
