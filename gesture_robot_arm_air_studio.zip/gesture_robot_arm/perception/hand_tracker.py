"""
perception/hand_tracker.py
The "Camera -> MediaPipe Hand Tracking -> Landmark Preprocessing" stages
of the architecture, combined into one module: threaded webcam capture
feeding MediaPipe Hands, with the raw output reduced to a small, clean
HandObservation per detected hand that the rest of the system consumes.

Threaded capture: cv2.VideoCapture.read() runs on a background thread and
the main loop always gets the latest frame, so MediaPipe inference is
never the thing waiting on camera I/O, and stale frames never queue up.

Orientation: computed from MediaPipe's *world* landmarks (metric 3D hand
shape, independent of screen position) rather than the 2D image
landmarks, which are distorted by perspective and hand position in frame.
"""

import math
import threading
import time
from dataclasses import dataclass, field
from typing import List, Optional

import cv2
import mediapipe as mp

import config as C

mp_hands = mp.solutions.hands
mp_drawing = mp.solutions.drawing_utils
mp_styles = mp.solutions.drawing_styles


# ------------------------------------------------------------- Capture thread
class ThreadedCapture:
    def __init__(self, source=0, width=None, height=None):
        self.cap = cv2.VideoCapture(source)
        if width:
            self.cap.set(cv2.CAP_PROP_FRAME_WIDTH, width)
        if height:
            self.cap.set(cv2.CAP_PROP_FRAME_HEIGHT, height)
        self.lock = threading.Lock()
        self.frame = None
        self.running = False
        self.thread = None
        self.last_error = None

    def start(self):
        self.running = True
        self.thread = threading.Thread(target=self._loop, daemon=True)
        self.thread.start()
        return self

    def _loop(self):
        fail_count = 0
        while self.running:
            ok, frame = self.cap.read()
            if not ok:
                fail_count += 1
                self.last_error = "Camera read failed"
                time.sleep(0.05)
                if fail_count > 100:
                    self.last_error = "Camera not available"
                continue
            fail_count = 0
            with self.lock:
                self.frame = frame

    def read(self):
        with self.lock:
            if self.frame is None:
                return False, None
            return True, self.frame.copy()

    def isOpened(self):
        return self.cap.isOpened()

    def stop(self):
        self.running = False
        if self.thread is not None:
            self.thread.join(timeout=1.0)
        self.cap.release()


# ------------------------------------------------------------ Orientation
def compute_orientation(world_landmarks):
    """Returns (roll, pitch) in radians from MediaPipe world landmarks."""
    def vec3(lm):
        return (lm.x, lm.y, lm.z)

    def sub(a, b):
        return (a[0] - b[0], a[1] - b[1], a[2] - b[2])

    def cross(a, b):
        return (
            a[1] * b[2] - a[2] * b[1],
            a[2] * b[0] - a[0] * b[2],
            a[0] * b[1] - a[1] * b[0],
        )

    def norm(a):
        n = math.sqrt(a[0] ** 2 + a[1] ** 2 + a[2] ** 2)
        return (a[0] / n, a[1] / n, a[2] / n) if n > 1e-9 else (0.0, 0.0, 0.0)

    wrist = vec3(world_landmarks[0])
    index_mcp = vec3(world_landmarks[5])
    middle_mcp = vec3(world_landmarks[9])
    pinky_mcp = vec3(world_landmarks[17])

    v1 = sub(index_mcp, wrist)
    v2 = sub(pinky_mcp, wrist)
    normal = norm(cross(v1, v2))
    forward = norm(sub(middle_mcp, wrist))

    roll = math.atan2(normal[0], -normal[2])
    pitch = math.asin(max(-1.0, min(1.0, -forward[1])))
    return roll, pitch


# --------------------------------------------------------------- Observation
@dataclass
class HandObservation:
    handedness: str                    # "Left" or "Right", as reported by MediaPipe
    landmarks: list                    # 21 normalized image-space landmarks
    world_landmarks: Optional[list]    # 21 metric landmarks, or None if unavailable
    wrist_xy: tuple                    # (x, y) normalized image coords
    hand_span: float                   # index_mcp<->pinky_mcp distance, depth proxy
    pinch_distance: float              # thumb_tip<->index_tip distance
    roll: float = 0.0
    pitch: float = 0.0


class HandTracker:
    """
    Wraps threaded capture + MediaPipe Hands. `read()` returns
    (ok, frame, observations, fps) and never raises on a missing camera
    or a frame with no hands -- callers get an empty observation list
    instead, which is the correct "safe" default for a control system.
    """

    def __init__(self):
        self.capture = ThreadedCapture(
            C.CAMERA_INDEX, C.CAMERA_WIDTH, C.CAMERA_HEIGHT
        ).start()
        self.hands = mp_hands.Hands(
            max_num_hands=C.MAX_NUM_HANDS,
            model_complexity=C.MEDIAPIPE_MODEL_COMPLEXITY,
            min_detection_confidence=C.MEDIAPIPE_MIN_DETECTION_CONF,
            min_tracking_confidence=C.MEDIAPIPE_MIN_TRACKING_CONF,
        )
        self._last_t = time.time()
        self._fps = 0.0

    def read(self):
        ok, frame = self.capture.read()
        if not ok:
            return False, None, [], self._fps, self.capture.last_error

        frame = cv2.flip(frame, 1)
        rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        result = self.hands.process(rgb)

        now = time.time()
        dt = max(now - self._last_t, 1e-6)
        self._fps = 0.9 * self._fps + 0.1 * (1.0 / dt)
        self._last_t = now

        observations = []
        if result.multi_hand_landmarks:
            handedness_list = result.multi_handedness
            world_list = result.multi_hand_world_landmarks
            for i, hlm in enumerate(result.multi_hand_landmarks):
                lm = hlm.landmark
                wrist = lm[mp_hands.HandLandmark.WRIST]
                index_mcp = lm[mp_hands.HandLandmark.INDEX_FINGER_MCP]
                pinky_mcp = lm[mp_hands.HandLandmark.PINKY_MCP]
                thumb_tip = lm[mp_hands.HandLandmark.THUMB_TIP]
                index_tip = lm[mp_hands.HandLandmark.INDEX_FINGER_TIP]

                hand_span = math.dist((index_mcp.x, index_mcp.y), (pinky_mcp.x, pinky_mcp.y))
                pinch_distance = math.dist((thumb_tip.x, thumb_tip.y), (index_tip.x, index_tip.y))

                label = "Right"
                if handedness_list and i < len(handedness_list):
                    label = handedness_list[i].classification[0].label

                roll, pitch = 0.0, 0.0
                world_lm = None
                if world_list and i < len(world_list):
                    world_lm = world_list[i].landmark
                    roll, pitch = compute_orientation(world_lm)

                observations.append(HandObservation(
                    handedness=label,
                    landmarks=lm,
                    world_landmarks=world_lm,
                    wrist_xy=(wrist.x, wrist.y),
                    hand_span=hand_span,
                    pinch_distance=pinch_distance,
                    roll=roll,
                    pitch=pitch,
                ))

                mp_drawing.draw_landmarks(
                    frame, hlm, mp_hands.HAND_CONNECTIONS,
                    mp_styles.get_default_hand_landmarks_style(),
                    mp_styles.get_default_hand_connections_style(),
                )

        return True, frame, observations, self._fps, None

    def close(self):
        self.capture.stop()
