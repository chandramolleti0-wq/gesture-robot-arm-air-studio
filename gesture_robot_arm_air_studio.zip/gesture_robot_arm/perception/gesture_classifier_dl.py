"""
perception/gesture_classifier_dl.py
Trained MLP gesture classifier. The GestureNet model class lives here so
both train_classifier.py and inference share one definition -- if they
ever diverged, a saved model's state_dict would silently fail to load
(or load into the wrong architecture) with no clear error.

classify() returns (label, confidence) -- the same interface as
perception.gesture_classifier.classify() -- with no threshold applied
here: control/command_manager.py decides what confidence is "enough"
per-command (see config.GESTURE_CONFIDENCE_THRESHOLD vs.
DANGEROUS_GESTURE_CONFIDENCE_THRESHOLD), rather than this module
silently collapsing borderline predictions to "unknown" on its own.
"""

import json

try:
    import torch
    import torch.nn as nn
    import torch.nn.functional as F
    TORCH_AVAILABLE = True
except ImportError:
    TORCH_AVAILABLE = False

from perception.feature_utils import landmarks_to_features, FEATURE_DIM
import config as C


if TORCH_AVAILABLE:
    class GestureNet(nn.Module):
        def __init__(self, num_classes):
            super().__init__()
            self.net = nn.Sequential(
                nn.Linear(FEATURE_DIM, 64), nn.ReLU(), nn.Dropout(0.2),
                nn.Linear(64, 32), nn.ReLU(), nn.Dropout(0.2),
                nn.Linear(32, num_classes),
            )

        def forward(self, x):
            return self.net(x)
else:
    GestureNet = None


class GestureClassifierDL:
    """
    Raises FileNotFoundError/RuntimeError at construction if the model or
    labels can't be loaded -- callers (main.py) should catch this and fall
    back to the rule-based classifier rather than crash, per the
    "never let a missing model take the robot down" robustness requirement.
    """

    def __init__(self, model_path=None, labels_path=None):
        if not TORCH_AVAILABLE:
            raise RuntimeError("PyTorch is not installed; deep-learning classifier unavailable")

        model_path = model_path or f"{C.MODELS_DIR}/gesture_model_{C.MODEL_VERSION}.pt"
        labels_path = labels_path or C.LABELS_PATH

        with open(labels_path) as f:
            self.classes = json.load(f)

        self.model = GestureNet(len(self.classes))
        self.model.load_state_dict(torch.load(model_path, map_location="cpu"))
        self.model.eval()

    def classify(self, landmarks):
        feats = landmarks_to_features(landmarks)
        x = torch.tensor(feats, dtype=torch.float32).unsqueeze(0)
        with torch.no_grad():
            probs = F.softmax(self.model(x), dim=1)[0]
        conf, idx = torch.max(probs, dim=0)
        return self.classes[idx.item()], float(conf.item())
