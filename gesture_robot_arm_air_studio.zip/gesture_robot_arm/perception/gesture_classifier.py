"""
perception/gesture_classifier.py
Rule-based classifier for *static* hand shapes (one frame at a time).
Motion gestures (swipe, move, rotate) are NOT classified here -- those
require a history of wrist positions over time and live in
control/command_manager.py's MotionGestureDetector instead.

This module always returns a (label, confidence) pair. Confidence for
the rule-based path is a simple 0/1-ish heuristic (1.0 when the shape
cleanly matches a rule, lower when landmarks sit near a decision
boundary) -- it exists mainly so rule-based and deep-learning paths
share the same downstream interface in command_manager.py.
"""

import math
import mediapipe as mp

mp_hands = mp.solutions.hands
HL = mp_hands.HandLandmark

FINGER_JOINTS = {
    "index": (HL.INDEX_FINGER_TIP, HL.INDEX_FINGER_PIP),
    "middle": (HL.MIDDLE_FINGER_TIP, HL.MIDDLE_FINGER_PIP),
    "ring": (HL.RING_FINGER_TIP, HL.RING_FINGER_PIP),
    "pinky": (HL.PINKY_TIP, HL.PINKY_PIP),
}

# All gesture labels this classifier can produce, for reference/testing.
GESTURE_LABELS = [
    "open_palm", "pinch", "fist", "peace", "victory", "thumbs_up", "estop",
    "rock", "ok_sign", "index_point", "middle_point", "three_fingers",
    "four_fingers", "unknown",
]


def finger_states(landmarks, margin=0.02):
    states = {}
    for name, (tip_i, pip_i) in FINGER_JOINTS.items():
        tip, pip = landmarks[tip_i], landmarks[pip_i]
        states[name] = tip.y < pip.y - margin

    thumb_tip = landmarks[HL.THUMB_TIP]
    thumb_ip = landmarks[HL.THUMB_IP]
    wrist = landmarks[HL.WRIST]
    d_tip = math.dist((thumb_tip.x, thumb_tip.y), (wrist.x, wrist.y))
    d_ip = math.dist((thumb_ip.x, thumb_ip.y), (wrist.x, wrist.y))
    states["thumb"] = d_tip > d_ip
    return states


def pinch_distance(landmarks):
    thumb_tip = landmarks[HL.THUMB_TIP]
    index_tip = landmarks[HL.INDEX_FINGER_TIP]
    return math.dist((thumb_tip.x, thumb_tip.y), (index_tip.x, index_tip.y))


def classify(landmarks, pinch_threshold=0.045, margin=0.02, roll=0.0):
    """
    Returns (label, confidence). `roll` (radians, from world landmarks)
    is used only to disambiguate peace vs. victory and estop vs. rock,
    which are the same finger shape at different wrist rotations.
    """
    states = finger_states(landmarks, margin)
    idx, mid, ring, pinky, thumb = (
        states["index"], states["middle"], states["ring"], states["pinky"], states["thumb"]
    )
    n_extended = sum([idx, mid, ring, pinky])
    pinch_d = pinch_distance(landmarks)
    is_pinching = pinch_d < pinch_threshold

    # OK sign: pinch shape but with the other three fingers extended
    if is_pinching and mid and ring and pinky:
        return "ok_sign", 0.9

    if is_pinching:
        return "pinch", 0.95

    # Index+pinky extended, middle+ring curled: e-stop or "rock" depending on thumb/orientation
    if idx and pinky and not mid and not ring:
        if thumb or abs(roll) > math.pi / 2:
            return "rock", 0.75
        return "estop", 0.95

    if n_extended == 0 and not thumb:
        return "fist", 0.9

    if idx and not mid and not ring and not pinky:
        return "index_point", 0.85

    if mid and not idx and not ring and not pinky:
        return "middle_point", 0.8

    if idx and mid and not ring and not pinky:
        # Same shape as peace/victory -- distinguish by wrist roll (palm vs. back of hand facing camera)
        if abs(roll) > math.pi / 2:
            return "victory", 0.75
        return "peace", 0.85

    if idx and mid and ring and not pinky:
        return "three_fingers", 0.8

    if idx and mid and ring and pinky and not thumb:
        return "four_fingers", 0.8

    if thumb and n_extended == 0:
        return "thumbs_up", 0.9

    if n_extended >= 3 and thumb:
        return "open_palm", 0.9

    return "unknown", 0.4
