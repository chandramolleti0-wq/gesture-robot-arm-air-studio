"""
perception/pose_tracker.py
Optional body-pose tracking (shoulders, elbows, wrists, hips, knees,
ankles) via MediaPipe Pose. Hands remain the PRIMARY control mechanism
(perception/hand_tracker.py); this module supplies the additional
shoulder/elbow/wrist angles that MIRROR mode needs to reproduce full arm
posture, not just hand position.

Deliberately does NOT own a camera thread of its own -- main_humanoid.py
already has one frame source (HandTracker's ThreadedCapture). Running a
second, independent VideoCapture against the same physical webcam is
unreliable on most OSes and wasteful regardless. PoseTracker.process()
takes the frame HandTracker already grabbed.
"""

from dataclasses import dataclass
from typing import Optional

import mediapipe as mp

import config as C

mp_pose = mp.solutions.pose


@dataclass
class PoseObservation:
    landmarks: list   # 33 MediaPipe Pose landmarks, normalized image coords with visibility
    visible: bool      # whether a pose was detected at all this frame


class PoseTracker:
    def __init__(self):
        self.enabled = C.POSE_ENABLED
        self._pose = None
        if self.enabled:
            self._pose = mp_pose.Pose(
                model_complexity=C.POSE_MODEL_COMPLEXITY,
                min_detection_confidence=C.POSE_MIN_DETECTION_CONF,
                min_tracking_confidence=C.POSE_MIN_TRACKING_CONF,
            )

    def process(self, rgb_frame):
        """rgb_frame: an RGB numpy array (same frame HandTracker processed).
        Returns a PoseObservation, or None if pose tracking is disabled."""
        if not self.enabled or self._pose is None:
            return None
        result = self._pose.process(rgb_frame)
        if not result.pose_landmarks:
            return PoseObservation(landmarks=[], visible=False)
        return PoseObservation(landmarks=result.pose_landmarks.landmark, visible=True)

    @staticmethod
    def joint(obs: PoseObservation, name: str):
        """name: one of mp_pose.PoseLandmark's names, e.g. 'LEFT_SHOULDER'."""
        if obs is None or not obs.visible:
            return None
        idx = getattr(mp_pose.PoseLandmark, name)
        return obs.landmarks[idx]

    def close(self):
        if self._pose is not None:
            self._pose.close()
