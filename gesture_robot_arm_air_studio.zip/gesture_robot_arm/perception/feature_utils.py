"""
perception/feature_utils.py
Converts raw MediaPipe hand landmarks into a fixed-length, translation-
and scale-invariant feature vector. Used identically by data collection,
training, and both classifiers so they can never silently drift apart.
"""

import numpy as np

NUM_LANDMARKS = 21
FEATURE_DIM = NUM_LANDMARKS * 3


def landmarks_to_features(landmarks):
    """landmarks: MediaPipe's 21-point landmark list for one hand."""
    pts = np.array([[lm.x, lm.y, lm.z] for lm in landmarks], dtype=np.float32)

    wrist = pts[0].copy()
    pts -= wrist

    scale = np.linalg.norm(pts[9])  # distance to middle-finger MCP
    if scale < 1e-6:
        scale = 1e-6
    pts /= scale

    return pts.flatten()


def augment(features, rng, noise_std=0.02, max_rotation_deg=15.0):
    """Random in-plane rotation + jitter, used only during training."""
    pts = features.reshape(NUM_LANDMARKS, 3).copy()

    angle = np.radians(rng.uniform(-max_rotation_deg, max_rotation_deg))
    c, s = np.cos(angle), np.sin(angle)
    x, y = pts[:, 0].copy(), pts[:, 1].copy()
    pts[:, 0] = c * x - s * y
    pts[:, 1] = s * x + c * y

    pts += rng.normal(0, noise_std, size=pts.shape)
    return pts.flatten()
