"""
communication/ros_controller.py
Optional ROS 2 publishing, alongside (not instead of) the UDP path.

Being direct about scope: this is a thin, honestly-limited wrapper, not a
full ROS 2 integration. rclpy is a large, platform-specific installation
(a full ROS 2 distro) that isn't available in the environment this was
built and tested in, so the "real ROS 2 node actually publishing to a
running ROS 2 graph" path could not be executed or verified here -- only
the "rclpy is absent, degrade gracefully" path was actually tested (see
below). If you have ROS 2 installed, treat the publishing code path as
implemented-but-unverified, the same honesty standard applied to the
Webots controller itself, and tell me what breaks.

Disabled by default (config.ROS2_ENABLED). UDP remains the primary,
always-available transport regardless of this module's state.
"""

try:
    import rclpy
    from rclpy.node import Node
    from std_msgs.msg import String
    ROS2_AVAILABLE = True
except ImportError:
    ROS2_AVAILABLE = False
    Node = object  # placeholder base class so the class body below still parses


class RosHumanoidPublisher(Node if ROS2_AVAILABLE else object):
    def __init__(self, topic="/humanoid/command"):
        self._available = ROS2_AVAILABLE
        self._topic = topic
        self._publisher = None
        self._node_started = False
        if ROS2_AVAILABLE:
            super().__init__("gesture_humanoid_publisher")

    def start(self):
        if not self._available:
            print("[ros2] rclpy not installed -- ROS 2 publishing disabled. "
                  "UDP communication is unaffected. Install a ROS 2 distribution "
                  "and rclpy to enable this.")
            return False
        try:
            rclpy.init()
            self._publisher = self.create_publisher(String, self._topic, 10)
            self._node_started = True
            print(f"[ros2] Publishing humanoid commands on {self._topic}")
            return True
        except Exception as e:
            print(f"[ros2] Failed to initialize ROS 2 node ({e}) -- disabling. "
                  "UDP communication is unaffected.")
            self._available = False
            return False

    def publish(self, command_dict: dict):
        if not self._available or not self._node_started:
            return False
        import json
        msg = String()
        msg.data = json.dumps(command_dict)
        try:
            self._publisher.publish(msg)
            return True
        except Exception:
            return False

    def is_available(self):
        return self._available

    def stop(self):
        if self._node_started:
            try:
                self.destroy_node()
                rclpy.shutdown()
            except Exception:
                pass
