"""
communication/udp_sender.py
Standardized humanoid command structure + UDP transport. Builds directly
on communication/udp_controller.py's already-tested UDPSender/UDPReceiver
socket classes (sequence numbers, out-of-order rejection, timeout
detection all already verified there) -- this module only adds the
humanoid-specific message *schema* on top, matching the exact format from
the spec:

    {
        "timestamp": ..., "mode": "mirror", "gesture": "open_palm",
        "confidence": 0.96,
        "left_arm": {"shoulder":.., "elbow":.., "wrist":..},
        "right_arm": {"shoulder":.., "elbow":.., "wrist":..},
        "emergency_stop": false
    }

A dataclass is used as the internal representation before serialization,
per the spec's "use a robust internal Python dataclass/model" requirement.
"""

import time
from dataclasses import dataclass, field, asdict
from typing import Dict

from communication.udp_controller import UDPSender, UDPReceiver
import config as C


@dataclass
class ArmCommand:
    shoulder: float = 0.0
    elbow: float = 0.0
    wrist: float = 0.0


@dataclass
class HumanoidCommand:
    mode: str = "gesture"
    gesture: str = "none"
    confidence: float = 0.0
    left_arm: ArmCommand = field(default_factory=ArmCommand)
    right_arm: ArmCommand = field(default_factory=ArmCommand)
    left_hand: float = 0.0
    right_hand: float = 0.0
    neck_yaw: float = 0.0
    neck_pitch: float = 0.0
    torso_yaw: float = 0.0
    emergency_stop: bool = False
    timestamp: float = field(default_factory=time.time)
    seq: int = 0   # not in the spec's minimal example, but reuses the
                    # already-tested out-of-order rejection in
                    # communication/udp_controller.UDPReceiver

    def to_dict(self):
        return asdict(self)

    @staticmethod
    def from_dict(d: dict):
        left = ArmCommand(**d.get("left_arm", {}))
        right = ArmCommand(**d.get("right_arm", {}))
        return HumanoidCommand(
            mode=d.get("mode", "gesture"), gesture=d.get("gesture", "none"),
            confidence=d.get("confidence", 0.0), left_arm=left, right_arm=right,
            left_hand=d.get("left_hand", 0.0), right_hand=d.get("right_hand", 0.0),
            neck_yaw=d.get("neck_yaw", 0.0), neck_pitch=d.get("neck_pitch", 0.0),
            torso_yaw=d.get("torso_yaw", 0.0),
            emergency_stop=d.get("emergency_stop", False),
            timestamp=d.get("timestamp", time.time()),
        )

    @staticmethod
    def from_joint_dict(joint_angles: Dict[str, float], mode="gesture", gesture="none",
                         confidence=0.0, left_hand=0.0, right_hand=0.0, emergency_stop=False):
        """Builds a HumanoidCommand from the flat joint_name->angle dicts
        that robotics/joint_controller.py and robotics/safety_controller.py
        work with internally."""
        return HumanoidCommand(
            mode=mode, gesture=gesture, confidence=confidence,
            left_arm=ArmCommand(
                shoulder=joint_angles.get("left_shoulder", 0.0),
                elbow=joint_angles.get("left_elbow", 0.0),
                wrist=joint_angles.get("left_wrist", 0.0),
            ),
            right_arm=ArmCommand(
                shoulder=joint_angles.get("right_shoulder", 0.0),
                elbow=joint_angles.get("right_elbow", 0.0),
                wrist=joint_angles.get("right_wrist", 0.0),
            ),
            left_hand=left_hand, right_hand=right_hand,
            neck_yaw=joint_angles.get("neck_yaw", 0.0),
            neck_pitch=joint_angles.get("neck_pitch", 0.0),
            torso_yaw=joint_angles.get("torso_yaw", 0.0),
            emergency_stop=emergency_stop,
        )

    def to_joint_dict(self):
        return {
            "left_shoulder": self.left_arm.shoulder, "left_elbow": self.left_arm.elbow,
            "left_wrist": self.left_arm.wrist,
            "right_shoulder": self.right_arm.shoulder, "right_elbow": self.right_arm.elbow,
            "right_wrist": self.right_arm.wrist,
            "neck_yaw": self.neck_yaw, "neck_pitch": self.neck_pitch,
            "torso_yaw": self.torso_yaw,
        }


class HumanoidUDPSender:
    def __init__(self, host=None, port=None):
        self._sender = UDPSender(host or C.UDP_HOST, port or C.UDP_PORT)
        self._seq = 0

    def send(self, command: HumanoidCommand):
        self._seq += 1
        command.seq = self._seq
        d = command.to_dict()
        # Reuse the already-tested generic sender by piggybacking on its
        # position/orientation/gripper/mode fields would lose the richer
        # humanoid schema, so we serialize the full dict ourselves via the
        # same underlying socket instead of UDPSender.send()'s fixed shape.
        import json
        payload = json.dumps(d).encode("utf-8")
        try:
            self._sender.sock.sendto(payload, (self._sender.host, self._sender.port))
            return True
        except OSError:
            return False

    def close(self):
        self._sender.close()


class HumanoidUDPReceiver:
    def __init__(self, host=None, port=None, timeout=None):
        self._receiver = UDPReceiver(host or C.UDP_HOST, port or C.UDP_PORT,
                                      timeout or C.HUMANOID_UDP_TIMEOUT_S)

    def poll_latest(self):
        msg = self._receiver.poll_latest()
        if msg is None:
            return None
        return HumanoidCommand.from_dict(msg)

    def is_connected(self):
        return self._receiver.is_connected()

    def close(self):
        self._receiver.close()
