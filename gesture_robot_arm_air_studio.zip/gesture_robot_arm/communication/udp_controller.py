"""
communication/udp_controller.py
Structured UDP messaging between the Python gesture pipeline and the
Webots controller. Each message is a JSON object:

    {
        "seq": 42,
        "timestamp": 1234567890.123,
        "position": [x, y, z],
        "orientation": [roll, pitch, 0.0],
        "gripper": 0.67,
        "mode": "TRACKING",
        "emergency_stop": false
    }

UDPSender runs in the vision process. UDPReceiver runs inside the Webots
controller and additionally tracks message recency for heartbeat/timeout
detection -- if no message (of any kind) arrives within config.UDP_TIMEOUT_S,
is_connected() returns False and the caller (webots controller) must stop
the robot rather than continue acting on stale data.
"""

import json
import socket
import time

import config as C


class UDPSender:
    def __init__(self, host=None, port=None):
        self.host = host or C.UDP_HOST
        self.port = port or C.UDP_PORT
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.sock.setblocking(False)
        self._seq = 0

    def send(self, position, orientation, gripper, mode, emergency_stop=False):
        self._seq += 1
        message = {
            "seq": self._seq,
            "timestamp": time.time(),
            "position": list(position),
            "orientation": list(orientation),
            "gripper": gripper,
            "mode": mode,
            "emergency_stop": bool(emergency_stop),
        }
        payload = json.dumps(message).encode("utf-8")
        try:
            self.sock.sendto(payload, (self.host, self.port))
            return True
        except OSError:
            # Non-blocking UDP send buffer full or similar transient
            # failure -- never let a comms hiccup raise into the caller's
            # main loop; the receiver's timeout logic is what actually
            # keeps the robot safe if sends keep failing.
            return False

    def close(self):
        self.sock.close()


class UDPReceiver:
    def __init__(self, host=None, port=None, timeout=None):
        self.host = host or C.UDP_HOST
        self.port = port or C.UDP_PORT
        self.timeout = timeout if timeout is not None else C.UDP_TIMEOUT_S
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.sock.bind((self.host, self.port))
        self.sock.setblocking(False)
        self._last_received_time = None
        self._last_seq = None
        self._dropped_out_of_order = 0

    def poll_latest(self):
        """
        Drains the socket and returns the most recent valid message
        (dict) received this call, or None if nothing new arrived.
        Also updates heartbeat bookkeeping regardless of whether the
        message parses -- any traffic at all counts as "still connected"
        for timeout purposes, since a single malformed packet shouldn't
        itself be read as "connection lost."
        """
        latest = None
        while True:
            try:
                data, _ = self.sock.recvfrom(4096)
            except (BlockingIOError, OSError):
                break
            self._last_received_time = time.time()
            try:
                msg = json.loads(data.decode("utf-8"))
            except (json.JSONDecodeError, UnicodeDecodeError):
                continue
            if self._last_seq is not None and msg.get("seq", 0) < self._last_seq:
                self._dropped_out_of_order += 1
                continue  # ignore out-of-order/stale packets, keep the newer one already held
            self._last_seq = msg.get("seq")
            latest = msg
        return latest

    def is_connected(self):
        if self._last_received_time is None:
            return False
        return (time.time() - self._last_received_time) <= self.timeout

    def close(self):
        self.sock.close()
