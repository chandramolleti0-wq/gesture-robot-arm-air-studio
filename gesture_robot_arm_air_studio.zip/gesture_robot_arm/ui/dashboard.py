"""
ui/dashboard.py
Optional local web dashboard mirroring the HUD's data. Runs Flask in a
background thread if Flask is installed and config.DASHBOARD_ENABLED is
True; otherwise start() is a no-op that logs once and returns. The core
controller (main.py) never depends on this succeeding -- per the spec,
"do not make the dashboard required for the core controller."
"""

import threading

try:
    from flask import Flask, jsonify, render_template_string
    FLASK_AVAILABLE = True
except ImportError:
    FLASK_AVAILABLE = False

import config as C

_PAGE = """
<!doctype html>
<html><head><title>Gesture Robot Dashboard</title>
<meta http-equiv="refresh" content="1">
<style>
body { font-family: monospace; background:#111; color:#eee; padding:20px; }
h1 { color:#4fc3f7; }
.row { margin: 4px 0; }
.label { color:#888; display:inline-block; width:160px; }
.safe { color:#4caf50; } .unsafe { color:#f44336; }
</style></head>
<body>
<h1>Gesture Robot Control Dashboard</h1>
{% for k, v in state.items() %}
<div class="row"><span class="label">{{ k }}:</span> {{ v }}</div>
{% endfor %}
</body></html>
"""


class DashboardServer:
    def __init__(self, host=None, port=None):
        self.host = host or C.DASHBOARD_HOST
        self.port = port or C.DASHBOARD_PORT
        self._state = {}
        self._lock = threading.Lock()
        self._thread = None
        self._app = None
        self._warned = False

    def update_state(self, snapshot: dict):
        with self._lock:
            self._state = dict(snapshot)

    def start(self):
        if not C.DASHBOARD_ENABLED:
            return False
        if not FLASK_AVAILABLE:
            if not self._warned:
                print("[dashboard] Flask not installed -- dashboard disabled. "
                      "Install with `pip install flask` to enable it. "
                      "The core controller works fine without it.")
                self._warned = True
            return False

        self._app = Flask(__name__)

        @self._app.route("/")
        def index():
            with self._lock:
                return render_template_string(_PAGE, state=self._state)

        @self._app.route("/state")
        def state():
            with self._lock:
                return jsonify(self._state)

        def run():
            self._app.run(host=self.host, port=self.port, debug=False, use_reloader=False)

        self._thread = threading.Thread(target=run, daemon=True)
        self._thread.start()
        print(f"[dashboard] running at http://{self.host}:{self.port}")
        return True
