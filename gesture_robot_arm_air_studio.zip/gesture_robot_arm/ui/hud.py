"""
ui/hud.py
Draws the on-screen HUD onto the camera frame: current gesture/confidence,
mode, hand and robot coordinates, gripper %, IK solver/error, robot speed,
safety status, and FPS. Pure OpenCV drawing -- no state of its own, just
takes a snapshot dict and renders it.
"""

import cv2

GREEN = (0, 255, 0)
RED = (0, 0, 255)
YELLOW = (0, 255, 255)
WHITE = (255, 255, 255)
GRAY = (180, 180, 180)


def _put(frame, text, pos, color=WHITE, scale=0.55, thickness=1):
    cv2.putText(frame, text, pos, cv2.FONT_HERSHEY_SIMPLEX, scale, color, thickness, cv2.LINE_AA)


def draw_confidence_bar(frame, x, y, width, height, confidence, color=GREEN):
    cv2.rectangle(frame, (x, y), (x + width, y + height), GRAY, 1)
    filled = int(width * max(0.0, min(1.0, confidence)))
    if filled > 0:
        cv2.rectangle(frame, (x, y), (x + filled, y + height), color, -1)


def draw_hud(frame, snapshot):
    """
    snapshot: dict with keys (all optional, missing ones are skipped):
      gesture, confidence, mode, hand_pos (x,y,z), robot_pos (x,y,z),
      gripper (0..1), ik_solver, ik_error, robot_speed (0..1),
      safety_status, fps, warnings (list of str)
    """
    h, w = frame.shape[:2]
    x0, y0 = 10, 20
    line_h = 22

    safety = snapshot.get("safety_status", "SAFE")
    safety_color = RED if safety not in ("SAFE",) else GREEN

    lines = [
        ("GESTURE ROBOT CONTROL", WHITE, 0.6),
        ("-" * 28, GRAY, 0.5),
    ]
    if "gesture" in snapshot:
        lines.append((f"Gesture:      {snapshot['gesture']}", WHITE, 0.55))
    if "confidence" in snapshot:
        lines.append((f"Confidence:   {snapshot['confidence']*100:.1f}%", WHITE, 0.55))
    lines.append(("", WHITE, 0.3))
    if "mode" in snapshot:
        mode_color = RED if snapshot["mode"] == "EMERGENCY_STOP" else YELLOW
        lines.append((f"Mode:         {snapshot['mode']}", mode_color, 0.55))
    lines.append(("", WHITE, 0.3))
    if "hand_pos" in snapshot:
        hx, hy, hz = snapshot["hand_pos"]
        lines.append((f"Hand  X/Y/Z:  {hx:.2f} / {hy:.2f} / {hz:.2f}", GRAY, 0.5))
    if "robot_pos" in snapshot:
        rx, ry, rz = snapshot["robot_pos"]
        lines.append((f"Robot X/Y/Z:  {rx:.2f} / {ry:.2f} / {rz:.2f}", WHITE, 0.5))
    if "gripper" in snapshot:
        lines.append((f"Gripper:      {snapshot['gripper']*100:.0f}%", WHITE, 0.55))
    lines.append(("", WHITE, 0.3))
    if "ik_solver" in snapshot:
        lines.append((f"IK Solver:    {snapshot['ik_solver'].upper()}", GRAY, 0.5))
    if "ik_error" in snapshot:
        lines.append((f"IK Error:     {snapshot['ik_error']:.4f}", GRAY, 0.5))
    if "robot_speed" in snapshot:
        lines.append((f"Robot Speed:  {snapshot['robot_speed']*100:.0f}%", GRAY, 0.5))
    lines.append(("", WHITE, 0.3))
    lines.append((f"Safety:       {safety}", safety_color, 0.6))
    if "fps" in snapshot:
        lines.append((f"FPS:          {snapshot['fps']:.0f}", GRAY, 0.5))

    y = y0
    for text, color, scale in lines:
        if text:
            _put(frame, text, (x0, y), color, scale)
        y += line_h

    if "confidence" in snapshot:
        bar_color = GREEN if snapshot["confidence"] >= 0.7 else (YELLOW if snapshot["confidence"] >= 0.4 else RED)
        draw_confidence_bar(frame, x0, y0 + 40, 150, 10, snapshot["confidence"], bar_color)

    for i, warning in enumerate(snapshot.get("warnings", [])[:3]):
        _put(frame, f"WARNING: {warning}", (x0, h - 20 - i * 20), YELLOW, 0.5)

    if snapshot.get("mode") == "EMERGENCY_STOP":
        _put(frame, "EMERGENCY STOP ACTIVE", (w // 2 - 150, 40), RED, 0.9, 2)

    return frame
