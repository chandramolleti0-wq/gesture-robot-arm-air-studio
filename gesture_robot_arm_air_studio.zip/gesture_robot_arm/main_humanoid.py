"""
main_humanoid.py
Entry point for the full-body humanoid extension. Run with:
    python main_humanoid.py

Reuses, unchanged, the already-tested arm-project machinery where it
genuinely applies: perception.hand_tracker.HandTracker (threaded capture +
MediaPipe Hands), perception.gesture_classifier (rule-based classifier),
control.calibration.Calibrator (hand-workspace calibration), and
control.gesture_mapper.GestureMapper (hand position -> reach target, one
instance per arm in GESTURE mode). New humanoid-specific pieces
(pose_tracker, motion_mapper, mirror_controller, humanoid_mode_manager,
joint_controller, safety_controller, udp_sender) are described in
README.md's "what's tested vs. what needs Webots to confirm" section --
the same honesty standard as main.py (arm).

Startup safety: mode starts at GESTURE (config.HUMANOID_MODE_DEFAULT) but
every joint starts at 0 (neutral pose) and stays there until safety
checks (frame received, confidence, non-estopped) pass -- there is no
path where the robot moves before a valid, connected, confident command
exists.
"""

import time

import cv2

import config as C
from perception.hand_tracker import HandTracker
from perception.pose_tracker import PoseTracker
from perception.gesture_classifier import classify as rule_based_classify
from control.calibration import Calibrator
from control.gesture_mapper import GestureMapper
from control.mirror_controller import MirrorController
from control.humanoid_mode_manager import HumanoidModeManager, HumanoidMode
from control.motion_mapper import arm_angles_from_hand_position, hand_openness_to_grip
from robotics.humanoid_controller import neutral_pose
from robotics.joint_controller import JointController
from robotics.safety_controller import SafetyController, SAFE, EMERGENCY_STOP, TRACKING_LOST, LOW_CONFIDENCE
from communication.udp_sender import HumanoidUDPSender, HumanoidCommand
from ui.hud import _put, GREEN, RED, YELLOW, WHITE, GRAY


def split_hands(observations):
    if len(observations) == 0:
        return None, None
    if len(observations) == 1:
        return observations[0], None
    right = next((o for o in observations if o.handedness == "Right"), None)
    left = next((o for o in observations if o.handedness == "Left"), None)
    if right is None:
        right, left = observations[0], observations[1]
    return right, left


def draw_humanoid_hud(frame, snapshot):
    h, w = frame.shape[:2]
    x0, y0, line_h = 10, 20, 20
    lines = [
        ("HUMANOID ROBOT CONTROL", WHITE, 0.6),
        ("-" * 30, GRAY, 0.5),
        (f"Camera:        {'CONNECTED' if snapshot['camera_ok'] else 'LOST'}",
         GREEN if snapshot["camera_ok"] else RED, 0.5),
        (f"Hand Tracking: {'ACTIVE' if snapshot['hand_visible'] else 'NONE'}", GRAY, 0.5),
        (f"Pose Tracking: {'ACTIVE' if snapshot['pose_visible'] else 'NONE'}", GRAY, 0.5),
        (f"Robot:         {'CONNECTED' if snapshot['robot_connected'] else 'NO WEBOTS'}",
         GREEN if snapshot["robot_connected"] else YELLOW, 0.5),
        ("", WHITE, 0.3),
        (f"Gesture:       {snapshot['gesture']}", WHITE, 0.55),
        (f"Confidence:    {snapshot['confidence']*100:.0f}%", WHITE, 0.5),
        ("", WHITE, 0.3),
        (f"Mode:          {snapshot['mode']}", YELLOW if snapshot["mode"] != "EMERGENCY_STOP" else RED, 0.55),
        (f"Safety:        {snapshot['safety_status']}",
         GREEN if snapshot["safety_status"] == "SAFE" else RED, 0.55),
        ("", WHITE, 0.3),
        (f"Left Arm:      {'ACTIVE' if snapshot['left_active'] else 'idle'}", GRAY, 0.5),
        (f"Right Arm:     {'ACTIVE' if snapshot['right_active'] else 'idle'}", GRAY, 0.5),
        ("", WHITE, 0.3),
        (f"FPS:           {snapshot['fps']:.0f}", GRAY, 0.5),
        (f"Latency:       {snapshot['latency_ms']:.0f} ms", GRAY, 0.5),
    ]
    y = y0
    for text, color, scale in lines:
        if text:
            _put(frame, text, (x0, y), color, scale)
        y += line_h

    legend = "[E] Estop  [M] Mirror  [G] Gesture  [R] Reset  [K] Calibrate  [Q] Quit"
    _put(frame, legend, (x0, h - 15), GRAY, 0.45)

    if snapshot["mode"] == "EMERGENCY_STOP":
        _put(frame, "EMERGENCY STOP ACTIVE", (w // 2 - 150, 40), RED, 0.9, 2)


def main():
    print("[main_humanoid] Loading configuration...")
    calibration = Calibrator.load()

    try:
        hand_tracker = HandTracker()
    except Exception as e:
        print(f"[main_humanoid] ERROR: Camera/MediaPipe initialization failed: {e}")
        return
    pose_tracker = PoseTracker()

    sender = HumanoidUDPSender()
    safety = SafetyController()
    joint_ctrl = JointController(C.ACTIVE_HUMANOID_JOINTS)
    mirror_ctrl = MirrorController()
    mode_mgr = HumanoidModeManager()
    calibrator = Calibrator()

    left_arm_mapper = GestureMapper(calibration)
    right_arm_mapper = GestureMapper(calibration)

    full_joints = neutral_pose()
    left_hand, right_hand = 0.0, 0.0
    manual_selected_idx = 0

    print("[main_humanoid] Ready. Mode=GESTURE. Robot holds neutral pose "
          "until tracking is confirmed. Press 'q' to quit, 'k' to calibrate.")

    try:
        while True:
            frame_start = time.time()
            ok, frame, hand_obs, fps, cam_error = hand_tracker.read()

            if not ok:
                blank_status = {
                    "camera_ok": False, "hand_visible": False, "pose_visible": False,
                    "robot_connected": False, "gesture": "none", "confidence": 0.0,
                    "mode": mode_mgr.mode.value, "safety_status": TRACKING_LOST,
                    "left_active": False, "right_active": False, "fps": 0, "latency_ms": 0,
                }
                print(f"[main_humanoid] ERROR: Camera not available ({cam_error})")
                time.sleep(0.1)
                continue

            safety.frame_received()
            rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            pose_obs = pose_tracker.process(rgb) if C.POSE_ENABLED else None

            primary_obs, left_obs = split_hands(hand_obs)
            gesture_label, gesture_conf = "none", 0.0
            if primary_obs is not None:
                gesture_label, gesture_conf = rule_based_classify(
                    primary_obs.landmarks, C.PINCH_THRESHOLD, C.FINGER_CURL_MARGIN, primary_obs.roll)

            # ---- Emergency stop (highest priority, any mode) ----
            if gesture_label == "estop" and gesture_conf >= C.GESTURE_CONFIDENCE_THRESHOLD:
                mode_mgr.transition(HumanoidMode.EMERGENCY_STOP)
                safety.trigger_estop()

            if mode_mgr.mode == HumanoidMode.EMERGENCY_STOP:
                open_palm_now = (gesture_label == "open_palm" and gesture_conf >= C.GESTURE_CONFIDENCE_THRESHOLD)
                safety.update_estop_clear(open_palm_now)
                if not safety.is_estopped():
                    mode_mgr.transition(HumanoidMode.GESTURE)

            # ---- Calibration ----
            # (calibration progress is driven by the 'k' keypress at the
            # end of the loop; calibrator.current_step() is None when idle)

            # ---- Compute target joints per mode ----
            confidence_for_safety = 1.0
            if mode_mgr.mode == HumanoidMode.MIRROR:
                result = mirror_ctrl.update(
                    pose_obs,
                    left_pinch=left_obs.pinch_distance if left_obs else None,
                    right_pinch=primary_obs.pinch_distance if primary_obs else None,
                )
                full_joints.update(result["joint_angles"])
                left_hand, right_hand = result["left_hand"], result["right_hand"]

            elif mode_mgr.mode == HumanoidMode.GESTURE:
                confidence_for_safety = gesture_conf if primary_obs is not None else 1.0
                if primary_obs is not None:
                    rx, ry, rz = right_arm_mapper.map_position(*primary_obs.wrist_xy, primary_obs.hand_span)
                    full_joints.update(arm_angles_from_hand_position(rx, ry, rz, "right"))
                    right_hand = hand_openness_to_grip(primary_obs.pinch_distance)
                if left_obs is not None:
                    lx, ly, lz = left_arm_mapper.map_position(*left_obs.wrist_xy, left_obs.hand_span)
                    full_joints.update(arm_angles_from_hand_position(lx, ly, lz, "left"))
                    left_hand = hand_openness_to_grip(left_obs.pinch_distance)

            # MANUAL mode: joints only change via keypresses (handled below), nothing computed here.

            status, safe_joints = safety.evaluate(full_joints, confidence=confidence_for_safety)
            if status == SAFE:
                full_joints = joint_ctrl.limit_acceleration(safe_joints, dt=C.TIME_STEP_MS / 1000.0)
            # else: hold full_joints unchanged (previous safe pose)

            command = HumanoidCommand.from_joint_dict(
                full_joints, mode=mode_mgr.mode.value.lower(), gesture=gesture_label,
                confidence=gesture_conf, left_hand=left_hand, right_hand=right_hand,
                emergency_stop=safety.is_estopped(),
            )
            sender.send(command)

            snapshot = {
                "camera_ok": True, "hand_visible": primary_obs is not None,
                "pose_visible": pose_obs.visible if pose_obs else False,
                "robot_connected": False,  # main_humanoid.py doesn't receive acks; Webots side logs its own connection state
                "gesture": gesture_label, "confidence": gesture_conf,
                "mode": mode_mgr.mode.value, "safety_status": status,
                "left_active": left_obs is not None or (pose_obs.visible if pose_obs else False),
                "right_active": primary_obs is not None,
                "fps": fps, "latency_ms": (time.time() - frame_start) * 1000.0,
            }
            draw_humanoid_hud(frame, snapshot)
            cv2.imshow("Humanoid Robot Control (q=quit)", frame)

            key = cv2.waitKey(1) & 0xFF
            if key == ord('q'):
                break
            elif key in (ord('e'), ord('m'), ord('g'), ord('r')):
                mode_mgr.handle_key(chr(key))
                if chr(key) == 'e':
                    safety.trigger_estop()
            elif key == ord('k'):
                calibrator.start()
                print("[main_humanoid] Calibration started -- follow prompts (reusing arm project's calibrator).")
            elif mode_mgr.mode == HumanoidMode.MANUAL:
                if key == ord('['):
                    manual_selected_idx = (manual_selected_idx - 1) % len(C.ACTIVE_HUMANOID_JOINTS)
                elif key == ord(']'):
                    manual_selected_idx = (manual_selected_idx + 1) % len(C.ACTIVE_HUMANOID_JOINTS)
                elif key == ord('w'):
                    name = C.ACTIVE_HUMANOID_JOINTS[manual_selected_idx]
                    full_joints[name] = full_joints.get(name, 0.0) + C.MANUAL_JOINT_STEP
                elif key == ord('s'):
                    name = C.ACTIVE_HUMANOID_JOINTS[manual_selected_idx]
                    full_joints[name] = full_joints.get(name, 0.0) - C.MANUAL_JOINT_STEP

            # Calibration progress (if active), separate from the mode-key branch above
            if calibrator.current_step() is not None and primary_obs is not None:
                completed_step = calibrator.update(
                    *primary_obs.wrist_xy, primary_obs.hand_span, primary_obs.roll, primary_obs.pitch)
                if calibrator.is_complete():
                    mapping = calibrator.save()
                    left_arm_mapper.set_calibration(mapping)
                    right_arm_mapper.set_calibration(mapping)
                    print(f"[main_humanoid] Calibration complete, saved to {C.CALIBRATION_FILE}")

    except Exception as e:
        print(f"[main_humanoid] ERROR: unexpected exception: {e}")
        safety.trigger_estop()
    finally:
        hand_tracker.close()
        pose_tracker.close()
        sender.close()
        cv2.destroyAllWindows()
        print("[main_humanoid] Shutdown complete.")


if __name__ == "__main__":
    main()
