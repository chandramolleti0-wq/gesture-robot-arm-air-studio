# Air Studio: Air Writing + Virtual Drawing

This is an add-on to the existing `gesture_robot_arm` project. It does not replace or modify the robotic-arm controller. It adds `air_studio.py`, a webcam-based canvas with finger drawing, save/undo/color controls, basic geometric shape classification, and an offline character/number guesser.

## Windows / VS Code setup

Open the extracted `gesture_robot_arm` folder in VS Code, then open **Terminal → New Terminal**. Make sure the terminal is in the folder containing `air_studio.py`.

If you already created `.venv` and activated it, continue with the install command. If not, run:

```powershell
py -3.12 -m venv .venv
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
.\.venv\Scripts\Activate.ps1
```

Install only the dependencies required for Air Studio (avoids installing the unrelated, larger PyTorch/scikit-learn packages from the robotics project's full requirements file):

```powershell
python -m pip install --upgrade pip
python -m pip install opencv-python mediapipe==0.10.21 numpy
```

Run it:

```powershell
python air_studio.py
```

If the webcam does not open, close other camera applications. If necessary, edit `cv2.VideoCapture(0)` to `cv2.VideoCapture(1)` in `air_studio.py`.

## Controls

- Raise only the index finger to draw on the canvas.
- Open palm pauses drawing.
- `1` through `5`: select brush color.
- `+` / `-`: brush size.
- `Enter`: guess both the character/number and the shape currently on the canvas.
- `L`: character/number guess only.
- `H`: shape guess only.
- `U`: undo the last stroke.
- `C`: clear canvas.
- `S`: save canvas PNG under `paintings/`.
- `Q`: quit.

## Recognition limitations

- Shape detection is a lightweight geometric heuristic, not a trained AI vision model. It works best for a single large, simple shape.
- Character recognition compares the drawing with built-in OpenCV font templates. It is an approximate offline demo, not reliable general-purpose handwriting OCR. Draw one large, centered A-Z letter or 0-9 digit at a time, clear the canvas between characters, and verify the guess. Multi-stroke handwriting can produce incorrect results.
- This add-on uses the webcam only and does not move a physical or simulated robot arm. Robot-arm painting would require separate robot motion-control integration.

## Troubleshooting

- If `python -m pip` installs packages but MediaPipe import fails, confirm the selected interpreter is `.venv` Python 3.12 in VS Code (`Ctrl+Shift+P` → **Python: Select Interpreter**).
- If Windows Application Control blocks the installer executable, do not try to bypass organizational controls. Use an approved Python environment or ask the device administrator to permit the required packages.
