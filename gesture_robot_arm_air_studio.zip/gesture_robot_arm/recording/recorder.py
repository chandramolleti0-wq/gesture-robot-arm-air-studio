"""
recording/recorder.py
Records robot movements as a sequence of waypoints (position, orientation,
joint angles, gripper position, timestamp) to auto-numbered JSON files in
config.RECORDINGS_DIR (recording_001.json, recording_002.json, ...).
"""

import glob
import json
import os
import re
import time

import config as C


class Recorder:
    def __init__(self, directory=None):
        self.directory = directory or C.RECORDINGS_DIR
        os.makedirs(self.directory, exist_ok=True)
        self.waypoints = []
        self.recording = False

    def start(self):
        self.waypoints = []
        self.recording = True

    def add_waypoint(self, position, orientation, joint_angles, gripper, timestamp=None):
        if not self.recording:
            return
        self.waypoints.append({
            "timestamp": timestamp if timestamp is not None else time.time(),
            "position": list(position),
            "orientation": list(orientation),
            "joint_angles": list(joint_angles),
            "gripper": gripper,
        })

    def stop(self):
        self.recording = False

    def _next_filename(self):
        existing = glob.glob(os.path.join(self.directory, "recording_*.json"))
        numbers = []
        for path in existing:
            m = re.search(r"recording_(\d+)\.json$", path)
            if m:
                numbers.append(int(m.group(1)))
        next_n = (max(numbers) + 1) if numbers else 1
        return os.path.join(self.directory, f"recording_{next_n:03d}.json")

    def save(self):
        if not self.waypoints:
            return None
        path = self._next_filename()
        with open(path, "w") as f:
            json.dump({"waypoints": self.waypoints}, f, indent=2)
        return path

    def clear(self):
        self.waypoints = []

    def __len__(self):
        return len(self.waypoints)
