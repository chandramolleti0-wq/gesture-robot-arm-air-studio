"""
recording/playback.py
Loads a recorded waypoint file and manages playback state:

    Recorded waypoints -> spline interpolation -> velocity limiting
    (handled by robotics.motion_planner) -> safety validation -> execution

This module owns *what position to be at right now* given play/pause/
stop/speed state; robotics.motion_planner and robotics.safety_manager
handle turning that into safe joint motion, exactly as they do for live
hand tracking -- playback doesn't get a safety-checking shortcut.
"""

import json
import time

from robotics.trajectory import catmull_rom_spline
import config as C


class PlaybackState:
    STOPPED = "STOPPED"
    PLAYING = "PLAYING"
    PAUSED = "PAUSED"


class Playback:
    def __init__(self, samples_per_segment=None, step_interval=None):
        self.samples_per_segment = samples_per_segment or C.PLAYBACK_SAMPLES_PER_SEGMENT
        self.step_interval = step_interval or C.PLAYBACK_STEP_INTERVAL
        self.speed = 1.0
        self.state = PlaybackState.STOPPED
        self._path = []
        self._idx = 0
        self._last_step_time = 0.0

    def load(self, path):
        with open(path) as f:
            data = json.load(f)
        waypoints = [
            (wp["position"][0], wp["position"][1], wp["position"][2], wp.get("gripper", 0.0))
            for wp in data["waypoints"]
        ]
        self._path = catmull_rom_spline(waypoints, self.samples_per_segment)
        self._idx = 0
        self.state = PlaybackState.STOPPED
        return len(self._path)

    def set_speed(self, speed):
        if speed not in C.PLAYBACK_SPEED_OPTIONS:
            nearest = min(C.PLAYBACK_SPEED_OPTIONS, key=lambda s: abs(s - speed))
            speed = nearest
        self.speed = speed

    def play(self):
        if not self._path:
            return False
        self.state = PlaybackState.PLAYING
        self._last_step_time = 0.0
        return True

    def pause(self):
        if self.state == PlaybackState.PLAYING:
            self.state = PlaybackState.PAUSED

    def resume(self):
        if self.state == PlaybackState.PAUSED:
            self.state = PlaybackState.PLAYING

    def stop(self):
        self.state = PlaybackState.STOPPED
        self._idx = 0

    def restart(self):
        self._idx = 0
        self.play()

    def is_finished(self):
        return self._idx >= len(self._path)

    def step(self, now=None):
        """
        Call every frame. Returns the current target (x, y, z, grip) if
        it's time to advance to a new sample, else None (caller should
        keep commanding the previously returned target).
        """
        if self.state != PlaybackState.PLAYING or not self._path:
            return None
        now = now if now is not None else time.time()

        effective_interval = self.step_interval / max(self.speed, 1e-6)
        if (now - self._last_step_time) < effective_interval:
            return None

        self._last_step_time = now
        if self._idx >= len(self._path):
            self.state = PlaybackState.STOPPED
            return None

        target = self._path[self._idx]
        self._idx += 1
        return target

    def progress(self):
        return self._idx, len(self._path)
