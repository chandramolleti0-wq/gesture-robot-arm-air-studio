"""
apps/air_mouse.py
Control the real mouse cursor with your hand.

    index fingertip moves .......... cursor (smoothed with a One-Euro filter)
    quick thumb+index pinch ........ left click
    pinch and HOLD ................. drag (mouse down ... mouse up on release)
    thumb+middle pinch ............. right click
    peace sign (2 fingers) + move .. scroll
    fist ........................... pause (cursor frozen, drag released)
    hand leaves frame .............. any drag is released immediately

Two details that make air mice usable instead of infuriating:
  * Click-freeze: while your fingers close for a pinch, the fingertip drifts,
    so the cursor is frozen as soon as they start approaching. The click lands
    where you aimed, not where your finger ended up.
  * Hysteresis: pinch engages below MOUSE_PINCH_PRESS and only releases above
    MOUSE_PINCH_RELEASE, so a borderline pinch can't flicker into 20 clicks.

Safety: AirMouse never touches the OS directly -- it talks to a backend.
DryRunBackend just records events (default, and what the tests use);
PyAutoGUIBackend moves the real cursor and is only used when you explicitly
go live.
"""

from dataclasses import dataclass, field
from typing import List, Optional, Tuple

import config as C
from perception.one_euro_filter import VectorOneEuroFilter


# ------------------------------------------------------------------ backends
class DryRunBackend:
    """Records what *would* have happened. Never touches the real cursor."""
    is_live = False

    def __init__(self, size=(1920, 1080)):
        self._size = size
        self.events = []

    def screen_size(self):
        return self._size

    def move(self, x, y):
        self.events.append(("move", round(x), round(y)))

    def mouse_down(self, button="left"):
        self.events.append(("down", button))

    def mouse_up(self, button="left"):
        self.events.append(("up", button))

    def click(self, button="left"):
        self.events.append(("click", button))

    def scroll(self, amount):
        self.events.append(("scroll", amount))


class PyAutoGUIBackend:
    """Drives the real OS cursor. Requires `pip install pyautogui` and a
    desktop session (on macOS: grant Accessibility permission; on Linux:
    X11 -- Wayland usually blocks synthetic input)."""
    is_live = True

    def __init__(self):
        import pyautogui
        pyautogui.FAILSAFE = True    # slam the real cursor into a screen corner to abort
        pyautogui.PAUSE = 0
        self._pg = pyautogui

    def screen_size(self):
        size = self._pg.size()
        return (size.width, size.height)

    def move(self, x, y):
        self._pg.moveTo(x, y, _pause=False)

    def mouse_down(self, button="left"):
        self._pg.mouseDown(button=button)

    def mouse_up(self, button="left"):
        self._pg.mouseUp(button=button)

    def click(self, button="left"):
        self._pg.click(button=button)

    def scroll(self, amount):
        self._pg.scroll(int(amount))


def make_backend(live: bool):
    """Returns (backend, note). Falls back to dry-run, with an honest note,
    if live was requested but pyautogui isn't usable."""
    if not live:
        return DryRunBackend(), "dry-run (cursor not touched)"
    try:
        return PyAutoGUIBackend(), "LIVE (controlling the real cursor)"
    except Exception as e:  # ImportError, or no display on headless Linux
        return DryRunBackend(), f"dry-run -- pyautogui unavailable ({type(e).__name__}: {e})"


# ---------------------------------------------------------------- controller
@dataclass
class MouseResult:
    events: List[str] = field(default_factory=list)
    cursor: Tuple[float, float] = (0.0, 0.0)
    state: str = "NO_HAND"


class AirMouse:
    def __init__(self, backend=None, region=None):
        self.backend = backend or DryRunBackend()
        self.region = region or C.MOUSE_ACTIVE_REGION
        sw, sh = self.backend.screen_size()
        self.cursor = (sw / 2.0, sh / 2.0)

        self._filter = None
        self._pinching = False
        self._pinch_start = 0.0
        self._dragging = False
        self._right_down = False
        self._last_right_click = -1e9
        self._scroll_y = None
        self._scroll_acc = 0.0

    # -------------------------------------------------------------- helpers
    def set_backend(self, backend):
        """Swap dry-run <-> live. Always lets go of any held button first."""
        self._cancel_pinch([])
        self.backend = backend

    def _cancel_pinch(self, events):
        if self._dragging:
            self.backend.mouse_up("left")
            events.append("drag_end")
        self._dragging = False
        self._pinching = False

    def _to_normalized(self, x, y):
        x0, y0, x1, y1 = self.region
        nx = min(max((x - x0) / (x1 - x0), 0.0), 1.0)
        ny = min(max((y - y0) / (y1 - y0), 0.0), 1.0)
        return nx, ny

    def _move_to(self, x, y, now):
        nx, ny = self._to_normalized(x, y)
        if self._filter is None:
            self._filter = VectorOneEuroFilter(
                now, (nx, ny), C.MOUSE_FILTER_MIN_CUTOFF, C.MOUSE_FILTER_BETA, 1.0)
            fx, fy = nx, ny
        else:
            fx, fy = self._filter(now, (nx, ny))
        sw, sh = self.backend.screen_size()
        self.cursor = (fx * (sw - 1), fy * (sh - 1))
        self.backend.move(*self.cursor)

    # --------------------------------------------------------------- update
    def update(self, feats, now: float) -> MouseResult:
        events: List[str] = []

        # --- Hand lost: fail safe. Never leave a button held with no hand.
        if feats is None:
            self._cancel_pinch(events)
            self._right_down = False
            self._scroll_y = None
            self._filter = None          # re-seed smoothing when the hand returns
            return MouseResult(events, self.cursor, "NO_HAND")

        pose = feats.pose

        # --- Fist = pause
        if pose == "fist":
            self._cancel_pinch(events)
            self._scroll_y = None
            return MouseResult(events, self.cursor, "PAUSED")

        # --- Peace sign = scroll
        if pose == "peace":
            self._cancel_pinch(events)
            y = feats.palm_center[1]
            if self._scroll_y is None:
                self._scroll_y = y
                self._scroll_acc = 0.0
            else:
                self._scroll_acc += (self._scroll_y - y) * C.MOUSE_SCROLL_GAIN   # hand up = scroll up
                self._scroll_y = y
                n = int(self._scroll_acc)
                if n != 0:
                    self.backend.scroll(n)
                    self._scroll_acc -= n
                    events.append("scroll")
            return MouseResult(events, self.cursor, "SCROLL")
        self._scroll_y = None

        # --- Left pinch (click / drag), with hysteresis
        if not self._pinching and feats.pinch_ratio < C.MOUSE_PINCH_PRESS:
            self._pinching = True
            self._pinch_start = now
        elif self._pinching and feats.pinch_ratio > C.MOUSE_PINCH_RELEASE:
            self._pinching = False
            if self._dragging:
                self.backend.mouse_up("left")
                self._dragging = False
                events.append("drag_end")
            else:
                self.backend.click("left")
                events.append("click")

        if self._pinching and not self._dragging and (now - self._pinch_start) >= C.MOUSE_DRAG_HOLD_S:
            self.backend.mouse_down("left")
            self._dragging = True
            events.append("drag_start")

        # --- Right click: thumb+middle pinch (only if not already left-pinching)
        if not self._pinching:
            if (not self._right_down and feats.pinch_middle_ratio < C.MOUSE_PINCH_PRESS
                    and (now - self._last_right_click) >= C.MOUSE_RIGHT_CLICK_COOLDOWN_S):
                self._right_down = True
                self._last_right_click = now
                self.backend.click("right")
                events.append("right_click")
            elif self._right_down and feats.pinch_middle_ratio > C.MOUSE_PINCH_RELEASE:
                self._right_down = False

        # --- Cursor movement
        if self._dragging:
            # While dragging, follow the pinch midpoint (stable when pinched).
            mx = (feats.thumb_tip[0] + feats.index_tip[0]) / 2.0
            my = (feats.thumb_tip[1] + feats.index_tip[1]) / 2.0
            self._move_to(mx, my, now)
            state = "DRAG"
        elif self._pinching or feats.pinch_ratio < C.MOUSE_FREEZE_RATIO:
            state = "AIMING"             # click-freeze: hold position
        else:
            self._move_to(feats.index_tip[0], feats.index_tip[1], now)
            state = "MOVE"

        return MouseResult(events, self.cursor, state)
