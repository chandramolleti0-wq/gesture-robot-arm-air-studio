"""
apps/hand_pose.py
Turns 21 MediaPipe hand landmarks into the handful of numbers the mouse and
paint apps actually need (HandFeatures), plus two small timing helpers.

Deliberately self-contained: it only needs objects with .x/.y attributes at
the standard MediaPipe landmark indices, so it has no MediaPipe import and
can be unit-tested with synthetic landmarks.

Finger "extended" test is rotation-tolerant: a finger counts as extended when
its tip is farther from the wrist than its PIP joint (by a margin). Unlike a
"tip above PIP in image y" rule, this still works if the hand is tilted.
Everything distance-based is divided by palm size (wrist -> middle MCP), so
thresholds don't depend on how far you sit from the camera.
"""

import math
from collections import deque
from dataclasses import dataclass, field
from typing import Dict, Optional, Tuple

# MediaPipe landmark indices
WRIST = 0
THUMB_TIP = 4
INDEX_MCP, INDEX_PIP, INDEX_TIP = 5, 6, 8
MIDDLE_MCP, MIDDLE_PIP, MIDDLE_TIP = 9, 10, 12
RING_PIP, RING_TIP = 14, 16
PINKY_PIP, PINKY_TIP = 18, 20

FINGER_JOINTS = {
    "index": (INDEX_PIP, INDEX_TIP),
    "middle": (MIDDLE_PIP, MIDDLE_TIP),
    "ring": (RING_PIP, RING_TIP),
    "pinky": (PINKY_PIP, PINKY_TIP),
}
EXTENDED_RATIO = 1.10


@dataclass
class HandFeatures:
    pose: str                                # fist | point | peace | three | open | other
    index_tip: Tuple[float, float]           # normalized image coords
    thumb_tip: Tuple[float, float]
    middle_tip: Tuple[float, float]
    palm_center: Tuple[float, float]
    palm_size: float                         # wrist -> middle MCP, normalized image units
    pinch_ratio: float                       # thumb<->index distance / palm size
    pinch_middle_ratio: float                # thumb<->middle distance / palm size
    extended: Dict[str, bool] = field(default_factory=dict)


def _dist(a, b):
    return math.hypot(a.x - b.x, a.y - b.y)


def classify_pose(extended: Dict[str, bool]) -> str:
    up = {name for name, is_up in extended.items() if is_up}
    if not up:
        return "fist"
    if up == {"index"}:
        return "point"
    if up == {"index", "middle"}:
        return "peace"
    if up == {"index", "middle", "ring"}:
        return "three"
    if up == {"index", "middle", "ring", "pinky"}:
        return "open"
    return "other"


def extract_features(lm) -> HandFeatures:
    wrist = lm[WRIST]
    palm = max(_dist(wrist, lm[MIDDLE_MCP]), 1e-6)

    extended = {
        name: _dist(wrist, lm[tip]) > _dist(wrist, lm[pip]) * EXTENDED_RATIO
        for name, (pip, tip) in FINGER_JOINTS.items()
    }

    thumb, index, middle = lm[THUMB_TIP], lm[INDEX_TIP], lm[MIDDLE_TIP]
    mcp_i, mcp_m = lm[INDEX_MCP], lm[MIDDLE_MCP]

    return HandFeatures(
        pose=classify_pose(extended),
        index_tip=(index.x, index.y),
        thumb_tip=(thumb.x, thumb.y),
        middle_tip=(middle.x, middle.y),
        palm_center=((wrist.x + mcp_i.x + mcp_m.x) / 3.0, (wrist.y + mcp_i.y + mcp_m.y) / 3.0),
        palm_size=palm,
        pinch_ratio=_dist(thumb, index) / palm,
        pinch_middle_ratio=_dist(thumb, middle) / palm,
        extended=extended,
    )


class PoseDebouncer:
    """A pose only becomes 'stable' after being seen n frames in a row, so one
    misclassified frame can't trigger a click, a stroke, or a mode change."""

    def __init__(self, n: int = 3):
        self.n = max(1, n)
        self._recent = deque(maxlen=self.n)
        self.stable = "none"

    def update(self, pose: Optional[str]) -> str:
        self._recent.append(pose or "none")
        if len(self._recent) == self.n and len(set(self._recent)) == 1:
            self.stable = self._recent[0]
        return self.stable

    def reset(self):
        self._recent.clear()
        self.stable = "none"


class HoldDetector:
    """Fires exactly once when `target_pose` has been held for `hold_s`
    seconds; re-arms only after the pose is released. progress() gives 0..1
    for drawing a fill ring in the HUD."""

    def __init__(self, target_pose: str, hold_s: float):
        self.target_pose = target_pose
        self.hold_s = hold_s
        self._since = None
        self._fired = False

    def update(self, pose: str, now: float) -> bool:
        if pose != self.target_pose:
            self._since = None
            self._fired = False
            return False
        if self._since is None:
            self._since = now
        if not self._fired and (now - self._since) >= self.hold_s:
            self._fired = True
            return True
        return False

    def progress(self, now: float) -> float:
        if self._since is None or self._fired:
            return 0.0
        return min(1.0, (now - self._since) / self.hold_s)
