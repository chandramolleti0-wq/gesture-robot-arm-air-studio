"""
apps/air_paint.py
Paint in the air.

    index finger only ......... DRAW
    index + middle (peace) .... SELECT: hover a toolbar button to press it
    open palm ................. ERASE (big circle follows your palm)
    fist / anything else ...... lift the brush

Toolbar (top of the frame): 6 colors, RAINBOW, SYM (cycles symmetry),
SIZE -/+, UNDO, CLEAR, SAVE. Buttons trigger by dwelling on them -- CLEAR
needs a longer dwell so you can't wipe your painting by accident.

The crazy bits: symmetry modes mirror every stroke across the canvas center
(MIRROR x2, QUAD x4, KALEIDO x12, MANDALA x24); RAINBOW shifts hue along the
stroke; the canvas renders with a neon glow; sparks fly off the brush tip.

PaintCanvas is pure numpy/OpenCV drawing (no camera, no display) so all of it
is unit-testable.
"""

import colorsys
import math
import os
import random
import re
from collections import deque
from typing import List, Optional, Tuple

import cv2
import numpy as np

import config as C
from perception.one_euro_filter import VectorOneEuroFilter

SYM_MODES = [("OFF", 1), ("MIRROR", 2), ("QUAD", 4), ("KALEIDO", 12), ("MANDALA", 24)]


# --------------------------------------------------------------- the canvas
class PaintCanvas:
    def __init__(self, width: int, height: int, undo_depth: Optional[int] = None):
        self.w, self.h = width, height
        self.layer = np.zeros((height, width, 3), np.uint8)
        self._undo = deque(maxlen=undo_depth or C.PAINT_UNDO_DEPTH)
        self.sym_mode = 0
        self.hue = 0.0

    # ----- undo / clear
    def push_undo(self):
        self._undo.append(self.layer.copy())

    def undo(self) -> bool:
        if not self._undo:
            return False
        self.layer = self._undo.pop()
        return True

    def clear(self):
        self.push_undo()
        self.layer[:] = 0

    # ----- symmetry
    @property
    def sym_name(self) -> str:
        return SYM_MODES[self.sym_mode][0]

    def cycle_symmetry(self) -> str:
        self.sym_mode = (self.sym_mode + 1) % len(SYM_MODES)
        return self.sym_name

    def symmetric_points(self, p) -> List[Tuple[float, float]]:
        """All images of point p under the current symmetry mode, about the
        canvas center. The same index always corresponds to the same
        transform, so zipping the lists for two points gives matching segments."""
        cx, cy = self.w / 2.0, self.h / 2.0
        x, y = p
        mode = self.sym_name
        if mode == "OFF":
            return [(x, y)]
        if mode == "MIRROR":
            return [(x, y), (2 * cx - x, y)]
        if mode == "QUAD":
            return [(x, y), (2 * cx - x, y), (x, 2 * cy - y), (2 * cx - x, 2 * cy - y)]
        n_rot = 6 if mode == "KALEIDO" else 12
        dx, dy = x - cx, y - cy
        pts = []
        for k in range(n_rot):
            a = 2 * math.pi * k / n_rot
            ca, sa = math.cos(a), math.sin(a)
            pts.append((cx + dx * ca - dy * sa, cy + dx * sa + dy * ca))
            mdx = -dx                                   # mirrored copy, then rotated
            pts.append((cx + mdx * ca - dy * sa, cy + mdx * sa + dy * ca))
        return pts

    # ----- color
    def rainbow_color(self, advance_px: float = 0.0) -> Tuple[int, int, int]:
        self.hue = (self.hue + advance_px / C.PAINT_RAINBOW_PX_PER_CYCLE) % 1.0
        r, g, b = colorsys.hsv_to_rgb(self.hue, 1.0, 1.0)
        return int(b * 255), int(g * 255), int(r * 255)

    # ----- drawing
    def draw_segment(self, p0, p1, color, size):
        for a, b in zip(self.symmetric_points(p0), self.symmetric_points(p1)):
            cv2.line(self.layer, (int(a[0]), int(a[1])), (int(b[0]), int(b[1])),
                     color, int(size), cv2.LINE_AA)

    def draw_dot(self, p, color, size):
        for a in self.symmetric_points(p):
            cv2.circle(self.layer, (int(a[0]), int(a[1])), max(1, int(size // 2)), color, -1, cv2.LINE_AA)

    def erase_circle(self, p, radius):
        cv2.circle(self.layer, (int(p[0]), int(p[1])), int(radius), (0, 0, 0), -1)

    # ----- output
    def composite(self, frame, glow: Optional[bool] = None):
        """Draws the painting onto `frame` (in place) and returns it."""
        glow = C.PAINT_GLOW if glow is None else glow
        mask = self.layer.any(axis=2)
        frame[mask] = self.layer[mask]
        if glow and mask.any():
            blur = cv2.GaussianBlur(self.layer, (0, 0), 9)
            cv2.add(frame, blur, dst=frame)
        return frame

    def save(self, directory: Optional[str] = None) -> str:
        directory = directory or C.PAINT_SAVE_DIR
        os.makedirs(directory, exist_ok=True)
        numbers = [int(m.group(1)) for f in os.listdir(directory)
                   if (m := re.match(r"painting_(\d+)\.png$", f))]
        path = os.path.join(directory, f"painting_{(max(numbers) + 1 if numbers else 1):03d}.png")
        out = np.zeros_like(self.layer)
        self.composite(out)
        cv2.imwrite(path, out)
        return path


# ------------------------------------------------------------------ toolbar
def toolbar_items() -> List[str]:
    return ([f"color:{i}" for i in range(len(C.PAINT_COLORS))]
            + ["rainbow", "sym", "size-", "size+", "undo", "clear", "save"])


def toolbar_layout(width: int):
    items = toolbar_items()
    w = width / len(items)
    return [(item, int(i * w), int((i + 1) * w)) for i, item in enumerate(items)]


def toolbar_hit(x: float, y: float, width: int) -> Optional[str]:
    if y < 0 or y >= C.PAINT_TOOLBAR_HEIGHT:
        return None
    for item, x0, x1 in toolbar_layout(width):
        if x0 <= x < x1:
            return item
    return None


# -------------------------------------------------------------------- the app
class PaintApp:
    def __init__(self, width: int, height: int, save_dir: Optional[str] = None):
        self.w, self.h = width, height
        self.canvas = PaintCanvas(width, height)
        self.save_dir = save_dir
        self.color_idx = 0
        self.rainbow = False
        self.size = C.PAINT_BRUSH_SIZE
        self.state = "IDLE"                    # IDLE | DRAW | SELECT | ERASE
        self.cursor = (0.0, 0.0)
        self.last_saved = None

        self._filter = None
        self._drawing = False
        self._erasing = False
        self._last_pt = None
        self._dwell_item = None
        self._dwell_start = 0.0
        self._dwell_fired = False
        self._particles = []                   # [x, y, vx, vy, life, (b,g,r)]

    # ---- state helpers
    def current_color(self):
        return self.canvas.rainbow_color(0.0) if self.rainbow else C.PAINT_COLORS[self.color_idx]

    def _end_stroke(self):
        self._drawing = False
        self._erasing = False
        self._last_pt = None

    def dwell_progress(self, now: float) -> float:
        if self._dwell_item is None or self._dwell_fired:
            return 0.0
        return min(1.0, (now - self._dwell_start) / self._dwell_for(self._dwell_item))

    @staticmethod
    def _dwell_for(item: str) -> float:
        return C.PAINT_CLEAR_DWELL_S if item == "clear" else C.PAINT_DWELL_S

    # ---- toolbar actions
    def trigger(self, item: str) -> str:
        if item.startswith("color:"):
            self.color_idx = int(item.split(":")[1])
            self.rainbow = False
            return "color"
        if item == "rainbow":
            self.rainbow = not self.rainbow
            return "rainbow_on" if self.rainbow else "rainbow_off"
        if item == "sym":
            return f"sym:{self.canvas.cycle_symmetry()}"
        if item == "size-":
            self.size = max(C.PAINT_BRUSH_MIN, self.size - 2)
            return "size"
        if item == "size+":
            self.size = min(C.PAINT_BRUSH_MAX, self.size + 2)
            return "size"
        if item == "undo":
            return "undo" if self.canvas.undo() else "undo_empty"
        if item == "clear":
            self.canvas.clear()
            return "clear"
        if item == "save":
            self.last_saved = self.canvas.save(self.save_dir)
            return f"saved:{self.last_saved}"
        return "noop"

    def handle_key(self, ch: str) -> Optional[str]:
        """Keyboard shortcuts (handy alongside the gesture toolbar)."""
        table = {"c": "clear", "u": "undo", "s": "save", "y": "sym", "r": "rainbow",
                 "+": "size+", "=": "size+", "-": "size-"}
        return self.trigger(table[ch]) if ch in table else None

    # ---- per-frame update
    def update(self, feats, now: float) -> List[str]:
        events: List[str] = []

        if feats is None:
            self._end_stroke()
            self._dwell_item = None
            self._filter = None
            self.state = "IDLE"
            self._step_particles()
            return events

        nx, ny = feats.index_tip
        if self._filter is None:
            self._filter = VectorOneEuroFilter(
                now, (nx, ny), C.PAINT_FILTER_MIN_CUTOFF, C.PAINT_FILTER_BETA, 1.0)
            fx, fy = nx, ny
        else:
            fx, fy = self._filter(now, (nx, ny))
        pt = (fx * self.w, fy * self.h)
        self.cursor = pt
        pose = feats.pose

        if pose == "point" and pt[1] >= C.PAINT_TOOLBAR_HEIGHT:
            self.state = "DRAW"
            self._dwell_item = None
            self._erasing = False
            color = self.current_color()
            if not self._drawing:
                self.canvas.push_undo()
                self._drawing = True
                self._last_pt = None
            if self._last_pt is None:
                self.canvas.draw_dot(pt, color, self.size)
            else:
                dist = math.dist(pt, self._last_pt)
                if dist > C.PAINT_STROKE_JUMP_FRAC * self.w:      # tracking glitch: don't draw a streak
                    self.canvas.draw_dot(pt, color, self.size)
                else:
                    if self.rainbow:
                        color = self.canvas.rainbow_color(dist)
                    self.canvas.draw_segment(self._last_pt, pt, color, self.size)
            self._last_pt = pt
            self._spawn_particles(pt, color)

        elif pose == "peace":
            self._end_stroke()
            self.state = "SELECT"
            item = toolbar_hit(pt[0], pt[1], self.w)
            if item != self._dwell_item:
                self._dwell_item = item
                self._dwell_start = now
                self._dwell_fired = False
            elif item is not None and not self._dwell_fired and (now - self._dwell_start) >= self._dwell_for(item):
                self._dwell_fired = True
                events.append(self.trigger(item))

        elif pose == "open":
            self._drawing = False
            self._last_pt = None
            self._dwell_item = None
            self.state = "ERASE"
            if not self._erasing:
                self.canvas.push_undo()
                self._erasing = True
            self.canvas.erase_circle(pt, C.PAINT_ERASER_RADIUS)

        else:
            self._end_stroke()
            self._dwell_item = None
            self.state = "IDLE"

        self._step_particles()
        return events

    # ---- particles
    def _spawn_particles(self, pt, color):
        if not C.PAINT_PARTICLES:
            return
        for _ in range(2):
            if len(self._particles) < C.PAINT_MAX_PARTICLES:
                ang = random.uniform(0, 2 * math.pi)
                spd = random.uniform(1.0, 4.0)
                self._particles.append([pt[0], pt[1], math.cos(ang) * spd, math.sin(ang) * spd,
                                        random.randint(8, 18), color])

    def _step_particles(self):
        alive = []
        for p in self._particles:
            p[0] += p[2]; p[1] += p[3]; p[3] += 0.15; p[4] -= 1
            if p[4] > 0:
                alive.append(p)
        self._particles = alive

    # ---- rendering
    def render(self, frame, now: float):
        self.canvas.composite(frame)

        for x, y, _, _, life, color in self._particles:
            cv2.circle(frame, (int(x), int(y)), max(1, life // 6), color, -1, cv2.LINE_AA)

        # toolbar
        cv2.rectangle(frame, (0, 0), (self.w, C.PAINT_TOOLBAR_HEIGHT), (25, 25, 25), -1)
        labels = {"rainbow": "RGB", "sym": self.canvas.sym_name[:5], "size-": "S-", "size+": "S+",
                  "undo": "UNDO", "clear": "CLEAR", "save": "SAVE"}
        for item, x0, x1 in toolbar_layout(self.w):
            if item.startswith("color:"):
                idx = int(item.split(":")[1])
                cv2.rectangle(frame, (x0 + 3, 6), (x1 - 3, C.PAINT_TOOLBAR_HEIGHT - 6), C.PAINT_COLORS[idx], -1)
                if idx == self.color_idx and not self.rainbow:
                    cv2.rectangle(frame, (x0 + 1, 4), (x1 - 1, C.PAINT_TOOLBAR_HEIGHT - 4), (255, 255, 255), 2)
            else:
                active = (item == "rainbow" and self.rainbow)
                cv2.rectangle(frame, (x0 + 3, 6), (x1 - 3, C.PAINT_TOOLBAR_HEIGHT - 6),
                              (0, 140, 0) if active else (70, 70, 70), -1)
                cv2.putText(frame, labels[item], (x0 + 6, 36), cv2.FONT_HERSHEY_SIMPLEX, 0.38,
                            (255, 255, 255), 1, cv2.LINE_AA)
            if item == self._dwell_item:
                prog = self.dwell_progress(now)
                if prog > 0:
                    cv2.rectangle(frame, (x0 + 3, C.PAINT_TOOLBAR_HEIGHT - 5),
                                  (x0 + 3 + int((x1 - x0 - 6) * prog), C.PAINT_TOOLBAR_HEIGHT - 2),
                                  (0, 255, 255), -1)

        # cursor
        cx, cy = int(self.cursor[0]), int(self.cursor[1])
        if self.state == "DRAW":
            cv2.circle(frame, (cx, cy), max(3, self.size // 2 + 2), self.current_color(), 2, cv2.LINE_AA)
        elif self.state == "ERASE":
            cv2.circle(frame, (cx, cy), C.PAINT_ERASER_RADIUS, (255, 255, 255), 2, cv2.LINE_AA)
        elif self.state == "SELECT":
            cv2.circle(frame, (cx, cy), 10, (0, 255, 255), 2, cv2.LINE_AA)
        return frame
