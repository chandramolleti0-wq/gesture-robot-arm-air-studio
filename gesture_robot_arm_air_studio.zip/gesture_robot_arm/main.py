"""
main.py
Entry point. Run with:  python main.py

Startup sequence (per spec):
    1. Load configuration        2. Load gesture model
    3. Load calibration           4. Initialize camera
    5. Initialize MediaPipe       6. Connect to Webots (UDP sender ready)
    7. Start safety manager       8. Start gesture recognition
    9. Start robot control        10. Display HUD

Startup safety: mode starts at IDLE with motion disabled. The arm will
not move until a deliberate open-palm gesture transitions to TRACKING.

Robustness: the per-frame body is wrapped in a broad try/except. Any
unexpected exception triggers an emergency stop and is logged as an
ERROR rather than propagating -- a bug in, say, the HUD drawing code
must never be able to leave the robot moving with stale commands.
"""

import glob
import os
import time

import cv2

import config as C
from perception.hand_tracker import HandTracker
from perception.gesture_classifier import classify as rule_based_classify
from control.command_manager import CommandManager, MotionGestureDetector
from control.mode_manager import ModeManager, Mode
from control.gesture_mapper import GestureMapper
from control.calibration import Calibrator
from control.voice_control import VoiceControl
from robotics.safety_manager import SafetyManager
from robotics.motion_planner import MotionPlanner
from communication.udp_controller import UDPSender
from recording.recorder import Recorder
from recording.playback import Playback
from ui.hud import draw_hud
from ui.dashboard import DashboardServer
from logging_utils import CommandLogger


def build_classifier():
    """Returns classify_fn(obs) -> (label, confidence). Falls back to
    rule-based if deep-learning is selected but unavailable (missing
    model/labels/torch) -- never crash startup over a missing model file."""
    if C.CLASSIFIER_MODE == "deep_learning":
        try:
            from perception.gesture_classifier_dl import GestureClassifierDL
            dl = GestureClassifierDL()
            print(f"[main] Using deep-learning classifier, classes: {dl.classes}")
            return lambda obs: dl.classify(obs.landmarks)
        except Exception as e:
            print(f"[main] WARNING: deep-learning classifier unavailable ({e}); "
                  f"falling back to rule-based classifier.")

    print("[main] Using rule-based classifier")
    return lambda obs: rule_based_classify(
        obs.landmarks, C.PINCH_THRESHOLD, C.FINGER_CURL_MARGIN, obs.roll
    )


def split_hands(observations):
    """Returns (primary_obs, left_obs). Single hand -> it's always primary,
    regardless of handedness label (single-hand fallback mode)."""
    if len(observations) == 0:
        return None, None
    if len(observations) == 1:
        return observations[0], None
    right = next((o for o in observations if o.handedness == "Right"), None)
    left = next((o for o in observations if o.handedness == "Left"), None)
    if right is None:
        right, left = observations[0], observations[1]
    return right, left


def latest_recording():
    files = sorted(glob.glob(os.path.join(C.RECORDINGS_DIR, "recording_*.json")))
    return files[-1] if files else None


def main():
    print("[main] 1/10 Configuration loaded")

    classify_fn = build_classifier()
    print("[main] 2/10 Gesture model ready")

    calibration = Calibrator.load()
    if calibration:
        print(f"[main] 3/10 Calibration loaded from {C.CALIBRATION_FILE}")
    else:
        print("[main] 3/10 No calibration found -- using config.py defaults. Press 'k' to calibrate.")

    try:
        tracker = HandTracker()
    except Exception as e:
        print(f"[main] ERROR: Camera/MediaPipe initialization failed: {e}")
        return
    print("[main] 4/10 Camera initialized  5/10 MediaPipe initialized")

    sender = UDPSender()
    print(f"[main] 6/10 UDP sender ready ({C.UDP_HOST}:{C.UDP_PORT}) -- "
          f"start the Webots controller to actually move the arm")

    safety = SafetyManager()
    print("[main] 7/10 Safety manager started")

    right_commands = CommandManager()
    left_commands = CommandManager(min_duration=0.15, debounce=0.2, cooldown=0.0)
    motion_detector = MotionGestureDetector()
    print("[main] 8/10 Gesture recognition started")

    mode_manager = ModeManager()
    mapper = GestureMapper(calibration)
    local_planner = MotionPlanner(safety)  # local shadow copy, for HUD/logging diagnostics only
    calibrator = Calibrator()
    recorder = Recorder()
    playback = Playback()
    voice = VoiceControl()
    if C.VOICE_CONTROL_ENABLED:
        voice.start()
    dashboard = DashboardServer()
    dashboard.start()
    logger = CommandLogger()
    print("[main] 9/10 Robot control ready. Mode=IDLE, motion DISABLED. "
          "Show an open palm to begin tracking.")
    print("[main] 10/10 Starting HUD. Press 'q' to quit, 'k' to calibrate.")

    last_target = (0.0, sum(C.ROBOT_WORKSPACE["y"]) / 2, sum(C.ROBOT_WORKSPACE["z"]) / 2)
    last_wrist_roll, last_wrist_pitch = 0.0, 0.0
    last_gripper = 0.0

    try:
        while True:
            try:
                ok, frame, observations, fps, cam_error = tracker.read()
                if not ok:
                    print(f"[main] ERROR: Camera not available ({cam_error})")
                    time.sleep(0.1)
                    continue

                primary_obs, left_obs = split_hands(observations)

                gesture_label, gesture_conf = "none", 0.0
                if primary_obs is not None:
                    gesture_label, gesture_conf = classify_fn(primary_obs)

                right_event = right_commands.update(gesture_label, gesture_conf)

                left_label, left_conf = "none", 0.0
                left_event = None
                if left_obs is not None:
                    left_label, left_conf = classify_fn(left_obs)
                    left_event = left_commands.update(left_label, left_conf)

                # ---- Emergency stop handling (highest priority) ----
                if right_event and right_event.label == "estop":
                    mode_manager.handle_gesture("estop")
                    safety.trigger_estop()

                if mode_manager.mode == Mode.EMERGENCY_STOP:
                    open_palm_now = (gesture_label == "open_palm" and gesture_conf >= C.GESTURE_CONFIDENCE_THRESHOLD)
                    safety.update_estop_clear(open_palm_now)
                    if not safety.is_estopped():
                        mode_manager.transition(Mode.IDLE)
                        right_commands.reset()

                # ---- Calibration mode ----
                if mode_manager.mode == Mode.CALIBRATION:
                    if primary_obs is not None:
                        step = calibrator.current_step()
                        completed = calibrator.update(
                            primary_obs.wrist_xy[0], primary_obs.wrist_xy[1],
                            primary_obs.hand_span, primary_obs.roll, primary_obs.pitch,
                        )
                        if calibrator.is_complete():
                            mapping = calibrator.save()
                            mapper.set_calibration(mapping)
                            mode_manager.transition(Mode.IDLE)
                            print(f"[main] Calibration complete, saved to {C.CALIBRATION_FILE}")
                    else:
                        calibrator.reset_hold()

                # ---- Left-hand commands (precision toggle, dangerous-action confirm) ----
                elif left_event is not None:
                    if left_event.label == "fist":
                        mode_manager.handle_gesture("left_fist")
                    elif left_event.label == "open_palm":
                        mode_manager.handle_gesture("left_open_palm")

                # ---- Right-hand mode transitions (record, tracking, pause) ----
                if mode_manager.mode not in (Mode.EMERGENCY_STOP, Mode.CALIBRATION):
                    if right_event is not None:
                        if mode_manager.mode == Mode.RECORD and right_event.label == "peace":
                            recorder.stop()
                            saved_path = recorder.save()
                            recorder.clear()
                            mode_manager.transition(Mode.TRACKING)
                            print(f"[main] Recording saved to {saved_path}")
                        else:
                            mode_manager.handle_gesture(right_event.label)
                            if mode_manager.mode == Mode.RECORD and not recorder.recording:
                                recorder.start()

                        # Dangerous action: playback requires double thumbs-up confirmation
                        if right_event.label == "thumbs_up" and mode_manager.mode in (Mode.TRACKING, Mode.PRECISION):
                            confirmed = right_commands.confirm_dangerous(right_event)
                            if confirmed:
                                path = latest_recording()
                                if path:
                                    playback.load(path)
                                    playback.play()
                                    mode_manager.transition(Mode.PLAYBACK)
                                    print(f"[main] Playback started: {path}")
                                else:
                                    print("[main] WARNING: no recordings to play back")

                # ---- Compute target position/orientation/gripper ----
                warnings = []
                if mode_manager.mode == Mode.PLAYBACK:
                    step_target = playback.step()
                    if step_target is not None:
                        last_target = step_target[:3]
                        last_gripper = step_target[3]
                    if playback.is_finished():
                        mode_manager.transition(Mode.TRACKING)
                elif mode_manager.mode in (Mode.TRACKING, Mode.PRECISION, Mode.RECORD) and primary_obs is not None:
                    last_target = mapper.map_position(*primary_obs.wrist_xy, primary_obs.hand_span)
                    last_wrist_roll, last_wrist_pitch = mapper.map_orientation(primary_obs.roll, primary_obs.pitch)
                    gripper_source = left_obs if left_obs is not None else primary_obs
                    last_gripper = mapper.map_gripper(gripper_source.pinch_distance)
                # else: hold last_target/last_gripper unchanged (IDLE/PAUSED/no hand)

                speed_scale = C.PRECISION_SPEED_SCALE if mode_manager.mode == Mode.PRECISION else 1.0
                plan_result = local_planner.plan(
                    last_target, wrist_pitch_offset=last_wrist_pitch,
                    dt=C.TIME_STEP_MS / 1000.0, speed_scale=speed_scale,
                )
                warnings += plan_result.warnings

                if mode_manager.mode == Mode.RECORD and recorder.recording:
                    recorder.add_waypoint(last_target, (last_wrist_roll, last_wrist_pitch, 0.0),
                                           plan_result.angles, last_gripper)

                # ---- Send to Webots ----
                sender.send(
                    position=last_target,
                    orientation=(last_wrist_roll, last_wrist_pitch, 0.0),
                    gripper=last_gripper,
                    mode=mode_manager.mode.value,
                    emergency_stop=safety.is_estopped(),
                )

                # ---- Voice control (optional) ----
                if voice.is_available():
                    vc = voice.poll_command()
                    if vc == "voice_estop":
                        mode_manager.handle_gesture("estop")
                        safety.trigger_estop()
                    elif vc == "voice_precision_mode":
                        mode_manager.handle_gesture("left_fist")
                    elif vc == "voice_normal_mode":
                        mode_manager.handle_gesture("left_open_palm")
                    elif vc == "voice_calibrate":
                        calibrator.start()
                        mode_manager.transition(Mode.CALIBRATION)

                # ---- Logging ----
                if right_event is not None:
                    logger.log(
                        timestamp=time.time(), gesture=right_event.label, confidence=right_event.confidence,
                        hand_x=primary_obs.wrist_xy[0] if primary_obs else "",
                        hand_y=primary_obs.wrist_xy[1] if primary_obs else "",
                        hand_z=primary_obs.hand_span if primary_obs else "",
                        robot_x=last_target[0], robot_y=last_target[1], robot_z=last_target[2],
                        joint_angles=list(plan_result.angles), gripper_position=last_gripper,
                        mode=mode_manager.mode.value, ik_solver=plan_result.ik_solver_used,
                        ik_error=plan_result.ik_error,
                        safety_status=plan_result.reason,
                    )

                # ---- HUD ----
                snapshot = {
                    "gesture": gesture_label, "confidence": gesture_conf,
                    "mode": mode_manager.mode.value,
                    "hand_pos": primary_obs.wrist_xy + (primary_obs.hand_span,) if primary_obs else (0, 0, 0),
                    "robot_pos": last_target, "gripper": last_gripper,
                    "ik_solver": plan_result.ik_solver_used, "ik_error": plan_result.ik_error,
                    "robot_speed": speed_scale, "safety_status": plan_result.reason,
                    "fps": fps, "warnings": warnings,
                }
                if mode_manager.mode == Mode.CALIBRATION:
                    step = calibrator.current_step()
                    idx, total = calibrator.progress()
                    snapshot["warnings"] = [f"CALIBRATION: hold hand at '{step}' ({idx+1}/{total})"]

                dashboard.update_state(snapshot)
                draw_hud(frame, snapshot)
                cv2.imshow("Gesture Robot Control (q=quit, k=calibrate)", frame)

                key = cv2.waitKey(1) & 0xFF
                if key == ord('q'):
                    break
                if key == ord('k') and mode_manager.mode not in (Mode.EMERGENCY_STOP,):
                    calibrator.start()
                    mode_manager.transition(Mode.CALIBRATION)
                    print("[main] Calibration started. Follow on-screen prompts.")

            except Exception as e:
                # Fail safe: never let an unexpected exception leave the
                # robot moving on stale commands.
                print(f"[main] ERROR: unexpected exception in main loop: {e}")
                safety.trigger_estop()
                try:
                    sender.send(last_target, (last_wrist_roll, last_wrist_pitch, 0.0),
                                last_gripper, Mode.EMERGENCY_STOP.value, emergency_stop=True)
                except Exception:
                    pass
                time.sleep(0.05)

    finally:
        tracker.close()
        sender.close()
        logger.close()
        voice.stop()
        cv2.destroyAllWindows()
        print("[main] Shutdown complete.")


if __name__ == "__main__":
    main()
