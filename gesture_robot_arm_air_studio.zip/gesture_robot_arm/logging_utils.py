"""
logging_utils.py
Logs every accepted gesture/command to a CSV file in config.LOGS_DIR, one
file per run (timestamped filename). Kept as simple, dependency-free CSV
writing so a logging failure can never itself become a reason the main
loop breaks.
"""

import csv
import os
import time

import config as C

FIELDS = [
    "timestamp", "gesture", "confidence", "hand_x", "hand_y", "hand_z",
    "robot_x", "robot_y", "robot_z", "joint_angles", "gripper_position",
    "mode", "ik_solver", "ik_error", "safety_status",
]


class CommandLogger:
    def __init__(self, directory=None):
        self.directory = directory or C.LOGS_DIR
        os.makedirs(self.directory, exist_ok=True)
        filename = f"session_{time.strftime('%Y%m%d_%H%M%S')}.csv"
        self.path = os.path.join(self.directory, filename)
        self._file = open(self.path, "w", newline="")
        self._writer = csv.DictWriter(self._file, fieldnames=FIELDS)
        self._writer.writeheader()

    def log(self, **kwargs):
        row = {k: kwargs.get(k, "") for k in FIELDS}
        try:
            self._writer.writerow(row)
            self._file.flush()
        except (OSError, ValueError):
            # A logging hiccup (e.g. disk full) must never interrupt
            # robot control -- swallow and move on.
            pass

    def close(self):
        try:
            self._file.close()
        except OSError:
            pass
