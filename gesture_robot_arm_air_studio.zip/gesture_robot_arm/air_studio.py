"""Air Studio: webcam air-writing, drawing, and basic shape/character recognition.

Run: python air_studio.py
Controls: index finger only = draw; open palm = pause; C clear; U undo;
Enter recognize canvas; 1-5 colors; +/- brush size; S save; Q quit.
Recognition is an offline prototype: shape detection is geometric and character
recognition compares a drawing to OpenCV font templates. It works best with one
large, centered character at a time; it is not a general handwriting OCR model.
"""
from __future__ import annotations
import time
from pathlib import Path
import cv2
import numpy as np

try:
    import mediapipe as mp
except ImportError as exc:
    raise SystemExit("MediaPipe is missing. Run: python -m pip install mediapipe==0.10.21") from exc

CAM_W, CAM_H = 640, 480
CAN_W, CAN_H = 640, 480
PANEL_W, PANEL_H = 300, 480
COLORS = [
    ("White", (245, 245, 245)),
    ("Red", (70, 70, 255)),
    ("Green", (70, 235, 100)),
    ("Blue", (255, 150, 50)),
    ("Yellow", (40, 230, 255)),
]
SAVE_DIR = Path("paintings")
SAVE_DIR.mkdir(exist_ok=True)


def text(img, msg, xy, scale=0.55, color=(235, 235, 235), thick=1):
    cv2.putText(img, msg, xy, cv2.FONT_HERSHEY_SIMPLEX, scale, color, thick, cv2.LINE_AA)


def crop_and_normalize(binary: np.ndarray, size=(64, 64)) -> np.ndarray | None:
    ys, xs = np.where(binary > 0)
    if len(xs) < 25:
        return None
    x0, x1, y0, y1 = xs.min(), xs.max() + 1, ys.min(), ys.max() + 1
    crop = binary[y0:y1, x0:x1]
    h, w = crop.shape
    scale = min((size[0] - 8) / max(w, 1), (size[1] - 8) / max(h, 1))
    nw, nh = max(1, int(w * scale)), max(1, int(h * scale))
    resized = cv2.resize(crop, (nw, nh), interpolation=cv2.INTER_AREA)
    out = np.zeros((size[1], size[0]), np.uint8)
    x, y = (size[0] - nw) // 2, (size[1] - nh) // 2
    out[y:y + nh, x:x + nw] = resized
    _, out = cv2.threshold(out, 35, 255, cv2.THRESH_BINARY)
    return out


def glyph_templates():
    templates = []
    chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
    for ch in chars:
        for font in (cv2.FONT_HERSHEY_SIMPLEX, cv2.FONT_HERSHEY_DUPLEX):
            for thickness in (2, 3):
                img = np.zeros((100, 100), np.uint8)
                (tw, th), _ = cv2.getTextSize(ch, font, 2.0, thickness)
                x, y = max(1, (100 - tw) // 2), min(88, (100 + th) // 2)
                cv2.putText(img, ch, (x, y), font, 2.0, 255, thickness, cv2.LINE_AA)
                norm = crop_and_normalize(img)
                if norm is not None:
                    templates.append((ch, norm))
    return templates


def recognize_character(canvas_gray, templates):
    binary = cv2.threshold(canvas_gray, 35, 255, cv2.THRESH_BINARY)[1]
    norm = crop_and_normalize(binary)
    if norm is None:
        return "Nothing drawn", 0.0
    best_char, best_score = "?", -1.0
    # Symmetric normalized pixel similarity against rendered OpenCV glyphs.
    a = norm.astype(np.float32) / 255.0
    for ch, templ in templates:
        b = templ.astype(np.float32) / 255.0
        score = float(cv2.matchTemplate(a, b, cv2.TM_CCOEFF_NORMED)[0, 0])
        if score > best_score:
            best_char, best_score = ch, score
    return best_char, max(0.0, best_score)


def recognize_shape(canvas_gray):
    binary = cv2.threshold(canvas_gray, 35, 255, cv2.THRESH_BINARY)[1]
    contours, _ = cv2.findContours(binary, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    if not contours:
        return "No shape detected"
    contour = max(contours, key=cv2.contourArea)
    area = cv2.contourArea(contour)
    if area < 100:
        return "Draw a larger shape"
    perimeter = cv2.arcLength(contour, True)
    if perimeter <= 0:
        return "Unknown shape"
    approx = cv2.approxPolyDP(contour, 0.035 * perimeter, True)
    vertices = len(approx)
    circularity = 4 * np.pi * area / (perimeter * perimeter)
    x, y, w, h = cv2.boundingRect(contour)
    ratio = w / max(h, 1)
    if circularity > 0.78 and vertices > 6:
        return "Circle / oval"
    if vertices == 3:
        return "Triangle"
    if vertices == 4:
        return "Square" if 0.82 <= ratio <= 1.22 else "Rectangle"
    if vertices == 5:
        return "Pentagon"
    if vertices == 6:
        return "Hexagon"
    if vertices >= 7:
        hull = cv2.convexHull(contour)
        hull_area = cv2.contourArea(hull)
        solidity = area / max(hull_area, 1)
        if solidity < 0.75:
            return "Star / complex shape"
        return "Circle / freeform"
    return "Freeform drawing"


def main():
    mp_hands = mp.solutions.hands
    draw_utils = mp.solutions.drawing_utils
    cap = cv2.VideoCapture(0)
    if not cap.isOpened():
        raise SystemExit("Cannot open webcam. Close other camera apps or change VideoCapture(0) to VideoCapture(1).")
    canvas = np.zeros((CAN_H, CAN_W, 3), np.uint8)
    undo_stack = []
    color_index, brush = 0, 8
    previous = None
    message = "Raise only index finger to draw; open palm pauses"
    last_char = "-"
    last_shape = "-"
    templates = glyph_templates()
    print("Air Studio started. Draw one large character or shape, then press Enter to recognize it. Q quits.")

    with mp_hands.Hands(max_num_hands=1, model_complexity=0,
                        min_detection_confidence=0.6, min_tracking_confidence=0.6) as hands:
        try:
            while True:
                ok, camera = cap.read()
                if not ok:
                    message = "Camera frame unavailable"
                    time.sleep(0.03)
                    continue
                camera = cv2.flip(camera, 1)
                camera = cv2.resize(camera, (CAM_W, CAM_H))
                rgb = cv2.cvtColor(camera, cv2.COLOR_BGR2RGB)
                result = hands.process(rgb)
                is_drawing = False
                point = None
                if result.multi_hand_landmarks:
                    hand = result.multi_hand_landmarks[0]
                    lm = hand.landmark
                    draw_utils.draw_landmarks(camera, hand, mp_hands.HAND_CONNECTIONS)
                    # Finger is up if tip is above its PIP joint in the mirrored image.
                    index_up = lm[8].y < lm[6].y
                    middle_up = lm[12].y < lm[10].y
                    ring_up = lm[16].y < lm[14].y
                    pinky_up = lm[20].y < lm[18].y
                    point = (int(lm[8].x * CAN_W), int(lm[8].y * CAN_H))
                    if all((index_up, middle_up, ring_up, pinky_up)):
                        previous = None
                        message = "OPEN PALM: drawing paused"
                    elif index_up and not middle_up and not ring_up and not pinky_up:
                        is_drawing = True
                        message = "DRAWING - index finger only"
                    else:
                        previous = None
                else:
                    previous = None

                if is_drawing and point:
                    if previous is None:
                        undo_stack.append(canvas.copy())
                        if len(undo_stack) > 10:
                            undo_stack.pop(0)
                        cv2.circle(canvas, point, max(1, brush // 2), COLORS[color_index][1], -1)
                    else:
                        cv2.line(canvas, previous, point, COLORS[color_index][1], brush, cv2.LINE_AA)
                    previous = point
                    cv2.circle(camera, point, 7, (0, 255, 255), -1)

                # Render a clear, separate canvas panel and controls panel.
                canvas_view = canvas.copy()
                cv2.rectangle(canvas_view, (0, 0), (CAN_W - 1, CAN_H - 1), (75, 75, 75), 1)
                panel = np.zeros((PANEL_H, PANEL_W, 3), np.uint8)
                text(panel, "AIR STUDIO", (18, 32), 0.85, (0, 220, 255), 2)
                text(panel, "Air writing + drawing", (18, 62))
                text(panel, "Gesture controls", (18, 105), 0.6, (100, 230, 255), 1)
                text(panel, "Index only: draw", (18, 135))
                text(panel, "Open palm: pause", (18, 160))
                text(panel, f"Color: {COLORS[color_index][0]}", (18, 195))
                text(panel, f"Brush: {brush}px", (18, 220))
                text(panel, "Keyboard", (18, 265), 0.6, (100, 230, 255), 1)
                text(panel, "1-5: color  +/-: brush", (18, 292), 0.45)
                text(panel, "ENTER: recognize", (18, 317), 0.48)
                text(panel, "H: shape  L: letter/number", (18, 342), 0.43)
                text(panel, "C: clear  U: undo  S: save", (18, 367), 0.43)
                text(panel, "Q: quit", (18, 392), 0.45)
                text(panel, "Recognition", (18, 425), 0.6, (100, 230, 255), 1)
                text(panel, f"Text: {last_char[:20]}", (18, 450), 0.48)
                text(panel, f"Shape: {last_shape[:20]}", (18, 473), 0.42)
                text(camera, "CAMERA / HAND TRACKING", (12, 25), 0.6, (0, 255, 255), 2)
                text(camera, message[:48], (12, CAM_H - 15), 0.45, (255, 255, 255), 1)
                combined = np.hstack([camera, canvas_view, panel])
                cv2.imshow("Air Studio - Gesture Writing & Drawing", combined)
                key = cv2.waitKey(1) & 0xFF
                if key == ord('q'):
                    break
                elif key == ord('c'):
                    undo_stack.append(canvas.copy())
                    canvas[:] = 0
                    previous = None
                    last_char, last_shape = "-", "-"
                    message = "Canvas cleared"
                elif key == ord('u'):
                    if undo_stack:
                        canvas = undo_stack.pop()
                    previous = None
                    message = "Undo"
                elif key == ord('s'):
                    path = SAVE_DIR / f"air_studio_{time.strftime('%Y%m%d_%H%M%S')}.png"
                    cv2.imwrite(str(path), canvas)
                    message = f"Saved: {path}"
                    print(message)
                elif ord('1') <= key <= ord('5'):
                    color_index = key - ord('1')
                elif key in (ord('+'), ord('=')):
                    brush = min(brush + 2, 36)
                elif key in (ord('-'), ord('_')):
                    brush = max(2, brush - 2)
                elif key in (10, 13):
                    gray = cv2.cvtColor(canvas, cv2.COLOR_BGR2GRAY)
                    last_char, score = recognize_character(gray, templates)
                    last_shape = recognize_shape(gray)
                    message = f"Character guess: {last_char} ({score:.2f}) | Shape: {last_shape}"
                    print(message, "(template score is approximate; verify result)")
                elif key == ord('l'):
                    gray = cv2.cvtColor(canvas, cv2.COLOR_BGR2GRAY)
                    last_char, score = recognize_character(gray, templates)
                    message = f"Character guess: {last_char} ({score:.2f})"
                    print(message)
                elif key == ord('h'):
                    gray = cv2.cvtColor(canvas, cv2.COLOR_BGR2GRAY)
                    last_shape = recognize_shape(gray)
                    message = f"Shape: {last_shape}"
                    print(message)
        finally:
            cap.release()
            cv2.destroyAllWindows()


if __name__ == '__main__':
    main()
