"""
control/humanoid_mode_manager.py
NOTE: this is a separate, humanoid-specific mode manager from the arm
project's 8-mode one -- the semantics genuinely differ (this spec calls
for exactly 4 modes: GESTURE, MIRROR, MANUAL, EMERGENCY_STOP), so rather
than overload the existing ModeManager/Mode with a second incompatible
meaning, this lives under a distinct name to avoid a collision.
main_humanoid.py imports this one; main.py (arm) is unaffected.
"""

from enum import Enum
import time

import config as C


class HumanoidMode(str, Enum):
    GESTURE = "GESTURE"
    MIRROR = "MIRROR"
    MANUAL = "MANUAL"
    EMERGENCY_STOP = "EMERGENCY_STOP"


class HumanoidModeManager:
    def __init__(self, default_mode=None):
        default = default_mode or C.HUMANOID_MODE_DEFAULT
        self.mode = HumanoidMode(default)
        self.previous_mode = self.mode
        self._entered_at = time.time()

    def transition(self, new_mode: HumanoidMode, now=None):
        now = now if now is not None else time.time()
        if new_mode == self.mode:
            return
        self.previous_mode = self.mode
        self.mode = new_mode
        self._entered_at = now

    def time_in_mode(self, now=None):
        now = now if now is not None else time.time()
        return now - self._entered_at

    def handle_key(self, key_char):
        """
        Keyboard mode switches, per the HUD legend: [E] estop [M] mirror
        [G] gesture [R] reset. EMERGENCY_STOP can only be exited via the
        safety controller's explicit hold-to-clear flow (main_humanoid.py),
        never by a plain keypress -- an accidental key tap must not
        silently resume robot motion after an e-stop.
        """
        if key_char == 'e':
            self.transition(HumanoidMode.EMERGENCY_STOP)
            return True
        if self.mode == HumanoidMode.EMERGENCY_STOP:
            return False
        if key_char == 'm':
            self.transition(HumanoidMode.MIRROR)
            return True
        if key_char == 'g':
            self.transition(HumanoidMode.GESTURE)
            return True
        if key_char == 'r':
            self.transition(HumanoidMode.GESTURE)
            return True
        return False

    def motion_enabled(self):
        return self.mode in (HumanoidMode.GESTURE, HumanoidMode.MIRROR, HumanoidMode.MANUAL)
