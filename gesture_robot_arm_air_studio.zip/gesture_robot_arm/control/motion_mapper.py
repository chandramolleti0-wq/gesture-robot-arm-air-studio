"""
control/motion_mapper.py
Two distinct mapping strategies, both producing the same output shape
(a dict of joint_name -> angle):

1. arm_angles_from_pose(): MIRROR mode. Computes the human's actual
   shoulder/elbow angles directly from 3D vector geometry between
   shoulder/elbow/wrist pose landmarks, so the robot copies the human's
   posture. This is NOT inverse kinematics -- it's forward measurement of
   the human's own joint angles.

2. arm_angles_from_hand_position(): GESTURE mode. Treats the hand's
   position as a target the arm should *reach toward*, solved via the
   existing 2-link IK (robotics/inverse_kinematics.py).

Both outputs are raw (unfiltered, unclamped) -- perception/landmark_filter.py
and robotics/safety_controller.py handle smoothing and limits downstream.
"""

import math

from robotics.inverse_kinematics import LEFT_ARM_IK, RIGHT_ARM_IK


def _vec(a, b):
    return (b.x - a.x, b.y - a.y, b.z - a.z)


def _angle_between(v1, v2):
    dot = sum(a * b for a, b in zip(v1, v2))
    n1 = math.sqrt(sum(a * a for a in v1))
    n2 = math.sqrt(sum(a * a for a in v2))
    if n1 < 1e-9 or n2 < 1e-9:
        return 0.0
    cos_a = max(-1.0, min(1.0, dot / (n1 * n2)))
    return math.acos(cos_a)


def arm_angles_from_pose(shoulder, elbow, wrist, hip, side):
    """
    shoulder, elbow, wrist, hip: MediaPipe Pose landmarks (have .x/.y/.z).
    side: "left" or "right" -- selects which joint names to return.
    Returns {f"{side}_shoulder": angle, f"{side}_elbow": angle}. Wrist
    orientation isn't derivable from Pose's 3 arm points alone (no roll
    information without hand landmarks), so wrist angle is left to the
    caller to fill from hand data if available, or left at 0.
    """
    torso_down = _vec(shoulder, hip)          # "down" direction at the shoulder
    upper_arm = _vec(shoulder, elbow)
    forearm = _vec(elbow, wrist)

    shoulder_angle = _angle_between(torso_down, upper_arm)   # 0 = arm at side, pi/2 = arm horizontal
    elbow_angle = _angle_between(upper_arm, forearm)          # 0 = straight (upper arm and forearm collinear), positive = bent

    # Signed shoulder angle: negative when the arm swings forward vs.
    # backward relative to the torso, using the horizontal (x) component
    # of the upper arm vector as the sign reference. This is a simplified,
    # single-plane approximation -- true shoulder motion is 2-DOF (pitch +
    # roll); a 1-DOF humanoid shoulder joint can only reproduce one plane
    # of it, which is what ACTIVE_HUMANOID_JOINTS models.
    sign = -1.0 if upper_arm[0] < 0 else 1.0
    if side == "right":
        sign *= -1.0

    return {
        f"{side}_shoulder": sign * shoulder_angle,
        f"{side}_elbow": elbow_angle,
    }


def arm_angles_from_hand_position(hand_x, hand_y, hand_z, side):
    """GESTURE mode: hand position (relative to shoulder, meters) -> reach IK."""
    solver = LEFT_ARM_IK if side == "left" else RIGHT_ARM_IK
    return solver.solve(hand_x, hand_y, hand_z)


def hand_openness_to_grip(pinch_distance, open_distance=0.25, closed_distance=0.03):
    """Same proportional mapping as control/gesture_mapper.py's map_gripper,
    reused here for humanoid hand open/close so both projects behave
    consistently for the same physical gesture."""
    t = (pinch_distance - closed_distance) / max(open_distance - closed_distance, 1e-6)
    t = max(0.0, min(1.0, t))
    return 1.0 - t  # 0 = open, 1 = closed
