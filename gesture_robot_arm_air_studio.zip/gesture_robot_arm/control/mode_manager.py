"""
control/mode_manager.py
Owns the robot's operating mode state machine:

    IDLE -> TRACKING -> PRECISION -> RECORD -> PLAYBACK -> CALIBRATION -> PAUSED -> EMERGENCY_STOP

Per the startup-safety requirement, the robot always starts in IDLE with
motion disabled -- entering TRACKING requires a deliberate gesture, it's
never automatic on launch.
"""

from enum import Enum
import time


class Mode(str, Enum):
    IDLE = "IDLE"
    TRACKING = "TRACKING"
    PRECISION = "PRECISION"
    RECORD = "RECORD"
    PLAYBACK = "PLAYBACK"
    CALIBRATION = "CALIBRATION"
    PAUSED = "PAUSED"
    EMERGENCY_STOP = "EMERGENCY_STOP"


# Which modes allow the arm to actually move (vs. hold position)
MOTION_ENABLED_MODES = {Mode.TRACKING, Mode.PRECISION, Mode.PLAYBACK}


class ModeManager:
    def __init__(self):
        self.mode = Mode.IDLE
        self.previous_mode = Mode.IDLE
        self._mode_entered_at = time.time()

    def motion_enabled(self):
        return self.mode in MOTION_ENABLED_MODES

    def transition(self, new_mode: Mode, now=None):
        now = now if now is not None else time.time()
        if new_mode == self.mode:
            return
        self.previous_mode = self.mode
        self.mode = new_mode
        self._mode_entered_at = now

    def time_in_mode(self, now=None):
        now = now if now is not None else time.time()
        return now - self._mode_entered_at

    def handle_gesture(self, label, current_hand_count=1):
        """
        Maps a confirmed gesture label to a mode transition. Returns True
        if a transition happened. This is intentionally conservative:
        unrecognized labels never change the mode, and EMERGENCY_STOP can
        only be exited via the safety manager's explicit hold-to-clear
        flow (handled in main.py), not through this generic mapping.
        """
        if self.mode == Mode.EMERGENCY_STOP:
            return False  # only main.py's estop-clear flow may exit this mode

        if label == "estop":
            self.transition(Mode.EMERGENCY_STOP)
            return True

        if label == "open_palm":
            if self.mode == Mode.IDLE:
                self.transition(Mode.TRACKING)
                return True
            if self.mode == Mode.PRECISION:
                self.transition(Mode.TRACKING)
                return True

        if label == "fist" and self.mode in (Mode.TRACKING, Mode.PRECISION):
            # left-hand fist (precision toggle) is handled by the caller
            # passing a distinguishable label like "left_fist"; a bare
            # "fist" from the primary hand is treated as pause instead.
            self.transition(Mode.PAUSED)
            return True

        if label == "left_fist":
            self.transition(Mode.PRECISION)
            return True
        if label == "left_open_palm":
            if self.mode == Mode.PRECISION:
                self.transition(Mode.TRACKING)
                return True

        if label == "peace" and self.mode in (Mode.TRACKING, Mode.PRECISION):
            self.transition(Mode.RECORD)
            return True

        return False
