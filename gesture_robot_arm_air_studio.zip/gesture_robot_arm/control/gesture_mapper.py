"""
control/gesture_mapper.py
Converts a filtered hand observation into a robot-space target:

    Hand X -> Robot X       Hand Y -> Robot Z        Hand depth -> Robot Y
    Palm rotation -> Wrist rotation      Pinch distance -> Gripper %

Applies calibration (if available, else config.py defaults), a
configurable dead zone around the workspace center, and a sensitivity
multiplier. Also implements proportional gripper control (a continuous
0-100% open/closed value from pinch distance, not a binary pinch/no-pinch
gesture) with its own gentle smoothing to prevent jitter.
"""

import config as C


def _lerp_range(v, in_lo, in_hi, out_lo, out_hi, clamp=True):
    if clamp:
        v = max(in_lo, min(in_hi, v))
    t = (v - in_lo) / (in_hi - in_lo) if in_hi != in_lo else 0.5
    return out_lo + t * (out_hi - out_lo)


class GestureMapper:
    def __init__(self, calibration=None):
        """calibration: dict from control.calibration.Calibrator.load(), or None to use config defaults."""
        self.set_calibration(calibration)
        self._gripper_smoothed = None

    def set_calibration(self, calibration):
        if calibration and "hand_workspace" in calibration:
            hw = calibration["hand_workspace"]
            self.hand_workspace = {
                "x": tuple(hw["x"]), "y": tuple(hw["y"]), "z": tuple(hw["z"]),
            }
            self.wrist_neutral = calibration.get("wrist_neutral", {"roll": 0.0, "pitch": 0.0})
        else:
            self.hand_workspace = {k: tuple(v) for k, v in C.HAND_WORKSPACE.items()}
            self.wrist_neutral = {"roll": 0.0, "pitch": 0.0}

    def _apply_dead_zone_and_sensitivity(self, normalized_pos):
        """normalized_pos: 0..1 within the hand workspace axis, 0.5 = center."""
        centered = normalized_pos - 0.5
        if abs(centered) < C.MAPPING_DEAD_ZONE:
            centered = 0.0
        else:
            sign = 1.0 if centered > 0 else -1.0
            centered = sign * (abs(centered) - C.MAPPING_DEAD_ZONE)
        centered *= C.MAPPING_SENSITIVITY
        return max(-0.5, min(0.5, centered)) + 0.5

    def map_position(self, hand_x, hand_y, hand_span):
        """Returns (robot_x, robot_y, robot_z) in meters."""
        nx = _lerp_range(hand_x, *self.hand_workspace["x"], 0.0, 1.0)
        ny = _lerp_range(hand_y, *self.hand_workspace["y"], 0.0, 1.0)
        nz = _lerp_range(hand_span, *self.hand_workspace["z"], 0.0, 1.0)

        nx = self._apply_dead_zone_and_sensitivity(nx)
        ny = self._apply_dead_zone_and_sensitivity(ny)

        robot_x = _lerp_range(nx, 0.0, 1.0, *C.ROBOT_WORKSPACE["x"], clamp=False)
        robot_z = _lerp_range(ny, 0.0, 1.0, *C.ROBOT_WORKSPACE["z"], clamp=False)  # hand Y -> robot Z per spec
        robot_y = _lerp_range(nz, 0.0, 1.0, *C.ROBOT_WORKSPACE["y"], clamp=False)  # hand depth -> robot Y per spec

        return robot_x, robot_y, robot_z

    def map_orientation(self, roll, pitch):
        """Returns (wrist_roll_offset, wrist_pitch_offset) relative to calibrated neutral, in radians."""
        rel_roll = roll - self.wrist_neutral.get("roll", 0.0)
        rel_pitch = pitch - self.wrist_neutral.get("pitch", 0.0)
        wrist_roll = _lerp_range(rel_roll, -0.6, 0.6, *C.WRIST_ROLL_RANGE)
        wrist_pitch = _lerp_range(rel_pitch, -0.6, 0.6, *C.WRIST_PITCH_RANGE)
        return wrist_roll, wrist_pitch

    def map_gripper(self, pinch_distance, open_distance=0.25, closed_distance=0.03):
        """
        Proportional gripper control: large pinch distance -> open (0.0),
        small distance -> closed (1.0), smoothed to prevent jitter.
        Returns a value in [GRIPPER_MIN, GRIPPER_MAX].
        """
        raw = 1.0 - _lerp_range(pinch_distance, closed_distance, open_distance, 0.0, 1.0)
        raw = max(C.GRIPPER_MIN, min(C.GRIPPER_MAX, raw))

        if self._gripper_smoothed is None:
            self._gripper_smoothed = raw
        else:
            a = C.GRIPPER_FILTER_ALPHA
            self._gripper_smoothed = a * raw + (1 - a) * self._gripper_smoothed

        return self._gripper_smoothed
