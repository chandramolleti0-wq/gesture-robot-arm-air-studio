"""
control/calibration.py
Interactive calibration: guides the user through holding their hand at
each workspace boundary (center, left, right, top, bottom, near, far,
neutral wrist), then computes hand_workspace mapping parameters from
what was actually observed -- rather than assuming everyone's reach and
camera setup matches the defaults in config.py.

Pressing 'k' during normal operation (wired up in main.py) starts this;
results are saved to config.CALIBRATION_FILE and loaded automatically on
next startup.
"""

import json
import os
import time
from dataclasses import dataclass, field

import config as C


@dataclass
class CalibrationSample:
    x: float
    y: float
    hand_span: float
    roll: float
    pitch: float


class Calibrator:
    def __init__(self, steps=None, hold_duration=None):
        self.steps = steps or C.CALIBRATION_STEPS
        self.hold_duration = hold_duration if hold_duration is not None else C.CALIBRATION_HOLD_S
        self._idx = 0
        self.samples = {}
        self._hold_buffer = []
        self._hold_start = None

    def start(self):
        self._idx = 0
        self.samples = {}
        self._hold_buffer = []
        self._hold_start = None

    def current_step(self):
        if self._idx >= len(self.steps):
            return None
        return self.steps[self._idx]

    def is_complete(self):
        return self._idx >= len(self.steps)

    def progress(self):
        return self._idx, len(self.steps)

    def update(self, hand_x, hand_y, hand_span, roll=0.0, pitch=0.0, now=None):
        """
        Call every frame a hand is visible during calibration. Returns
        True exactly on the frame a step completes (caller can use this
        to play a confirmation sound/flash, etc). Requires the hand to
        be observed continuously for hold_duration -- if update() isn't
        called for a frame (hand lost), the hold timer resets, which is
        the correct behavior: a boundary sample from a hand that
        vanished partway through isn't trustworthy.
        """
        if self.is_complete():
            return False
        now = now if now is not None else time.time()

        if self._hold_start is None:
            self._hold_start = now
            self._hold_buffer = []

        self._hold_buffer.append((hand_x, hand_y, hand_span, roll, pitch))

        if (now - self._hold_start) >= self.hold_duration:
            n = len(self._hold_buffer)
            avg = [sum(v[i] for v in self._hold_buffer) / n for i in range(5)]
            self.samples[self.current_step()] = CalibrationSample(*avg)
            self._idx += 1
            self._hold_buffer = []
            self._hold_start = None
            return True
        return False

    def reset_hold(self):
        """Call when the hand disappears mid-hold, to restart the timer honestly."""
        self._hold_start = None
        self._hold_buffer = []

    def compute_mapping(self):
        required = {"center", "left", "right", "top", "bottom", "near", "far"}
        if not required.issubset(self.samples.keys()):
            raise ValueError(f"Calibration incomplete: missing {required - self.samples.keys()}")

        s = self.samples
        x_lo, x_hi = sorted([s["left"].x, s["right"].x])
        y_lo, y_hi = sorted([s["top"].y, s["bottom"].y])
        z_lo, z_hi = sorted([s["far"].hand_span, s["near"].hand_span])

        # Guard against a degenerate calibration (e.g. user held hand in
        # nearly the same spot for two "different" boundary steps) --
        # fall back to config defaults for that axis rather than divide
        # by ~zero later during mapping.
        def safe_range(lo, hi, default):
            return (lo, hi) if (hi - lo) > 0.01 else default

        x_lo, x_hi = safe_range(x_lo, x_hi, C.HAND_WORKSPACE["x"])
        y_lo, y_hi = safe_range(y_lo, y_hi, C.HAND_WORKSPACE["y"])
        z_lo, z_hi = safe_range(z_lo, z_hi, C.HAND_WORKSPACE["z"])

        wrist_neutral = {"roll": 0.0, "pitch": 0.0}
        if "neutral_wrist" in s:
            wrist_neutral = {"roll": s["neutral_wrist"].roll, "pitch": s["neutral_wrist"].pitch}

        return {
            "hand_workspace": {"x": [x_lo, x_hi], "y": [y_lo, y_hi], "z": [z_lo, z_hi]},
            "wrist_neutral": wrist_neutral,
            "timestamp": time.time(),
        }

    def save(self, path=None):
        path = path or C.CALIBRATION_FILE
        os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
        mapping = self.compute_mapping()
        with open(path, "w") as f:
            json.dump(mapping, f, indent=2)
        return mapping

    @staticmethod
    def load(path=None):
        path = path or C.CALIBRATION_FILE
        if not os.path.exists(path):
            return None
        try:
            with open(path) as f:
                return json.load(f)
        except (json.JSONDecodeError, OSError):
            return None
