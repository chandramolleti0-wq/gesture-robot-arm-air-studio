"""
control/command_manager.py
Turns a noisy, per-frame stream of (gesture_label, confidence) into a
stream of trustworthy, debounced gesture *events*. A single frame's
classification is never enough to trigger a command:

    Gesture detected -> confidence > threshold? -> temporal confirmation
    -> command allowed (debounce/cooldown)? -> emit event

Also owns MotionGestureDetector, which watches a short history of wrist
position/hand-span/roll to recognize swipe/move/rotate gestures -- these
are inherently temporal (a single frame has no "swipe" information) so
they're detected here rather than in the per-frame static classifier.
"""

import time
from collections import deque, Counter
from dataclasses import dataclass
from typing import Optional

import config as C

DANGEROUS_LABELS = {"thumbs_up", "estop_clear", "mode_change", "reset"}


@dataclass
class GestureEvent:
    label: str
    confidence: float
    timestamp: float


class CommandManager:
    """
    Feed it every frame's raw (label, confidence) via update(). It
    returns a GestureEvent only when that gesture has been the majority
    vote across the recent window AND held stable for at least
    GESTURE_MIN_DURATION_S AND enough time has passed since the last
    accepted command (debounce/cooldown). Otherwise returns None.
    """

    def __init__(self, vote_window=None, min_duration=None, debounce=None, cooldown=None):
        self.vote_window = vote_window or C.GESTURE_VOTE_WINDOW
        self.min_duration = min_duration if min_duration is not None else C.GESTURE_MIN_DURATION_S
        self.debounce = debounce if debounce is not None else C.GESTURE_DEBOUNCE_S
        self.cooldown = cooldown if cooldown is not None else C.COMMAND_COOLDOWN

        self._history = deque(maxlen=self.vote_window)
        self._stable_label = None
        self._stable_since = None
        self._last_accepted_time = 0.0

        # Dangerous-command confirmation: label -> time it was first confirmed
        self._pending_confirmation = {}

    def _confidence_threshold_for(self, label):
        if label in DANGEROUS_LABELS:
            return C.DANGEROUS_GESTURE_CONFIDENCE_THRESHOLD
        return C.GESTURE_CONFIDENCE_THRESHOLD

    def update(self, raw_label, raw_confidence, now=None):
        now = now if now is not None else time.time()

        # Unknown-state rejection: low-confidence frames count as "unknown"
        # for voting purposes rather than letting a lucky high-confidence
        # frame in a mostly-uncertain window win the vote.
        threshold = self._confidence_threshold_for(raw_label)
        effective_label = raw_label if raw_confidence >= threshold else "unknown"
        self._history.append(effective_label)

        majority_label, _ = Counter(self._history).most_common(1)[0]

        if majority_label != self._stable_label:
            self._stable_label = majority_label
            self._stable_since = now
            return None

        if self._stable_label in (None, "unknown"):
            return None

        held_long_enough = (now - self._stable_since) >= self.min_duration
        if not held_long_enough:
            return None

        if (now - self._last_accepted_time) < (self.debounce + self.cooldown):
            return None

        self._last_accepted_time = now
        return GestureEvent(self._stable_label, raw_confidence, now)

    def confirm_dangerous(self, event: GestureEvent, now=None):
        """
        For actions that need explicit double-confirmation (e.g.
        thumbs-up to arm playback, thumbs-up again within the
        confirmation window to actually start it). Returns True only on
        the *second* matching event within GESTURE_CONFIRMATION_TIME.
        """
        now = now if now is not None else time.time()
        pending_time = self._pending_confirmation.get(event.label)

        if pending_time is not None and (now - pending_time) <= C.GESTURE_CONFIRMATION_TIME:
            del self._pending_confirmation[event.label]
            return True

        self._pending_confirmation[event.label] = now
        return False

    def reset(self):
        self._history.clear()
        self._stable_label = None
        self._stable_since = None
        self._pending_confirmation.clear()


class MotionGestureDetector:
    """
    Detects swipe/move/rotate gestures from a rolling window of wrist
    position (x, y), hand-span (depth proxy), and wrist roll. Each
    detected motion gesture has its own cooldown so a single continuous
    swipe doesn't fire the same command repeatedly.
    """

    def __init__(self, window_s=None):
        self.window_s = window_s or C.MOTION_GESTURE_WINDOW_S
        self._history = deque()  # (t, x, y, span, roll)
        self._last_fired = {}

    def update(self, wrist_x, wrist_y, hand_span, roll, now=None):
        now = now if now is not None else time.time()
        self._history.append((now, wrist_x, wrist_y, hand_span, roll))
        while self._history and (now - self._history[0][0]) > self.window_s:
            self._history.popleft()

        if len(self._history) < 2:
            return None

        t0, x0, y0, span0, roll0 = self._history[0]
        t1, x1, y1, span1, roll1 = self._history[-1]
        dt = max(t1 - t0, 1e-6)
        if dt < self.window_s * 0.5:
            return None  # not enough history spread yet

        dx, dy = x1 - x0, y1 - y0
        dspan = span1 - span0
        droll = roll1 - roll0

        label = None
        if abs(dx) > C.SWIPE_MIN_DISPLACEMENT and abs(dx) > abs(dy) * 1.5:
            label = "swipe_right" if dx > 0 else "swipe_left"
        elif abs(dy) > C.SWIPE_MIN_DISPLACEMENT and abs(dy) > abs(dx) * 1.5:
            label = "move_down" if dy > 0 else "move_up"
        elif abs(dspan) > 0.08:
            label = "move_forward" if dspan > 0 else "move_backward"
        elif abs(droll) > (C.ROTATE_MIN_ANGLE_DEG * 3.14159 / 180.0):
            label = "rotate_clockwise" if droll > 0 else "rotate_counterclockwise"

        if label is None:
            return None

        last = self._last_fired.get(label, 0.0)
        if (now - last) < (self.window_s + C.COMMAND_COOLDOWN):
            return None

        self._last_fired[label] = now
        self._history.clear()
        return GestureEvent(label, 1.0, now)
