"""
control/mirror_controller.py
Orchestrates MIRROR mode: for each visible arm (pose landmarks required;
falls back to holding the last pose for an arm whose landmarks are
missing, rather than snapping it to zero), computes shoulder/elbow angles
via control/motion_mapper.arm_angles_from_pose(), smooths them through a
JointFilterBank (dead-zone + One-Euro), and returns a ready-to-safety-check
joint-angle dict.
"""

from control.motion_mapper import arm_angles_from_pose, hand_openness_to_grip
from perception.landmark_filter import JointFilterBank
from perception.pose_tracker import PoseTracker
import config as C

MIRROR_JOINTS = ["left_shoulder", "left_elbow", "right_shoulder", "right_elbow"]


class MirrorController:
    def __init__(self):
        self._filters = JointFilterBank(
            MIRROR_JOINTS, dead_zone_rad=C.MIRROR_DEAD_ZONE_DEG * 3.14159 / 180.0
        )
        self._last_angles = {name: 0.0 for name in MIRROR_JOINTS}

    def update(self, pose_obs, left_pinch=None, right_pinch=None, now=None):
        """
        pose_obs: perception.pose_tracker.PoseObservation or None.
        left_pinch/right_pinch: optional pinch distances (from hand
        tracking) for hand open/close; omitted arms keep hands at 0 (open).
        Returns {"joint_angles": {...}, "left_hand": float, "right_hand": float}.
        """
        raw = dict(self._last_angles)

        if pose_obs is not None and pose_obs.visible:
            left_shoulder = PoseTracker.joint(pose_obs, "LEFT_SHOULDER")
            left_elbow = PoseTracker.joint(pose_obs, "LEFT_ELBOW")
            left_wrist = PoseTracker.joint(pose_obs, "LEFT_WRIST")
            left_hip = PoseTracker.joint(pose_obs, "LEFT_HIP")
            if all(j is not None for j in (left_shoulder, left_elbow, left_wrist, left_hip)):
                raw.update(arm_angles_from_pose(left_shoulder, left_elbow, left_wrist, left_hip, "left"))

            right_shoulder = PoseTracker.joint(pose_obs, "RIGHT_SHOULDER")
            right_elbow = PoseTracker.joint(pose_obs, "RIGHT_ELBOW")
            right_wrist = PoseTracker.joint(pose_obs, "RIGHT_WRIST")
            right_hip = PoseTracker.joint(pose_obs, "RIGHT_HIP")
            if all(j is not None for j in (right_shoulder, right_elbow, right_wrist, right_hip)):
                raw.update(arm_angles_from_pose(right_shoulder, right_elbow, right_wrist, right_hip, "right"))

        self._last_angles = raw
        filtered = self._filters.update(raw, now)

        left_hand = hand_openness_to_grip(left_pinch) if left_pinch is not None else 0.0
        right_hand = hand_openness_to_grip(right_pinch) if right_pinch is not None else 0.0

        return {"joint_angles": filtered, "left_hand": left_hand, "right_hand": right_hand}

    def reset(self):
        self._filters.reset()
        self._last_angles = {name: 0.0 for name in MIRROR_JOINTS}
