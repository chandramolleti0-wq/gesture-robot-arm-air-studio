"""
control/voice_control.py
Optional voice command support, layered alongside gestures (not instead
of them). Disabled by default (config.VOICE_CONTROL_ENABLED). If the
`speech_recognition` package (or a working microphone) isn't available,
this module logs one message and simply never produces any commands --
main.py's gesture pipeline is completely unaffected either way.
"""

import queue
import threading

try:
    import speech_recognition as sr
    SR_AVAILABLE = True
except ImportError:
    SR_AVAILABLE = False

VOICE_COMMANDS = {
    "open gripper": "voice_open_gripper",
    "close gripper": "voice_close_gripper",
    "start recording": "voice_start_recording",
    "stop recording": "voice_stop_recording",
    "play recording": "voice_play_recording",
    "pause": "voice_pause",
    "emergency stop": "voice_estop",
    "precision mode": "voice_precision_mode",
    "normal mode": "voice_normal_mode",
    "calibrate": "voice_calibrate",
}


class VoiceControl:
    def __init__(self):
        self._queue = queue.Queue()
        self._thread = None
        self._running = False
        self._available = SR_AVAILABLE

    def is_available(self):
        return self._available

    def start(self):
        if not self._available:
            print("[voice] speech_recognition not installed -- voice control disabled. "
                  "Install with `pip install SpeechRecognition pyaudio` to enable it. "
                  "Gesture control is unaffected.")
            return False
        try:
            self._recognizer = sr.Recognizer()
            self._mic = sr.Microphone()
        except Exception as e:
            print(f"[voice] Microphone unavailable ({e}) -- voice control disabled.")
            self._available = False
            return False

        self._running = True
        self._thread = threading.Thread(target=self._listen_loop, daemon=True)
        self._thread.start()
        print("[voice] Voice control active.")
        return True

    def _listen_loop(self):
        with self._mic as source:
            self._recognizer.adjust_for_ambient_noise(source, duration=0.5)
        while self._running:
            try:
                with self._mic as source:
                    audio = self._recognizer.listen(source, timeout=2, phrase_time_limit=3)
                text = self._recognizer.recognize_google(audio).lower().strip()
                for phrase, command in VOICE_COMMANDS.items():
                    if phrase in text:
                        self._queue.put(command)
                        break
            except Exception:
                # Timeouts, unrecognized audio, network errors, etc. are
                # all routine for live speech recognition -- never let
                # one bad listen cycle kill the thread.
                continue

    def poll_command(self):
        """Returns the next voice command string, or None if none pending."""
        try:
            return self._queue.get_nowait()
        except queue.Empty:
            return None

    def stop(self):
        self._running = False
