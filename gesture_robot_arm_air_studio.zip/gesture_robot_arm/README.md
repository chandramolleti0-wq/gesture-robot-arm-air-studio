# Gesture-Controlled Robotic Arm -- Professional Edition

A modular, safety-first architecture for controlling a simulated Webots robotic
arm with hand gestures, following the pipeline:

```
Camera -> MediaPipe Hand Tracking -> Landmark Preprocessing -> Gesture/Pose
Recognition -> Intent/Command Manager -> Motion Planner -> Inverse Kinematics
-> Safety Layer -> Trajectory Generator -> UDP Communication -> Webots Robot
```

## What's actually verified vs. what needs your hardware to confirm

Being direct about this, same as always: **every pure-logic module has a real,
passing automated test** (40 tests, `tests/`, all currently green) --
kinematics, safety limits, motion planning, trajectory generation, UDP
messaging, the rule-based classifier, and feature extraction. I also ran the
full ML training pipeline end-to-end on a synthetic dataset (real code path:
data loading, stratified split, class-weighted loss, training loop, checkpoint
selection, confusion matrix, per-class precision/recall/F1) and it works.

**What can't be verified without your camera and Webots setup:** `main.py`'s
live camera loop, the actual HUD rendering, real gesture recognition accuracy
on a real hand, and the Webots controller actually driving motors. These are
implemented carefully and the logic they call has been tested in isolation,
but "the whole thing runs end-to-end with a webcam and Webots open" is
something only you can confirm on your machine -- tell me what breaks and
I'll fix it directly.

---

## 1. Installation

```bash
pip install -r requirements.txt
```

If you hit `AttributeError: module 'mediapipe' has no attribute 'solutions'`,
your Python version doesn't have a wheel for `mediapipe==0.10.21` (this
affects Python 3.13+). Use Python 3.11 or 3.12 instead -- see the
troubleshooting note at the bottom.

Optional extras (only if you want these features):
```bash
pip install flask                        # for ui/dashboard.py
pip install SpeechRecognition pyaudio     # for control/voice_control.py
```
Both degrade gracefully and print a one-line notice if their dependency is
missing -- the core controller works fully without either.

## 2. Run commands

```bash
python main.py
```

This starts the full pipeline: camera, MediaPipe, gesture recognition, safety
manager, and HUD. **The robot starts in IDLE with motion disabled.** Show an
open palm to begin tracking -- it never moves on its own at launch.

For the Webots side, see section 5.

Run the test suite:
```bash
pytest tests/ -v
```

## 3. Project structure

```
gesture_robot_arm/
├── main.py, config.py, logging_utils.py, requirements.txt
├── perception/       hand_tracker, feature_utils, gesture_classifier(_dl), one_euro_filter
├── control/          command_manager, mode_manager, calibration, gesture_mapper, voice_control
├── robotics/         ik_solver, ik_solver_dls, motion_planner, trajectory, safety_manager
├── communication/     udp_controller
├── recording/         recorder, playback
├── ui/                 hud, dashboard
├── models/, recordings/, logs/, data/    (generated at runtime)
├── webots/controllers/webots_controller/webots_controller.py
├── collect_data.py, train_classifier.py
└── tests/
```

## 4. Gesture vocabulary

**Static (right/primary hand):**

| Gesture | Effect |
|---|---|
| Open palm | Track hand position (IDLE->TRACKING, or exits precision) |
| Pinch | Proportional gripper control (see below) |
| Fist | Pause |
| Peace | Toggle waypoint recording (RECORD mode) |
| Thumbs up | Requires a **second** thumbs-up within 1.5s to confirm -- starts playback of the most recent recording |
| Index + pinky ("estop") | **Emergency stop.** Clears only after an open palm is held continuously for `ESTOP_UNLOCK_HOLD_S` (default 1s) |
| Index + pinky + thumb out ("rock") | Distinguished from estop by thumb position/wrist roll -- reserved, not yet bound to an action |
| OK sign, index/middle point, three/four fingers, victory | Recognized by the classifier; available for you to bind to custom actions in `control/mode_manager.py` |

**Motion (either hand, detected from movement over time, not a single frame):**
swipe_left/right, move_up/down, move_forward/backward (from hand-depth
change), rotate_clockwise/counterclockwise (from wrist roll change).

**Left hand (two-hand mode):**

| Gesture | Effect |
|---|---|
| Fist | Enter PRECISION mode (slower, filtered, more accurate) |
| Open palm | Return to normal TRACKING |
| Pinch distance | Controls the gripper (right hand controls position/orientation instead) |

If only one hand is visible, that hand controls both position and its own
pinch distance drives the gripper -- single-hand mode always works safely.

**Proportional gripper:** pinch distance maps continuously to 0-100% closed,
not a binary open/closed, with its own smoothing to prevent jitter.

## 5. Webots setup

1. In your Webots world, your arm needs motors named to match `config.py`'s
   `MOTOR_NAMES` / `GRIPPER_MOTOR_NAMES` (or edit those lists to match your
   PROTO -- click the robot node in Webots to check actual device names).
2. Copy (or symlink) the **entire project root** so it's reachable from
   `webots/controllers/webots_controller/webots_controller.py` -- that file
   adds the project root to `sys.path` automatically based on its own
   location (`_PROJECT_ROOT_LEVELS_UP`), assuming you keep the
   `webots/controllers/webots_controller/` layout. If you move it, adjust
   that constant.
3. Set your robot's **controller** field to `webots_controller`.
4. Press Play in Webots. It starts idle, listening on UDP (`config.UDP_HOST`
   / `UDP_PORT`), and will not move until it receives a connected,
   motion-enabling message -- a comms timeout or e-stop flag freezes it in
   place rather than acting on stale data.
5. Separately, run `python main.py` on the vision side.

**Run order:** start Webots first, then `main.py` -- if reversed, the first
few packets are simply dropped (harmless) until the Webots controller starts
listening.

## 6. Calibration

Press **`k`** at any time (not while e-stopped) to start calibration. Follow
the on-screen prompt through each step: center, left, right, top, bottom,
near, far, neutral wrist orientation -- hold your hand steady at each position
for `CALIBRATION_HOLD_S` (default 1s; the hold timer resets if your hand
leaves the frame partway through, since a partial sample isn't trustworthy).

Results save to `data/calibration.json` and load automatically on the next
launch. Recalibrate any time by pressing `k` again.

## 7. Training your own gesture model

Ships with **no pretrained model** -- a model trained on someone else's hand,
camera, and lighting won't transfer reliably to yours.

1. Collect data (150-300+ samples per gesture; vary hand angle/distance/position):
   ```bash
   python collect_data.py
   ```
   See the key mapping printed at startup (`o`=open_palm, `p`=pinch, etc.,
   `r`=other/relaxed poses -- important for teaching the model to reject
   ambiguous frames instead of forcing a guess).

2. Train:
   ```bash
   python train_classifier.py
   ```
   This does a stratified 70/15/15 train/val/test split, class-weighted loss
   (so an over-collected gesture doesn't dominate), and reports a full
   confusion matrix + per-class precision/recall/F1 on the held-out test set.
   Saves `models/gesture_model_<version>.pt`, `models/labels.json`, and
   `models/training_metrics.json`. Training never runs automatically during
   normal operation -- it's always this separate, deliberate step.

3. Switch it on in `config.py`:
   ```python
   CLASSIFIER_MODE = "deep_learning"
   ```
   If the model/labels can't be loaded for any reason, `main.py` prints a
   warning and falls back to the rule-based classifier automatically rather
   than crashing at startup.

## 8. Operating the robot safely

- **Startup:** always begins IDLE, motion disabled. Show an open palm to begin.
- **Emergency stop:** the estop gesture (or the voice command, or a UDP
  comms timeout) immediately freezes the arm and releases the gripper. It
  stays locked until an open palm is held continuously for the configured
  duration -- a fast, accidental gesture cannot clear it.
- **Dangerous actions** (currently: starting playback) require the same
  gesture confirmed twice within `GESTURE_CONFIRMATION_TIME` (default 1.5s),
  so a single misread frame can't trigger it.
- **Every** target and every IK joint solution passes through
  `SafetyManager` (workspace clamp, joint limits, velocity/acceleration
  limiting) regardless of source -- live tracking, playback, or anything you
  add later. There's no fast path that skips this.
- **Comms loss:** if the Webots controller doesn't receive a message within
  `UDP_TIMEOUT_S`, it freezes rather than continuing to act on the last
  command indefinitely.
- **Exceptions:** `main.py`'s per-frame loop is wrapped in a broad
  try/except that triggers an emergency stop and logs the error rather than
  propagating -- a bug anywhere in the loop (HUD drawing, logging, etc.)
  cannot leave the robot moving on stale data.

## 9. Configuration

Every tunable lives in `config.py` -- camera settings, confidence thresholds,
filter parameters, workspace boxes, joint limits, IK solver choice, velocity/
acceleration limits, UDP settings, playback options, and more. Nothing else
in the project should hard-code a value you'd reasonably want to change.

## 10. Known limitations / honest gaps

- The new static gestures (OK sign, victory, rock, finger-count gestures)
  are implemented in the rule-based classifier by finger-extension logic
  that's reasonable by construction but, like the rest of the rule-based
  path, hasn't been tuned against a real hand -- expect to adjust
  `PINCH_THRESHOLD`/`FINGER_CURL_MARGIN` in `config.py` once you see it live.
- `robotics/motion_planner.py`'s collision checking is a real hook
  (`SafetyManager.set_collision_provider()`) but has no Webots collision
  data wired into it by default -- if your Webots scene exposes contact/
  proximity sensors, write a small function `f(trajectory) -> bool` and pass
  it to `safety.set_collision_provider(f)` in `main.py`.
- Voice control and the dashboard are intentionally minimal (a command
  keyword-matcher and a single-page auto-refreshing status view,
  respectively) since your own spec correctly scoped them as optional and
  non-blocking -- they're not meant to be the deep part of this system.

## Troubleshooting: mediapipe `AttributeError: module 'mediapipe' has no attribute 'solutions'`

Recent mediapipe releases (0.10.30+) on PyPI are missing the legacy
`solutions` API this project uses. Fix:
```bash
pip uninstall mediapipe -y
pip install mediapipe==0.10.21
```
If pip says no matching distribution is found, check `python --version` --
`0.10.21` has no wheel for Python 3.13+. Install Python 3.11 or 3.12,
recreate your virtual environment with it, and reinstall.

---

# Part 2: Full-Body Humanoid Extension

Everything above still works unchanged -- `main.py`, the tabletop arm,
`webots/controllers/webots_controller/`. This section covers the
**separate** `main_humanoid.py` entry point, which extends the same
architecture to a full-body humanoid: hands remain the primary control
signal, with MediaPipe Pose added for shoulder/elbow/wrist posture in
MIRROR mode.

## What's genuinely tested vs. what needs Webots to confirm

Same honesty standard as Part 1, applied to the new pieces. **18 new
automated tests, all passing** (58 total across the whole project):
joint-angle geometry (verified against three hand-checked synthetic
poses: arm straight down reads ~0, arm raised horizontal reads ~90°,
a 90°-bent elbow reads ~90°), the generalized N-joint velocity/
acceleration limiter, the 4-mode state machine (including the
hold-to-clear e-stop and the "estop can't be cleared by a plain
keypress" rule), the humanoid UDP command schema round-tripping over a
real socket, and per-arm IK.

**Two real bugs were found and fixed while testing this**, not zero:
the elbow-bend formula was inverted (read π for a straight arm instead
of 0), and `neutral_pose()` was including hand keys that don't belong in
the joint-angle dict (hands are tracked as separate fields, as
`HumanoidState` already correctly modeled).

**What can't be verified here:** `main_humanoid.py`'s live camera loop,
`webots/controllers/humanoid_controller/humanoid_controller.py` actually
driving Webots motors, and -- most importantly -- **the world file,
`webots/worlds/humanoid_world.wbt`, has not been opened in Webots.** It
was written with reasonable confidence in standard Webots/VRML97 syntax,
but if Webots reports a field error on load, that's a real possibility,
not a hidden risk. See the world file's own header comment for what to
do if that happens. `communication/ros_controller.py`'s "rclpy absent"
path is tested; its actual ROS 2 publishing path is not, since rclpy
requires a full ROS 2 distribution not available in the environment this
was built in.

## Architecture

```
Camera -> MediaPipe Hands + Pose -> Gesture/Posture Recognition
   -> Motion Mapper (mirror angles OR reach IK) -> Safety Controller
   -> Joint Controller (velocity/accel limits) -> UDP -> Webots
```

New modules, alongside the existing arm-project ones they reuse:

```
perception/pose_tracker.py         MediaPipe Pose (shoulders/elbows/wrists/hips/knees/ankles)
perception/landmark_filter.py      shared dead-zone + One-Euro pipeline, generalized to N joints
control/motion_mapper.py           mirror-angle geometry + reach-IK mapping
control/mirror_controller.py       orchestrates MIRROR mode
control/humanoid_mode_manager.py   GESTURE / MIRROR / MANUAL / EMERGENCY_STOP
robotics/humanoid_controller.py    joint layout + HumanoidState
robotics/joint_controller.py       N-joint velocity/acceleration limiting
robotics/inverse_kinematics.py     per-arm wrapper around the existing 2-link solver
robotics/safety_controller.py      joint limits + watchdog + e-stop, generalized to N joints
communication/udp_sender.py        HumanoidCommand dataclass + JSON schema, built on the tested UDP layer
communication/ros_controller.py    optional ROS 2 publishing, degrades gracefully without rclpy
webots/controllers/humanoid_controller/   Webots-side controller
webots/worlds/humanoid_world.wbt   minimal placeholder humanoid (see caveats above)
main_humanoid.py                   new entry point
```

Reused, unchanged: `perception/hand_tracker.py`, `perception/gesture_classifier.py`
(rule-based), `control/calibration.py`, `control/gesture_mapper.py` (one
instance per arm in GESTURE mode), and the entire tested UDP socket layer
in `communication/udp_controller.py`.

## Control modes

| Mode | Key | Behavior |
|---|---|---|
| GESTURE (default) | `G` | Each visible hand's position drives the corresponding arm to *reach toward* that point (2-link IK per arm, reusing the arm project's solver) |
| MIRROR | `M` | The robot copies your actual arm posture (shoulder/elbow angles measured directly from Pose landmarks via vector geometry, not IK) |
| MANUAL | -- | `[`/`]` selects a joint, `W`/`S` steps it by `config.MANUAL_JOINT_STEP` |
| EMERGENCY_STOP | `E` | Freezes all joints immediately. Clears only via a held-open-palm gesture (same hold-to-clear pattern as Part 1) -- never by a plain keypress |

Reset to GESTURE mode: `R`. Calibrate: `K` (reuses `control/calibration.py`
unchanged -- same hand-workspace wizard as the arm project).

## Gesture vocabulary

| Gesture | Effect |
|---|---|
| Open palm | Enter/confirm active tracking; clears e-stop when held |
| Fist | (available for you to bind -- see `perception/gesture_classifier.py`) |
| Thumbs up | Confirmation gesture (available for you to bind to a specific action) |
| Pinch | Proportional hand open/close, per arm |
| Index + pinky ("estop") | Emergency stop |
| Hand moving up/down/left/right | In GESTURE mode, continuously reflected in arm position via the reach IK -- no separate discrete gesture needed |

Two Fingers ("victory") is recognized by the classifier and left
unbound (`config.py` / `control/humanoid_mode_manager.py` is where to
wire it to a specific action) -- same "extend, don't guess what you
want" principle as the rest of this project.

## Webots setup

1. **Joint device names.** `config.HUMANOID_JOINTS` maps our internal
   joint names to Webots motor device names. The defaults match
   `webots/worlds/humanoid_world.wbt`'s placeholder humanoid. If you
   instead use Webots' built-in Nao (Wizards > Add a new object > robots
   > softbank > nao) or another PROTO, **you must check its real device
   names yourself in the Webots scene tree** and update
   `HUMANOID_JOINTS` to match -- SoftBank's NAOqi joint names (e.g.
   `LShoulderPitch`) are vendor-specific internals this project did not
   have a running Webots instance to verify against.
2. Copy the project so it's reachable from
   `webots/controllers/humanoid_controller/humanoid_controller.py` (same
   sys.path auto-detection as the arm controller).
3. Open `webots/worlds/humanoid_world.wbt` in Webots. **Read its header
   comment first** -- it's an honestly-labeled, unverified placeholder.
4. Set the robot's controller to `humanoid_controller`, press Play.
5. Run `python main_humanoid.py` separately.

Legs are deliberately not driven (`config.ACTIVE_HUMANOID_JOINTS`
excludes them) -- balance/gait control is a genuinely different, much
harder problem (walking humanoids need a real controller: ZMP/inverted-
pendulum balance, footstep planning, etc.) that copying arm-angle
geometry does not solve. `config.HUMANOID_JOINTS` already has hip/knee/
ankle entries prepared for when you're ready to tackle that separately.

## ROS 2

Disabled by default (`config.ROS2_ENABLED = False`). If you have a full
ROS 2 distribution installed, `communication/ros_controller.py` will
attempt to publish humanoid commands as JSON-encoded `std_msgs/String` on
`/humanoid/command`; alongside, not instead of, UDP. This path has not
been run against a real ROS 2 graph in this environment -- treat it as
implemented-but-unverified.

## Running

```bash
python main_humanoid.py
```

Same startup safety as Part 1: joints start at 0 and stay there until a
connected, confident (or mirror/manual, which don't need gesture
confidence) command clears the safety controller.

---

# Part 3: Air Mouse + Air Paint

Same hand tracking, new party tricks. Entry point: `main_mouse_paint.py`
(everything lives in `apps/`; the arm and humanoid code are untouched).

```bash
python main_mouse_paint.py                  # starts in PAINT mode
python main_mouse_paint.py --mode mouse
python main_mouse_paint.py --live-mouse     # actually drive the real cursor (see safety)
```

**Switch modes** by holding THREE fingers (index+middle+ring) up for ~1.2 s, or press `1` / `2`.

## Air Paint

| Gesture | Action |
|---|---|
| Index finger only | **Draw** |
| Index + middle (peace) | **Select** -- hover a toolbar button (~0.45 s) to press it |
| Open palm | **Erase** (big circle follows your palm) |
| Fist / anything else | Lift the brush |

Toolbar: 6 colors, **RGB** (rainbow stroke), **SYM** (cycles OFF -> MIRROR x2 -> QUAD x4 ->
KALEIDO x12 -> MANDALA x24), **S-/S+** (brush size), **UNDO**, **CLEAR** (needs a longer 1.2 s
dwell so you can't wipe your art by accident), **SAVE** (`paintings/painting_001.png`, ...).
Keys: `C` clear, `U` undo, `S` save, `Y` symmetry, `R` rainbow, `+`/`-` size.
Neon glow and spark particles are on by default (`PAINT_GLOW`, `PAINT_PARTICLES`).

## Air Mouse

| Gesture | Action |
|---|---|
| Move index fingertip | Move cursor (One-Euro smoothed) |
| Quick thumb+index pinch | Left click |
| Pinch and **hold** (0.4 s) | Drag; release to drop |
| Thumb+middle pinch | Right click |
| Peace sign, move hand up/down | Scroll |
| Fist | Pause |

Two details that decide whether an air mouse is usable: **click-freeze** (the cursor locks the
moment your fingers start closing, so the click lands where you aimed, not where your fingertip
drifted to) and **pinch hysteresis** (engages below 0.25, releases above 0.40, so a borderline
pinch can't machine-gun clicks). All thresholds are in `config.py` (`MOUSE_*`, `PAINT_*`).

### Mouse safety -- please read

- It **starts in DRY-RUN**: the whole pipeline runs and the HUD shows what it would do, but
  your real cursor is never touched.
- `M` (or `--live-mouse`) goes LIVE. Needs `pip install pyautogui`. If that isn't available it
  falls back to dry-run and tells you why, rather than pretending.
- **Panic exit:** in LIVE mode, hold a **fist for 1.5 s** to drop back to DRY-RUN. Use this
  instead of the `Q` key -- once the air mouse is clicking other windows, the camera window
  loses keyboard focus.
- Losing sight of your hand mid-drag releases the button immediately; mode switches and
  quitting release it too; pyautogui's corner-failsafe is enabled.
- macOS: grant Accessibility permission to your terminal. Linux: needs X11 (Wayland generally
  blocks synthetic input).

## What's verified

69 new tests (127 total), run in a venv matching your stated environment (Python 3.12,
NumPy 1.26.4, OpenCV 4.11, MediaPipe 0.10.21). The tests drive synthetic hands through the real
feature extractor into the real mouse/paint logic, and I mutation-tested the safety behaviors
(break the code on purpose, confirm a test fails): drag-release on hand loss, click-freeze,
hysteresis, fist-pause, panic exit, shutdown release, CLEAR's longer dwell, the tracking-jump guard,
symmetry math, and more. **That process caught two genuinely weak tests of mine** (a "jump guard"
test that never triggered the guard, and a stale-bytecode artifact), both now fixed.

**Not verified here -- needs you:** (1) real webcam hands: the pose rules are distance-based and
rotation-tolerant (tested to +/-40 degrees), but I have not seen them on an actual hand, so expect
to nudge `EXTENDED_RATIO` in `apps/hand_pose.py` or the `MOUSE_PINCH_*` thresholds; (2) the real
`pyautogui` backend, since the sandbox has no desktop -- the live path is a thin wrapper
(`move/mouseDown/mouseUp/click/scroll`) that has never actually moved a cursor; (3) overall *feel*
(smoothing, dwell times). I did render a real kaleidoscope frame through the full paint stack to
check it visually.
