"""
robotics/safety_manager.py
Every commanded position and every joint-angle solution passes through
this module before it reaches the robot. Nothing else in the system is
trusted to enforce safety on its own -- perception can be wrong, IK can
be wrong, communication can drop a packet, and none of that should ever
translate into uncontrolled robot movement.

This module is pure logic (no camera, no sockets, no Webots), which is
what makes it fully unit-testable -- see tests/test_safety_manager.py.
"""

import time
from dataclasses import dataclass, field
from typing import List, Optional

import config as C


SAFE = "SAFE"
WORKSPACE_VIOLATION = "WORKSPACE_BOUNDARY"
JOINT_LIMIT_VIOLATION = "JOINT_LIMIT"
VELOCITY_LIMIT = "VELOCITY_LIMIT"
EMERGENCY_STOP = "EMERGENCY_STOP"
COLLISION_RISK = "COLLISION_RISK"
COMMS_TIMEOUT = "COMMS_TIMEOUT"


@dataclass
class SafetyStatus:
    ok: bool
    reason: str
    warnings: List[str] = field(default_factory=list)


class SafetyManager:
    def __init__(self, safety_box=None, joint_limits=None,
                 max_joint_rate=None, max_acceleration=None,
                 max_step_displacement=None):
        self.safety_box = safety_box or C.SAFETY_BOX
        self.joint_limits = joint_limits or C.JOINT_LIMITS
        self.max_joint_rate = max_joint_rate or C.MAX_JOINT_RATE
        self.max_acceleration = max_acceleration or C.MAX_ACCELERATION
        self.max_step_displacement = max_step_displacement or C.MAX_STEP_DISPLACEMENT

        self._estopped = False
        self._estop_clear_started_at = None
        self._prev_velocities = None
        self.collision_provider = None  # optional callable(trajectory) -> bool safe

    # ------------------------------------------------------------ Workspace
    def clamp_workspace(self, x, y, z):
        box = self.safety_box
        cx = min(max(x, box["x"][0]), box["x"][1])
        cy = min(max(y, box["y"][0]), box["y"][1])
        cz = min(max(z, box["z"][0]), box["z"][1])
        clamped = (cx != x) or (cy != y) or (cz != z)
        return (cx, cy, cz), clamped

    # -------------------------------------------------------------- Joints
    def check_joint_limits(self, angles):
        violations = []
        for i, (angle, (lo, hi)) in enumerate(zip(angles, self.joint_limits)):
            if angle < lo or angle > hi:
                violations.append(i)
        return violations

    def clamp_joint_limits(self, angles):
        clamped = []
        for angle, (lo, hi) in zip(angles, self.joint_limits):
            clamped.append(min(max(angle, lo), hi))
        return tuple(clamped)

    # --------------------------------------------------------- Velocity/accel
    def limit_velocity(self, prev_angles, target_angles, dt):
        max_delta = self.max_joint_rate * dt
        out = []
        limited = False
        for prev, target in zip(prev_angles, target_angles):
            delta = target - prev
            if delta > max_delta:
                delta = max_delta
                limited = True
            elif delta < -max_delta:
                delta = -max_delta
                limited = True
            out.append(prev + delta)
        return tuple(out), limited

    def limit_acceleration(self, prev_angles, prev_prev_angles, target_angles, dt):
        """
        Caps the change in velocity (not just velocity itself) between
        consecutive steps, so the arm can't instantly jump from
        stationary to max speed even within the per-step velocity cap.
        """
        if prev_prev_angles is None:
            return self.limit_velocity(prev_angles, target_angles, dt)

        max_dv = self.max_acceleration * dt
        out = []
        for prev, prev_prev, target in zip(prev_angles, prev_prev_angles, target_angles):
            prev_vel = (prev - prev_prev) / dt
            desired_vel = (target - prev) / dt
            dv = desired_vel - prev_vel
            if dv > max_dv:
                desired_vel = prev_vel + max_dv
            elif dv < -max_dv:
                desired_vel = prev_vel - max_dv
            out.append(prev + desired_vel * dt)
        return self.limit_velocity(prev_angles, tuple(out), dt)

    # ------------------------------------------------------------- Collision
    def set_collision_provider(self, fn):
        """fn: callable(trajectory) -> bool (True = safe). Optional; if
        never set, check_collision() always passes -- Webots collision
        data is an optional integration, not a hard dependency."""
        self.collision_provider = fn

    def check_collision(self, trajectory):
        if self.collision_provider is None:
            return True
        try:
            return bool(self.collision_provider(trajectory))
        except Exception:
            # A broken collision provider must never itself become a
            # reason the robot behaves unpredictably -- fail safe by
            # treating an error as "unsafe", not by crashing the loop.
            return False

    # --------------------------------------------------------------- E-stop
    def trigger_estop(self):
        self._estopped = True
        self._estop_clear_started_at = None

    def is_estopped(self):
        return self._estopped

    def update_estop_clear(self, open_palm_detected, hold_required=None):
        """
        Call every frame while e-stopped. Clears the e-stop only after
        an open palm has been detected continuously for hold_required
        seconds, so a fast, accidental gesture can't clear it.
        """
        hold_required = hold_required if hold_required is not None else C.ESTOP_UNLOCK_HOLD_S
        if not self._estopped:
            return
        if not open_palm_detected:
            self._estop_clear_started_at = None
            return
        if self._estop_clear_started_at is None:
            self._estop_clear_started_at = time.time()
        elif time.time() - self._estop_clear_started_at >= hold_required:
            self._estopped = False
            self._estop_clear_started_at = None

    # ---------------------------------------------------------------- Comms
    def check_heartbeat(self, last_heartbeat_time, timeout=None):
        timeout = timeout if timeout is not None else C.UDP_TIMEOUT_S
        if last_heartbeat_time is None:
            return False
        return (time.time() - last_heartbeat_time) <= timeout

    # ---------------------------------------------------------------- Evaluate
    def evaluate_target(self, x, y, z):
        """Workspace-only check on a raw target, before IK runs."""
        warnings = []
        if self._estopped:
            return SafetyStatus(False, EMERGENCY_STOP, warnings), (x, y, z)
        (cx, cy, cz), clamped = self.clamp_workspace(x, y, z)
        if clamped:
            warnings.append("Workspace boundary reached")
        return SafetyStatus(True, SAFE, warnings), (cx, cy, cz)

    def evaluate_angles(self, angles):
        """Joint-limit check on an IK solution, before it's sent to motors."""
        warnings = []
        if self._estopped:
            return SafetyStatus(False, EMERGENCY_STOP, warnings), angles
        violations = self.check_joint_limits(angles)
        if violations:
            warnings.append(f"Joint limit violation on joints {violations}")
            angles = self.clamp_joint_limits(angles)
        return SafetyStatus(True, SAFE, warnings), angles
