"""
robotics/humanoid_controller.py
Defines the humanoid's joint layout and a HumanoidState holding current
joint angles + hand open/close state. This is pure data/bookkeeping --
robotics/joint_controller.py applies safety-limited motion to it, and
webots/controllers/humanoid_controller/humanoid_controller.py is what
actually drives Webots motors from it.
"""

from dataclasses import dataclass, field
from typing import Dict

import config as C


def neutral_pose() -> Dict[str, float]:
    """All active joints at 0 rad (arms relaxed at sides). Hand open/close
    is tracked separately (HumanoidState.left_hand/right_hand below) since
    it isn't a joint-limited arm/neck/torso angle."""
    return {name: 0.0 for name in C.ACTIVE_HUMANOID_JOINTS}


@dataclass
class HumanoidState:
    joint_angles: Dict[str, float] = field(default_factory=neutral_pose)
    left_hand: float = 0.0    # 0.0 open .. 1.0 closed
    right_hand: float = 0.0

    def clamp_to_limits(self, limits=None):
        limits = limits or C.HUMANOID_JOINT_LIMITS
        for name, angle in self.joint_angles.items():
            if name in limits:
                lo, hi = limits[name]
                self.joint_angles[name] = min(max(angle, lo), hi)
        self.left_hand = min(max(self.left_hand, 0.0), 1.0)
        self.right_hand = min(max(self.right_hand, 0.0), 1.0)

    def as_dict(self):
        return {
            "joint_angles": dict(self.joint_angles),
            "left_hand": self.left_hand,
            "right_hand": self.right_hand,
        }
