"""
robotics/safety_controller.py
Humanoid-specific safety layer, built on the same principles already
verified in robotics/safety_manager.py (workspace/joint limits,
hold-to-clear e-stop) but generalized to N named joints and adding the
watchdog behavior this spec calls for explicitly:

    camera tracking lost       -> STOP ROBOT
    gesture confidence too low -> IGNORE COMMAND (not "best guess")

Every joint-angle dict passes through here before reaching JointController.
"""

import time

import config as C

SAFE = "SAFE"
EMERGENCY_STOP = "EMERGENCY_STOP"
TRACKING_LOST = "TRACKING_LOST"
LOW_CONFIDENCE = "LOW_CONFIDENCE"


class SafetyController:
    def __init__(self, joint_limits=None, camera_lost_timeout=None, confidence_threshold=None):
        self.joint_limits = joint_limits or C.HUMANOID_JOINT_LIMITS
        self.camera_lost_timeout = camera_lost_timeout if camera_lost_timeout is not None else C.CAMERA_LOST_TIMEOUT_S
        self.confidence_threshold = confidence_threshold if confidence_threshold is not None else C.GESTURE_CONFIDENCE_THRESHOLD

        self._estopped = False
        self._estop_clear_started_at = None
        self._last_frame_time = None

    # ---------------------------------------------------------------- Watchdog
    def frame_received(self, now=None):
        """Call every frame a camera image (regardless of whether a hand/pose
        was detected in it) is successfully captured."""
        self._last_frame_time = now if now is not None else time.time()

    def is_tracking_lost(self, now=None):
        now = now if now is not None else time.time()
        if self._last_frame_time is None:
            return True
        return (now - self._last_frame_time) > self.camera_lost_timeout

    # ------------------------------------------------------------- Confidence
    def command_allowed(self, confidence):
        return confidence >= self.confidence_threshold

    # ----------------------------------------------------------------- E-stop
    def trigger_estop(self):
        self._estopped = True
        self._estop_clear_started_at = None

    def is_estopped(self):
        return self._estopped

    def update_estop_clear(self, open_palm_detected, hold_required=None):
        hold_required = hold_required if hold_required is not None else C.ESTOP_UNLOCK_HOLD_S
        if not self._estopped:
            return
        if not open_palm_detected:
            self._estop_clear_started_at = None
            return
        if self._estop_clear_started_at is None:
            self._estop_clear_started_at = time.time()
        elif time.time() - self._estop_clear_started_at >= hold_required:
            self._estopped = False
            self._estop_clear_started_at = None

    # -------------------------------------------------------------- Evaluate
    def evaluate(self, joint_angles: dict, confidence: float = 1.0, now=None):
        """
        Returns (status_str, safe_angles). safe_angles is joint_angles
        clamped to limits when status is SAFE; when unsafe, callers should
        NOT apply safe_angles -- they should hold the previous commanded
        pose instead (this function doesn't know the previous pose, that's
        JointController's job -- see main_humanoid.py for how they compose).
        """
        if self._estopped:
            return EMERGENCY_STOP, None
        if self.is_tracking_lost(now):
            return TRACKING_LOST, None
        if not self.command_allowed(confidence):
            return LOW_CONFIDENCE, None

        clamped = {}
        for name, angle in joint_angles.items():
            if name in self.joint_limits:
                lo, hi = self.joint_limits[name]
                clamped[name] = min(max(angle, lo), hi)
            else:
                clamped[name] = angle
        return SAFE, clamped
