"""
robotics/trajectory.py
Two independent pieces of trajectory generation:

1. catmull_rom_spline() -- turns a sparse list of recorded waypoints into
   a smooth path for playback, instead of the arm snapping between
   recorded poses.

2. generate_joint_trajectory() -- given a start and end joint
   configuration, produces a velocity- and acceleration-limited sequence
   of intermediate configurations (a simple trapezoidal-ish profile via
   direct numerical integration), used for point-to-point moves where a
   spline through only two points wouldn't add anything.

Both are pure math with no dependencies beyond the standard library,
which is what makes them fully unit-testable.
"""


def catmull_rom_spline(waypoints, samples_per_segment=15):
    """
    waypoints: list of equal-length tuples, e.g. (x, y, z, grip).
    Needs at least 2 waypoints; endpoints are duplicated to provide the
    extra control points Catmull-Rom needs.
    """
    if len(waypoints) < 2:
        return list(waypoints)

    def point(p0, p1, p2, p3, t):
        t2, t3 = t * t, t * t * t
        out = []
        for i in range(len(p1)):
            a, b, c, d = p0[i], p1[i], p2[i], p3[i]
            out.append(0.5 * (
                (2 * b) + (-a + c) * t
                + (2 * a - 5 * b + 4 * c - d) * t2
                + (-a + 3 * b - 3 * c + d) * t3
            ))
        return tuple(out)

    pts = [waypoints[0]] + list(waypoints) + [waypoints[-1]]
    result = []
    for i in range(1, len(pts) - 2):
        p0, p1, p2, p3 = pts[i - 1], pts[i], pts[i + 1], pts[i + 2]
        for s in range(samples_per_segment):
            result.append(point(p0, p1, p2, p3, s / samples_per_segment))
    result.append(waypoints[-1])
    return result


def generate_joint_trajectory(start_angles, end_angles, max_rate, max_accel, dt):
    """
    Returns a list of joint-angle tuples from start_angles to end_angles,
    respecting max_rate (rad/s) and max_accel (rad/s^2) per joint, via
    simple forward numerical integration (accelerate, cruise, decelerate).
    Terminates once all joints are within a small tolerance of the target
    or after a generous iteration cap (prevents an infinite loop if
    max_rate/max_accel are pathologically small).
    """
    n = len(start_angles)
    positions = list(start_angles)
    velocities = [0.0] * n
    trajectory = [tuple(positions)]

    tol = 1e-3
    max_steps = 5000

    for _ in range(max_steps):
        done = True
        for i in range(n):
            remaining = end_angles[i] - positions[i]
            if abs(remaining) > tol:
                done = False

            # Decelerate if we'd overshoot at current velocity
            stopping_distance = (velocities[i] ** 2) / (2 * max_accel) if max_accel > 0 else 0
            direction = 1.0 if remaining > 0 else -1.0

            if abs(remaining) <= stopping_distance:
                target_vel = 0.0
            else:
                target_vel = direction * max_rate

            dv = target_vel - velocities[i]
            max_dv = max_accel * dt
            if dv > max_dv:
                dv = max_dv
            elif dv < -max_dv:
                dv = -max_dv
            velocities[i] += dv

            step = velocities[i] * dt
            if abs(step) > abs(remaining):
                step = remaining
                velocities[i] = 0.0
            positions[i] += step

        trajectory.append(tuple(positions))
        if done:
            break

    return trajectory
