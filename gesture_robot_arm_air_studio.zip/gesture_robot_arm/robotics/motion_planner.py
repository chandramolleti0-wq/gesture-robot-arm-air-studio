"""
robotics/motion_planner.py
Implements the full pipeline from the architecture spec:

    Target Position -> Workspace Check -> IK -> Joint Limit Check ->
    Collision/Safety Check -> Velocity Limiting -> Acceleration Limiting

No raw hand-derived coordinate ever reaches the robot without passing
through every one of these stages. Each stage is independently testable
(robotics/safety_manager.py, robotics/ik_solver*.py) and this module's
job is purely to sequence them correctly -- see tests/test_motion_planner.py.
"""

from dataclasses import dataclass, field
from typing import Optional, Tuple

from robotics.ik_solver import solve_ik_diagnostic
from robotics.ik_solver_dls import solve_ik_dls_diagnostic
from robotics.safety_manager import SafetyManager, SAFE, EMERGENCY_STOP
import config as C


@dataclass
class PlanResult:
    angles: tuple
    ik_success: bool
    ik_error: float
    ik_solver_used: str
    distance_to_singularity: float
    safe: bool
    reason: str
    warnings: list = field(default_factory=list)


class MotionPlanner:
    def __init__(self, safety_manager: SafetyManager, l1=None, l2=None, l3=None, solver_mode=None):
        self.safety = safety_manager
        self.l1 = l1 or C.L1
        self.l2 = l2 or C.L2
        self.l3 = l3 or C.L3
        self.solver_mode = solver_mode or C.IK_SOLVER

        self._prev_angles = [0.0, 0.0, 0.0, 0.0]
        self._prev_prev_angles = None
        self._prev_ik_guess = [0.0, 0.0, 0.0]

    def _solve_ik(self, x, y, z, wrist_pitch_offset):
        if self.solver_mode == "dls":
            result = solve_ik_dls_diagnostic(
                x, y, z, self.l1, self.l2, self.l3, wrist_pitch_offset,
                initial_guess=self._prev_ik_guess,
            )
        elif self.solver_mode == "auto":
            result = solve_ik_diagnostic(x, y, z, self.l1, self.l2, self.l3, wrist_pitch_offset)
            if (not result.success) or result.distance_to_singularity < C.IK_SINGULARITY_MARGIN:
                result = solve_ik_dls_diagnostic(
                    x, y, z, self.l1, self.l2, self.l3, wrist_pitch_offset,
                    initial_guess=self._prev_ik_guess,
                )
        else:
            result = solve_ik_diagnostic(x, y, z, self.l1, self.l2, self.l3, wrist_pitch_offset)

        self._prev_ik_guess = list(result.angles[:3])
        return result

    def plan(self, target_xyz, wrist_pitch_offset=0.0, dt=None, speed_scale=1.0):
        """
        target_xyz: (x, y, z) in meters, already the arm-space target
            (i.e. after hand->robot mapping, see control/gesture_mapper.py).
        speed_scale: multiplier on max joint rate/accel, e.g. for precision mode.
        Returns a PlanResult; on any safety failure, `angles` is the
        previous safe angles unchanged (the arm holds position).
        """
        dt = dt if dt is not None else (C.TIME_STEP_MS / 1000.0)
        warnings = []

        if self.safety.is_estopped():
            return PlanResult(
                tuple(self._prev_angles), False, 0.0, "none", 0.0,
                False, EMERGENCY_STOP, warnings,
            )

        x, y, z = target_xyz
        target_status, (cx, cy, cz) = self.safety.evaluate_target(x, y, z)
        warnings += target_status.warnings

        ik_result = self._solve_ik(cx, cy, cz, wrist_pitch_offset)

        angle_status, clamped_angles = self.safety.evaluate_angles(ik_result.angles)
        warnings += angle_status.warnings

        collision_safe = self.safety.check_collision([clamped_angles])
        if not collision_safe:
            warnings.append("COLLISION RISK")
            return PlanResult(
                tuple(self._prev_angles), ik_result.success, ik_result.error,
                ik_result.solver_used, ik_result.distance_to_singularity,
                False, "COLLISION_RISK", warnings,
            )

        effective_rate = self.safety.max_joint_rate * speed_scale
        effective_accel = self.safety.max_acceleration * speed_scale
        original_rate, original_accel = self.safety.max_joint_rate, self.safety.max_acceleration
        self.safety.max_joint_rate, self.safety.max_acceleration = effective_rate, effective_accel
        try:
            final_angles, _ = self.safety.limit_acceleration(
                tuple(self._prev_angles), self._prev_prev_angles, clamped_angles, dt
            )
        finally:
            self.safety.max_joint_rate, self.safety.max_acceleration = original_rate, original_accel

        self._prev_prev_angles = tuple(self._prev_angles)
        self._prev_angles = list(final_angles)

        return PlanResult(
            final_angles, ik_result.success, ik_result.error, ik_result.solver_used,
            ik_result.distance_to_singularity, True, SAFE, warnings,
        )

    def reset(self, angles=None):
        self._prev_angles = list(angles) if angles else [0.0, 0.0, 0.0, 0.0]
        self._prev_prev_angles = None
        self._prev_ik_guess = self._prev_angles[:3]
