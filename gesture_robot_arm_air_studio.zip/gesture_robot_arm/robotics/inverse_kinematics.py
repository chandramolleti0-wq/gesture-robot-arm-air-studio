"""
robotics/inverse_kinematics.py
Thin per-arm wrapper around the already-tested closed-form solver in
robotics/ik_solver.py, used by GESTURE mode: when a hand's position
should make the corresponding arm *reach toward a point*, as opposed to
MIRROR mode (control/motion_mapper.py), which copies the human's actual
joint angles directly rather than solving for a target position.

No new kinematics math here -- this only adapts the existing, verified
2-link solver's calling convention to the humanoid's named-joint dicts.
"""

from robotics.ik_solver import solve_ik
import config as C


class ArmIK:
    def __init__(self, shoulder_joint, elbow_joint, wrist_joint,
                 l1=None, l2=None, l3=None):
        self.shoulder_joint = shoulder_joint
        self.elbow_joint = elbow_joint
        self.wrist_joint = wrist_joint
        self.l1 = l1 or C.HUMANOID_ARM_L1
        self.l2 = l2 or C.HUMANOID_ARM_L2
        self.l3 = l3 or C.HUMANOID_ARM_L3

    def solve(self, x, y, z, wrist_pitch_offset=0.0):
        """
        x, y, z: target hand position relative to the shoulder, meters.
        Returns {shoulder_joint: angle, elbow_joint: angle, wrist_joint: angle}.
        Reuses ik_solver.solve_ik's (theta0, theta1, theta2, theta3) output;
        theta0 (base yaw) is folded into the shoulder angle for this
        single-plane-per-arm humanoid model rather than a separate joint.
        """
        theta0, theta1, theta2, theta3 = solve_ik(x, y, z, self.l1, self.l2, self.l3, wrist_pitch_offset)
        return {
            self.shoulder_joint: theta1,
            self.elbow_joint: theta2,
            self.wrist_joint: theta3,
        }


LEFT_ARM_IK = ArmIK("left_shoulder", "left_elbow", "left_wrist")
RIGHT_ARM_IK = ArmIK("right_shoulder", "right_elbow", "right_wrist")
