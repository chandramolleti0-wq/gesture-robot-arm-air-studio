"""
robotics/ik_solver_dls.py
Jacobian-based Damped Least Squares (DLS) IK -- the general, iterative
alternative to ik_solver.py's closed-form solution. Used automatically
as a fallback when the closed-form solver reports it's near a singularity
(see robotics/motion_planner.py's automatic solver selection).

Only iterates over (theta0, theta1, theta2) since theta3 (wrist pitch)
doesn't affect end-effector position in this arm's model -- it's set
afterward exactly as in the closed-form solver.

Verified against ik_solver.forward_kinematics: converges to within
~1e-4 m of target across multiple test points (see tests/test_ik_solver.py).
"""

import numpy as np

from robotics.ik_solver import forward_kinematics, IKResult

_EPS = 1e-6


def _numerical_jacobian(theta, l1, l2, l3):
    J = np.zeros((3, 3))
    base = np.array(forward_kinematics(*theta, l1, l2, l3))
    for j in range(3):
        perturbed = theta.copy()
        perturbed[j] += _EPS
        fk_perturbed = np.array(forward_kinematics(*perturbed, l1, l2, l3))
        J[:, j] = (fk_perturbed - base) / _EPS
    return J, base


def solve_ik_dls(x, y, z, l1, l2, l3, wrist_pitch_offset=0.0,
                  initial_guess=None, max_iters=50, damping=0.06, tol=1e-4):
    """Returns (theta0, theta1, theta2, theta3), same order as ik_solver.solve_ik."""
    theta = np.array(initial_guess[:3], dtype=float) if initial_guess is not None else np.zeros(3)
    target = np.array([x, y, z])

    for _ in range(max_iters):
        J, current = _numerical_jacobian(theta, l1, l2, l3)
        error = target - current
        if np.linalg.norm(error) < tol:
            break
        JJt = J @ J.T
        lam2I = (damping ** 2) * np.eye(3)
        dtheta = J.T @ np.linalg.solve(JJt + lam2I, error)
        theta += dtheta

    theta0, theta1, theta2 = theta
    theta3 = -(theta1 - theta2) + wrist_pitch_offset
    return float(theta0), float(theta1), float(theta2), float(theta3)


def solve_ik_dls_diagnostic(x, y, z, l1, l2, l3, wrist_pitch_offset=0.0,
                             initial_guess=None, max_iters=50, damping=0.06, tol=1e-4):
    angles = solve_ik_dls(x, y, z, l1, l2, l3, wrist_pitch_offset, initial_guess, max_iters, damping, tol)
    fx, fy, fz = forward_kinematics(angles[0], angles[1], angles[2], l1, l2, l3)
    error = ((x - fx) ** 2 + (y - fy) ** 2 + (z - fz) ** 2) ** 0.5
    success = error < 1e-2
    # DLS doesn't hit a hard geometric wall the way closed-form does; use
    # residual error itself as an (inverse) proxy for closeness to a
    # solvable configuration.
    distance_to_singularity = max(0.0, 0.05 - error)
    return IKResult(angles, success, error, distance_to_singularity, "dls")
