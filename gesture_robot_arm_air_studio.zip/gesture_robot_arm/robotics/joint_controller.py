"""
robotics/joint_controller.py
Generalizes the arm project's fixed-4-joint velocity/acceleration
limiting (robotics/safety_manager.py's limit_velocity/limit_acceleration)
to an arbitrary named set of joints, since the humanoid has 9+ active
joints rather than a fixed 4-tuple. Same underlying math, dict-keyed.
"""

import config as C


class JointController:
    def __init__(self, joint_names, max_rate=None, max_accel=None):
        self.joint_names = list(joint_names)
        self.max_rate = max_rate if max_rate is not None else C.HUMANOID_MAX_JOINT_RATE
        self.max_accel = max_accel if max_accel is not None else C.HUMANOID_MAX_ACCELERATION
        self._prev = {name: 0.0 for name in self.joint_names}
        self._prev_prev = None

    def limit_velocity(self, target: dict, dt: float) -> dict:
        max_delta = self.max_rate * dt
        out = {}
        for name in self.joint_names:
            prev = self._prev.get(name, 0.0)
            tgt = target.get(name, prev)
            delta = tgt - prev
            if delta > max_delta:
                delta = max_delta
            elif delta < -max_delta:
                delta = -max_delta
            out[name] = prev + delta
        return out

    def limit_acceleration(self, target: dict, dt: float) -> dict:
        if self._prev_prev is None:
            result = self.limit_velocity(target, dt)
            self._prev_prev = dict(self._prev)
            self._prev = result
            return result

        max_dv = self.max_accel * dt
        intermediate = {}
        for name in self.joint_names:
            prev = self._prev.get(name, 0.0)
            prev_prev = self._prev_prev.get(name, 0.0)
            tgt = target.get(name, prev)
            prev_vel = (prev - prev_prev) / dt
            desired_vel = (tgt - prev) / dt
            dv = desired_vel - prev_vel
            if dv > max_dv:
                desired_vel = prev_vel + max_dv
            elif dv < -max_dv:
                desired_vel = prev_vel - max_dv
            intermediate[name] = prev + desired_vel * dt

        result = self.limit_velocity(intermediate, dt)
        self._prev_prev = dict(self._prev)
        self._prev = result
        return result

    def current(self):
        return dict(self._prev)

    def reset(self, angles=None):
        self._prev = dict(angles) if angles else {name: 0.0 for name in self.joint_names}
        self._prev_prev = None
