"""
robotics/ik_solver.py
Closed-form (analytical) inverse kinematics for the 4-DOF arm, plus a
forward-kinematics function shared with robotics/ik_solver_dls.py so
both solvers agree on the same arm geometry.

  theta0: base yaw
  theta1: shoulder pitch
  theta2: elbow pitch (interior bend angle)
  theta3: wrist pitch (kept level, plus any orientation offset)

Verified: solve_ik() -> forward_kinematics() round-trips to within
floating-point error across multiple test points (see tests/test_ik_solver.py).
"""

import math


def forward_kinematics(theta0, theta1, theta2, l1, l2, l3):
    """Position-only FK (theta3/wrist pitch doesn't move end-effector position)."""
    r = l1 * math.cos(theta1) + l2 * math.cos(theta1 - theta2)
    z = l1 * math.sin(theta1) + l2 * math.sin(theta1 - theta2) + l3
    x = r * math.cos(theta0)
    y = r * math.sin(theta0)
    return x, y, z


class IKResult:
    """Diagnostics alongside the joint solution, per the safety/diagnostics spec."""

    def __init__(self, angles, success, error, distance_to_singularity, solver_used):
        self.angles = angles
        self.success = success
        self.error = error                              # meters, |target - FK(angles)|
        self.distance_to_singularity = distance_to_singularity  # meters of slack, smaller = closer to singular
        self.solver_used = solver_used


def solve_ik(x, y, z, l1, l2, l3, wrist_pitch_offset=0.0):
    """
    Closed-form solution via the law of cosines. O(1), exact for this
    link structure. Targets outside the reachable annulus are clamped
    to the nearest reachable pose rather than raising -- callers that
    need to know whether clamping happened should use solve_ik_diagnostic().
    """
    theta0 = math.atan2(y, x)

    r = math.hypot(x, y)
    z_eff = z - l3
    d = math.hypot(r, z_eff)

    d_clamped = min(d, l1 + l2 - 1e-6)
    d_clamped = max(d_clamped, abs(l1 - l2) + 1e-6)

    cos_elbow = (l1 ** 2 + l2 ** 2 - d_clamped ** 2) / (2 * l1 * l2)
    cos_elbow = max(-1.0, min(1.0, cos_elbow))
    theta2 = math.pi - math.acos(cos_elbow)

    cos_a = (l1 ** 2 + d_clamped ** 2 - l2 ** 2) / (2 * l1 * d_clamped)
    cos_a = max(-1.0, min(1.0, cos_a))
    alpha = math.acos(cos_a)
    beta = math.atan2(z_eff, r)
    theta1 = beta + alpha

    theta3 = -(theta1 - theta2) + wrist_pitch_offset

    return theta0, theta1, theta2, theta3


def solve_ik_diagnostic(x, y, z, l1, l2, l3, wrist_pitch_offset=0.0):
    """
    Same solution as solve_ik(), plus an IKResult with success/error/
    singularity-distance, for the motion planner's IK diagnostics and
    automatic-solver-selection logic.
    """
    angles = solve_ik(x, y, z, l1, l2, l3, wrist_pitch_offset)
    fx, fy, fz = forward_kinematics(angles[0], angles[1], angles[2], l1, l2, l3)
    error = math.dist((x, y, z), (fx, fy, fz))

    r = math.hypot(x, y)
    d = math.hypot(r, z - l3)
    dist_to_outer = abs((l1 + l2) - d)
    dist_to_inner = abs(d - abs(l1 - l2))
    distance_to_singularity = min(dist_to_outer, dist_to_inner)

    success = error < 1e-3
    return IKResult(angles, success, error, distance_to_singularity, "closed_form")
