"""
train_classifier.py
Trains the gesture MLP with:
  - class balancing (weighted loss, since some gestures are naturally
    quicker to collect samples for than others)
  - a proper train/val/test split (test set touched only for the final
    reported metrics, never used for model selection)
  - confusion matrix, precision/recall/F1 per class
  - model versioning: saves to models/gesture_model_<version>.pt rather
    than overwriting a single file, so you can compare versions

Run from the project root: python train_classifier.py
Does NOT run automatically during normal robot operation -- training is
always a separate, deliberate step (per the spec's requirement).
"""

import csv
import json
import os

import numpy as np
import torch
import torch.nn as nn
from torch.utils.data import Dataset, DataLoader
from sklearn.model_selection import train_test_split
from sklearn.metrics import confusion_matrix, precision_recall_fscore_support, accuracy_score
from sklearn.utils.class_weight import compute_class_weight

from perception.feature_utils import augment, FEATURE_DIM
from perception.gesture_classifier_dl import GestureNet
import config as C


class GestureDataset(Dataset):
    def __init__(self, X, y, train, rng):
        self.X, self.y, self.train, self.rng = X, y, train, rng

    def __len__(self):
        return len(self.X)

    def __getitem__(self, idx):
        x = self.X[idx]
        if self.train:
            x = augment(x, self.rng)
        return torch.tensor(x, dtype=torch.float32), torch.tensor(self.y[idx], dtype=torch.long)


def load_dataset(path):
    X, labels = [], []
    with open(path) as f:
        reader = csv.reader(f)
        next(reader)
        for row in reader:
            X.append([float(v) for v in row[:63]])
            labels.append(row[63])
    return np.array(X, dtype=np.float32), labels


def main():
    if not os.path.exists(C.DATASET_PATH):
        print(f"ERROR: dataset not found at {C.DATASET_PATH}. Run collect_data.py first.")
        return

    X, raw_labels = load_dataset(C.DATASET_PATH)
    classes = sorted(set(raw_labels))
    label_to_idx = {c: i for i, c in enumerate(classes)}
    y = np.array([label_to_idx[l] for l in raw_labels], dtype=np.int64)

    print(f"Loaded {len(X)} samples across {len(classes)} classes: {classes}")
    counts = {c: raw_labels.count(c) for c in classes}
    print("Per-class counts:", counts)
    if min(counts.values()) < 20:
        print("WARNING: some classes have very few samples (<20) -- collect more with collect_data.py "
              "for reliable results, especially for that class.")

    # 70/15/15 train/val/test split, stratified so small classes aren't
    # accidentally left out of one split entirely.
    X_train, X_temp, y_train, y_temp = train_test_split(
        X, y, test_size=0.30, random_state=42, stratify=y)
    X_val, X_test, y_val, y_test = train_test_split(
        X_temp, y_temp, test_size=0.50, random_state=42, stratify=y_temp)
    print(f"Split: train={len(X_train)} val={len(X_val)} test={len(X_test)}")

    # Class balancing: weight the loss inversely proportional to class
    # frequency, so a common gesture (e.g. open_palm, easy to over-collect)
    # doesn't dominate the loss at the expense of rarer ones.
    class_weights = compute_class_weight("balanced", classes=np.arange(len(classes)), y=y_train)
    class_weights = torch.tensor(class_weights, dtype=torch.float32)

    rng = np.random.default_rng(42)
    train_ds = GestureDataset(X_train, y_train, train=True, rng=rng)
    val_ds = GestureDataset(X_val, y_val, train=False, rng=rng)
    test_ds = GestureDataset(X_test, y_test, train=False, rng=rng)
    train_loader = DataLoader(train_ds, batch_size=32, shuffle=True)
    val_loader = DataLoader(val_ds, batch_size=64)
    test_loader = DataLoader(test_ds, batch_size=64)

    model = GestureNet(len(classes))
    optimizer = torch.optim.Adam(model.parameters(), lr=1e-3, weight_decay=1e-4)
    criterion = nn.CrossEntropyLoss(weight=class_weights)

    os.makedirs(C.MODELS_DIR, exist_ok=True)
    model_path = os.path.join(C.MODELS_DIR, f"gesture_model_{C.MODEL_VERSION}.pt")

    best_val_acc = 0.0
    history = []
    for epoch in range(60):
        model.train()
        epoch_loss = 0.0
        for xb, yb in train_loader:
            optimizer.zero_grad()
            loss = criterion(model(xb), yb)
            loss.backward()
            optimizer.step()
            epoch_loss += loss.item()

        model.eval()
        correct, total = 0, 0
        with torch.no_grad():
            for xb, yb in val_loader:
                preds = model(xb).argmax(dim=1)
                correct += (preds == yb).sum().item()
                total += len(yb)
        val_acc = correct / max(total, 1)
        history.append({"epoch": epoch, "train_loss": epoch_loss / len(train_loader), "val_acc": val_acc})

        if val_acc >= best_val_acc:
            best_val_acc = val_acc
            torch.save(model.state_dict(), model_path)

        if epoch % 10 == 0 or epoch == 59:
            print(f"epoch {epoch:3d}  train_loss={epoch_loss/len(train_loader):.4f}  val_acc={val_acc:.3f}  best={best_val_acc:.3f}")

    # Final evaluation on the held-out test set, using the BEST checkpoint
    model.load_state_dict(torch.load(model_path, map_location="cpu"))
    model.eval()
    all_preds, all_true = [], []
    with torch.no_grad():
        for xb, yb in test_loader:
            preds = model(xb).argmax(dim=1)
            all_preds.extend(preds.tolist())
            all_true.extend(yb.tolist())

    test_acc = accuracy_score(all_true, all_preds)
    precision, recall, f1, support = precision_recall_fscore_support(
        all_true, all_preds, labels=range(len(classes)), zero_division=0)
    cm = confusion_matrix(all_true, all_preds, labels=range(len(classes)))

    print(f"\nTest accuracy: {test_acc:.3f}")
    print(f"{'class':<15} {'precision':>10} {'recall':>10} {'f1':>10} {'support':>8}")
    for i, c in enumerate(classes):
        print(f"{c:<15} {precision[i]:>10.3f} {recall[i]:>10.3f} {f1[i]:>10.3f} {support[i]:>8}")
    print("\nConfusion matrix (rows=true, cols=predicted):")
    print("      " + " ".join(f"{c[:5]:>6}" for c in classes))
    for i, row in enumerate(cm):
        print(f"{classes[i][:5]:>6}" + " ".join(f"{v:>6}" for v in row))

    with open(C.LABELS_PATH, "w") as f:
        json.dump(classes, f)

    metrics = {
        "model_version": C.MODEL_VERSION,
        "best_val_accuracy": best_val_acc,
        "test_accuracy": test_acc,
        "per_class": {
            classes[i]: {"precision": float(precision[i]), "recall": float(recall[i]),
                         "f1": float(f1[i]), "support": int(support[i])}
            for i in range(len(classes))
        },
        "confusion_matrix": cm.tolist(),
        "classes": classes,
        "training_history": history,
        "dataset_size": len(X),
        "per_class_counts": counts,
    }
    with open(C.TRAINING_METRICS_PATH, "w") as f:
        json.dump(metrics, f, indent=2)

    print(f"\nModel saved to {model_path}")
    print(f"Labels saved to {C.LABELS_PATH}")
    print(f"Training metrics saved to {C.TRAINING_METRICS_PATH}")


if __name__ == "__main__":
    main()
