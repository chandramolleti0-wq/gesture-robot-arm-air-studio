"""
config.py
Every tunable value in the system lives here. Nothing else in the project
should hard-code a threshold, range, or magic number that a user might
reasonably want to change -- if you find yourself doing that in another
file, it belongs here instead.
"""

# ---------------------------------------------------------------- Camera
CAMERA_INDEX = 0
CAMERA_WIDTH = 640
CAMERA_HEIGHT = 480
TARGET_FPS = 30

# ------------------------------------------------------------ Perception
MEDIAPIPE_MODEL_COMPLEXITY = 0
MEDIAPIPE_MIN_DETECTION_CONF = 0.6
MEDIAPIPE_MIN_TRACKING_CONF = 0.6
MAX_NUM_HANDS = 2

# ---------------------------------------------------- Gesture recognition
CLASSIFIER_MODE = "rule_based"          # "rule_based" or "deep_learning"
GESTURE_CONFIDENCE_THRESHOLD = 0.70      # normal commands
DL_CONFIDENCE_THRESHOLD = 0.75
DANGEROUS_GESTURE_CONFIDENCE_THRESHOLD = 0.90   # playback, mode change, reset
PINCH_THRESHOLD = 0.045
FINGER_CURL_MARGIN = 0.02

# Temporal confirmation (see control/command_manager.py)
GESTURE_VOTE_WINDOW = 8                  # frames of history for majority voting
GESTURE_MIN_DURATION_S = 0.25            # gesture must hold this long before it "counts"
GESTURE_DEBOUNCE_S = 0.35                # minimum time between two accepted commands
COMMAND_COOLDOWN = 0.5                   # extra cooldown after any accepted command
GESTURE_CONFIRMATION_TIME = 1.5          # window to repeat a gesture for dangerous-action confirm
ESTOP_UNLOCK_HOLD_S = 1.0                # open palm must be held this long to clear e-stop

# Motion gestures (swipe/move/rotate) are detected from wrist-position
# history rather than a single frame's hand shape.
MOTION_GESTURE_WINDOW_S = 0.6
SWIPE_MIN_DISPLACEMENT = 0.18            # normalized image-space displacement
ROTATE_MIN_ANGLE_DEG = 35.0

# --------------------------------------------------------------- Filter
FILTER_MIN_CUTOFF = 1.0
FILTER_BETA = 0.4
FILTER_D_CUTOFF = 1.0

GRIPPER_FILTER_ALPHA = 0.25              # separate, gentler smoothing just for gripper %

# ----------------------------------------------------- Hand -> robot map
# Hand workspace: normalized image-space box the calibrated hand moves within
HAND_WORKSPACE = {
    "x": (0.2, 0.8),
    "y": (0.2, 0.8),
    "z": (0.05, 0.20),   # hand-span depth proxy
}
# Robot workspace: meters, the arm's physical/simulated reach
ROBOT_WORKSPACE = {
    "x": (-0.3, 0.3),
    "y": (0.1, 0.5),
    "z": (0.05, 0.35),
}
MAPPING_DEAD_ZONE = 0.02      # normalized units near workspace center that don't move the arm
MAPPING_SENSITIVITY = 1.0     # >1 = amplified hand motion, <1 = damped

GRIPPER_MIN = 0.0             # 0% open .. 1.0 fully closed, robot-side units are separate
GRIPPER_MAX = 1.0

WRIST_PITCH_RANGE = (-0.6, 0.6)
WRIST_ROLL_RANGE = (-1.0, 1.0)

# ------------------------------------------------------------ Calibration
CALIBRATION_FILE = "data/calibration.json"
CALIBRATION_STEPS = [
    "center", "left", "right", "top", "bottom", "near", "far", "neutral_wrist",
]
CALIBRATION_HOLD_S = 1.0       # how long the user must hold still at each step

# ---------------------------------------------------------------- Arm
L1, L2, L3 = 0.25, 0.25, 0.10
MOTOR_NAMES = ["base_motor", "shoulder_motor", "elbow_motor", "wrist_motor"]
WRIST_ROLL_MOTOR_NAME = None
GRIPPER_MOTOR_NAMES = ["gripper_left", "gripper_right"]
GRIPPER_OPEN_POS = 0.04
GRIPPER_CLOSED_POS = 0.0

JOINT_LIMITS = [
    (-3.14, 3.14),   # base yaw
    (-1.57, 1.57),   # shoulder
    (0.0, 2.8),       # elbow
    (-2.0, 2.0),      # wrist
]

# --------------------------------------------------------------- IK
IK_SOLVER = "closed_form"     # "closed_form", "dls", or "auto"
DLS_DAMPING = 0.06
DLS_MAX_ITERS = 50
DLS_TOL = 1e-4
IK_SINGULARITY_MARGIN = 0.02   # meters of slack before closed-form is considered "near singular"

# ----------------------------------------------------------- Motion limits
MAX_JOINT_RATE = 3.0            # rad/s, normal mode
MAX_ACCELERATION = 8.0          # rad/s^2
PRECISION_SPEED_SCALE = 0.35    # multiplier applied to MAX_JOINT_RATE / sensitivity in precision mode
TIME_STEP_MS = 16

# ----------------------------------------------------------------- Safety
SAFETY_BOX = {
    "x": (-0.35, 0.35),
    "y": (0.05, 0.55),
    "z": (0.0, 0.40),
}
MAX_STEP_DISPLACEMENT = 0.05    # meters/step, hard cap regardless of velocity limiting upstream

# --------------------------------------------------------- Communication
UDP_HOST = "127.0.0.1"
UDP_PORT = 5005
UDP_TIMEOUT_S = 0.5              # if controller sees nothing this long, treat as comms loss
HEARTBEAT_INTERVAL_S = 0.2

# ------------------------------------------------------------- Recording
RECORDINGS_DIR = "recordings"
PLAYBACK_SAMPLES_PER_SEGMENT = 15
PLAYBACK_STEP_INTERVAL = 0.05
PLAYBACK_SPEED_OPTIONS = [0.25, 0.5, 0.75, 1.0, 1.5]

# ----------------------------------------------------------------- Logging
LOGS_DIR = "logs"
LOG_FORMAT = "csv"               # "csv" or "json"

# --------------------------------------------------------------------- ML
DATASET_PATH = "data/landmarks_dataset.csv"
MODELS_DIR = "models"
MODEL_VERSION = "v1"
LABELS_PATH = "models/labels.json"
TRAINING_METRICS_PATH = "models/training_metrics.json"

# ---------------------------------------------------------------- Voice
VOICE_CONTROL_ENABLED = False    # opt-in; module degrades gracefully if speech_recognition missing

# ------------------------------------------------------------- Dashboard
DASHBOARD_ENABLED = False        # opt-in; separate process, never required for the core controller
DASHBOARD_HOST = "127.0.0.1"
DASHBOARD_PORT = 8050

# =========================================================================
# HUMANOID EXTENSION
# Everything below extends the arm project to a full-body humanoid. It
# does not replace anything above -- main.py (arm) still works unchanged;
# main_humanoid.py is the new entry point that uses this section.
# =========================================================================

# ------------------------------------------------------- Body/pose tracking
POSE_ENABLED = True                    # MediaPipe Pose is optional; hands remain primary
POSE_MIN_DETECTION_CONF = 0.5
POSE_MIN_TRACKING_CONF = 0.5
POSE_MODEL_COMPLEXITY = 1

# ---------------------------------------------------------- Humanoid joints
# Maps our internal joint names to actual Webots motor device names.
# THESE DEFAULTS ARE PLACEHOLDERS matching the example world in
# webots/worlds/humanoid_world.wbt (a simple primitive-built humanoid).
# If you use Webots' built-in Nao (or another PROTO) instead, you must
# check its real joint device names yourself in the Webots scene tree --
# NAOqi's exact joint names (e.g. "LShoulderPitch") are SoftBank-specific
# internals that were not verified against a running Webots instance for
# this project, so they are deliberately not hard-coded here.
HUMANOID_JOINTS = {
    "neck_yaw": "neck_yaw_motor",
    "neck_pitch": "neck_pitch_motor",
    "left_shoulder": "left_shoulder_motor",
    "left_elbow": "left_elbow_motor",
    "left_wrist": "left_wrist_motor",
    "right_shoulder": "right_shoulder_motor",
    "right_elbow": "right_elbow_motor",
    "right_wrist": "right_wrist_motor",
    "left_hand": "left_hand_motor",       # open/close
    "right_hand": "right_hand_motor",     # open/close
    "torso_yaw": "torso_yaw_motor",
    # Prepared for future full-body expansion -- not actively driven yet.
    "left_hip": "left_hip_motor",
    "left_knee": "left_knee_motor",
    "left_ankle": "left_ankle_motor",
    "right_hip": "right_hip_motor",
    "right_knee": "right_knee_motor",
    "right_ankle": "right_ankle_motor",
}

# Joints actively driven by the current control modes (gesture/mirror).
# Legs are deliberately excluded -- balance/gait control is out of scope
# here and driving leg joints without it would be unsafe.
ACTIVE_HUMANOID_JOINTS = [
    "neck_yaw", "neck_pitch",
    "left_shoulder", "left_elbow", "left_wrist",
    "right_shoulder", "right_elbow", "right_wrist",
    "torso_yaw",
]

HUMANOID_JOINT_LIMITS = {
    "neck_yaw": (-1.57, 1.57), "neck_pitch": (-0.5, 0.5),
    "left_shoulder": (-2.0, 2.0), "left_elbow": (0.0, 2.5), "left_wrist": (-1.5, 1.5),
    "right_shoulder": (-2.0, 2.0), "right_elbow": (0.0, 2.5), "right_wrist": (-1.5, 1.5),
    "left_hand": (0.0, 1.0), "right_hand": (0.0, 1.0),
    "torso_yaw": (-1.0, 1.0),
    "left_hip": (-1.0, 1.0), "left_knee": (0.0, 2.0), "left_ankle": (-0.5, 0.5),
    "right_hip": (-1.0, 1.0), "right_knee": (0.0, 2.0), "right_ankle": (-0.5, 0.5),
}

# Per-arm link lengths (meters) for GESTURE mode's reaching IK (reuses the
# arm project's 2-link closed-form solver, one instance per arm).
HUMANOID_ARM_L1 = 0.20   # shoulder -> elbow
HUMANOID_ARM_L2 = 0.20   # elbow -> wrist
HUMANOID_ARM_L3 = 0.05   # wrist -> hand

HUMANOID_MAX_JOINT_RATE = 2.5      # rad/s
HUMANOID_MAX_ACCELERATION = 6.0    # rad/s^2

# ------------------------------------------------------------- Control modes
HUMANOID_MODE_DEFAULT = "GESTURE"   # GESTURE | MIRROR | MANUAL | EMERGENCY_STOP
MIRROR_DEAD_ZONE_DEG = 3.0          # ignore tiny human joint-angle jitter in mirror mode
MANUAL_JOINT_STEP = 0.05            # radians per keypress in MANUAL mode

# ------------------------------------------------------------------ Watchdog
CAMERA_LOST_TIMEOUT_S = 0.5     # no frame/landmarks this long -> STOP ROBOT
HUMANOID_UDP_TIMEOUT_S = 0.5

# --------------------------------------------------------------------- ROS 2
ROS2_ENABLED = False   # opt-in; communication/ros_controller.py degrades
                        # gracefully (falls back to UDP-only) if rclpy is
                        # not installed, exactly like voice_control.py does
                        # for speech_recognition.


# =========================================================================
# AIR MOUSE + AIR PAINT (apps/)
# Separate entry point: main_mouse_paint.py. Reuses perception.hand_tracker
# and perception.one_euro_filter; touches nothing in the arm/humanoid code.
# =========================================================================

# ---- Shared
MODE_SWITCH_POSE = "three"          # hold index+middle+ring up to toggle paint <-> mouse
MODE_SWITCH_HOLD_S = 1.2
POSE_DEBOUNCE_FRAMES = 3            # a pose must be seen this many frames in a row to count

# ---- Air mouse
MOUSE_ACTIVE_REGION = (0.20, 0.15, 0.80, 0.70)   # camera region (x0,y0,x1,y1) mapped to the whole screen
MOUSE_FILTER_MIN_CUTOFF = 1.2
MOUSE_FILTER_BETA = 8.0
MOUSE_PINCH_PRESS = 0.25            # thumb-index distance / palm size below this = pinched
MOUSE_PINCH_RELEASE = 0.40          # ...and above this = released (hysteresis stops flicker)
MOUSE_FREEZE_RATIO = 0.70           # cursor freezes while fingers approach, so the click lands where you aimed
MOUSE_DRAG_HOLD_S = 0.40            # pinch held this long becomes a drag instead of a click
MOUSE_RIGHT_CLICK_COOLDOWN_S = 0.6
MOUSE_SCROLL_GAIN = 40.0            # scroll clicks per unit of vertical palm travel (peace sign)
MOUSE_PANIC_POSE = "fist"           # hold to drop from LIVE back to DRY-RUN
MOUSE_PANIC_HOLD_S = 1.5

# ---- Air paint
PAINT_TOOLBAR_HEIGHT = 60
PAINT_COLORS = [                    # BGR
    (60, 60, 255), (0, 165, 255), (0, 255, 255),
    (80, 255, 80), (255, 200, 0), (255, 0, 200),
]
PAINT_BRUSH_SIZE = 6
PAINT_BRUSH_MIN, PAINT_BRUSH_MAX = 2, 40
PAINT_ERASER_RADIUS = 35
PAINT_DWELL_S = 0.45                # hover time over a toolbar button to press it
PAINT_CLEAR_DWELL_S = 1.2           # CLEAR needs a longer dwell so it can't be hit by accident
PAINT_UNDO_DEPTH = 15
PAINT_SAVE_DIR = "paintings"
PAINT_GLOW = True
PAINT_PARTICLES = True
PAINT_MAX_PARTICLES = 300
PAINT_RAINBOW_PX_PER_CYCLE = 700.0  # pixels of stroke length per full hue cycle
PAINT_FILTER_MIN_CUTOFF = 1.5
PAINT_FILTER_BETA = 6.0
PAINT_STROKE_JUMP_FRAC = 0.25       # a frame-to-frame jump bigger than this fraction of the width starts a new stroke
