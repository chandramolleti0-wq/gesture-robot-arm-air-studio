"""
main_mouse_paint.py
Air Mouse + Air Paint. Run with:

    python main_mouse_paint.py                 # starts in PAINT mode
    python main_mouse_paint.py --mode mouse
    python main_mouse_paint.py --live-mouse    # allow controlling the real cursor (see below)

Switching modes:  hold THREE fingers (index+middle+ring) for ~1.2 s, or press 1 / 2.

SAFETY MODEL for the mouse -- read this:
  * The mouse always starts in DRY-RUN: the full pipeline runs and the HUD shows
    what it would do, but your real cursor is never touched.
  * Press M (or start with --live-mouse) to go LIVE. This needs `pip install pyautogui`.
  * Panic exit: in LIVE mouse mode, hold a FIST for 1.5 s to drop back to DRY-RUN.
    (Use this rather than relying on the 'q' key -- once the air mouse is clicking
    other windows, the camera window loses keyboard focus.)
  * pyautogui's own failsafe is on: slam the real cursor into a screen corner to abort.
  * Losing sight of your hand mid-drag immediately releases the mouse button.

Keys:  1 paint | 2 mouse | M live-mouse on/off | Q quit
       paint: C clear | U undo | S save | Y symmetry | R rainbow | + / - brush size
"""

import argparse
import dataclasses
import time

import cv2

import config as C
from apps.hand_pose import HoldDetector, PoseDebouncer, extract_features
from apps.air_mouse import AirMouse, DryRunBackend, make_backend
from apps.air_paint import PaintApp

WHITE, GRAY, GREEN, YELLOW, RED = (255, 255, 255), (170, 170, 170), (0, 255, 0), (0, 255, 255), (60, 60, 255)


def _text(frame, s, pos, color=WHITE, scale=0.5, thick=1):
    cv2.putText(frame, s, pos, cv2.FONT_HERSHEY_SIMPLEX, scale, color, thick, cv2.LINE_AA)


class MouseAndPaintApp:
    def __init__(self, width, height, mode="paint", live=False, save_dir=None):
        self.w, self.h = width, height
        self.mode = mode
        self.paint = PaintApp(width, height, save_dir=save_dir)
        self.dry = DryRunBackend()
        self.mouse = AirMouse(self.dry)
        self.live = False
        self.note = ""
        self._debounce = PoseDebouncer(C.POSE_DEBOUNCE_FRAMES)
        self._mode_hold = HoldDetector(C.MODE_SWITCH_POSE, C.MODE_SWITCH_HOLD_S)
        self._panic_hold = HoldDetector(C.MOUSE_PANIC_POSE, C.MOUSE_PANIC_HOLD_S)
        self.pose = "none"
        self.last_events = []
        if live:
            self.set_live(True)

    # ----------------------------------------------------------- mode / live
    def set_live(self, live: bool) -> str:
        if live:
            backend, note = make_backend(True)
            if backend.is_live:
                self.mouse.set_backend(backend)
                self.live = True
            else:                                   # couldn't go live: stay safe in dry-run
                self.mouse.set_backend(self.dry)
                self.live = False
        else:
            self.mouse.set_backend(self.dry)        # set_backend releases any held button first
            self.live = False
            note = "dry-run (cursor not touched)"
        self.note = note
        return note

    def set_mode(self, mode: str):
        if mode == self.mode:
            return
        self.paint.update(None, time.time())        # lift the brush
        self.mouse.update(None, time.time())        # release any held button
        self.mode = mode
        self._debounce.reset()

    def toggle_mode(self):
        self.set_mode("mouse" if self.mode == "paint" else "paint")

    def shutdown(self):
        """Always called on exit: lift the brush, let go of any held mouse
        button, and hand the real cursor back to the user."""
        self.paint.update(None, time.time())
        self.mouse.update(None, time.time())
        self.set_live(False)

    # ------------------------------------------------------------------ keys
    def handle_key(self, ch: str):
        if ch == "q":
            return "quit"
        if ch == "1":
            self.set_mode("paint")
        elif ch == "2":
            self.set_mode("mouse")
        elif ch == "m":
            self.set_live(not self.live)
        elif self.mode == "paint":
            return self.paint.handle_key(ch)
        return None

    # ------------------------------------------------------------ per frame
    def step(self, landmarks, now: float):
        """landmarks: 21 MediaPipe landmarks for one hand, or None."""
        feats = extract_features(landmarks) if landmarks is not None else None
        self.pose = self._debounce.update(feats.pose if feats else None)

        if feats is not None:
            stable = "other" if self.pose == "none" else self.pose   # warm-up frames: act as 'other'
            feats = dataclasses.replace(feats, pose=stable)

        if self._mode_hold.update(self.pose, now):
            self.toggle_mode()
            self.note = f"mode -> {self.mode.upper()}"
            return

        if self.mode == "mouse" and self.live and self._panic_hold.update(self.pose, now):
            self.set_live(False)
            self.note = "PANIC: back to DRY-RUN"

        if self.mode == "paint":
            self.last_events = self.paint.update(feats, now)
            for e in self.last_events:
                self.note = e
        else:
            res = self.mouse.update(feats, now)
            self.last_events = res.events
            if res.events:
                self.note = ", ".join(res.events)

    # ---------------------------------------------------------------- render
    def render(self, frame, now: float, fps: float = 0.0):
        if self.mode == "paint":
            self.paint.render(frame, now)
            y0 = 80
            lines = [f"PAINT  pose:{self.pose}  state:{self.paint.state}",
                     f"sym:{self.paint.canvas.sym_name}  size:{self.paint.size}  rainbow:{'ON' if self.paint.rainbow else 'off'}"]
        else:
            x0, y0r, x1, y1r = C.MOUSE_ACTIVE_REGION
            cv2.rectangle(frame, (int(x0 * self.w), int(y0r * self.h)), (int(x1 * self.w), int(y1r * self.h)),
                          GREEN if self.live else YELLOW, 2)
            y0 = 20
            lines = [f"MOUSE  pose:{self.pose}",
                     "LIVE - controlling real cursor" if self.live else "DRY-RUN - cursor not touched (M = go live)"]
            sw, sh = self.mouse.backend.screen_size()
            cx, cy = self.mouse.cursor
            cv2.circle(frame, (int(cx / sw * self.w), int(cy / sh * self.h)), 8, GREEN if self.live else YELLOW, -1)

        lines.append(f"FPS {fps:.0f}   note: {self.note}")
        for i, s in enumerate(lines):
            col = RED if "LIVE" in s and self.mode == "mouse" else WHITE
            _text(frame, s, (10, y0 + 20 * i), col, 0.5)

        for hold, label, ypos in ((self._mode_hold, "switch mode", self.h - 40),
                                  (self._panic_hold, "PANIC release", self.h - 60)):
            p = hold.progress(now)
            if p > 0 and (hold is self._mode_hold or (self.mode == "mouse" and self.live)):
                cv2.rectangle(frame, (10, ypos), (10 + int(160 * p), ypos + 8), YELLOW, -1)
                _text(frame, label, (180, ypos + 8), YELLOW, 0.4)

        _text(frame, "1 paint  2 mouse  M live  Q quit  | 3 fingers = switch mode",
              (10, self.h - 10), GRAY, 0.4)
        return frame


def pick_hand(observations):
    if not observations:
        return None
    right = next((o for o in observations if o.handedness == "Right"), None)
    return (right or observations[0]).landmarks


def main():
    ap = argparse.ArgumentParser(description="Air Mouse + Air Paint")
    ap.add_argument("--mode", choices=["paint", "mouse"], default="paint")
    ap.add_argument("--live-mouse", action="store_true", help="control the real cursor (needs pyautogui)")
    args = ap.parse_args()

    from perception.hand_tracker import HandTracker      # lazy: keeps this module importable without MediaPipe
    try:
        tracker = HandTracker()
    except Exception as e:
        print(f"ERROR: camera/MediaPipe initialization failed: {e}")
        return

    app = None
    print("Air Mouse + Air Paint -- hold THREE fingers to switch modes. Q to quit.")
    try:
        while True:
            ok, frame, observations, fps, err = tracker.read()
            if not ok:
                time.sleep(0.05)
                continue
            now = time.time()
            if app is None:
                h, w = frame.shape[:2]
                app = MouseAndPaintApp(w, h, mode=args.mode, live=args.live_mouse)
                print(f"[mouse] {app.note or 'dry-run (cursor not touched)'}")
            app.step(pick_hand(observations), now)
            app.render(frame, now, fps)
            cv2.imshow("Air Mouse + Air Paint", frame)
            key = cv2.waitKey(1) & 0xFF
            if key != 255 and app.handle_key(chr(key).lower()) == "quit":
                break
    finally:
        if app is not None:
            app.shutdown()            # always release the real mouse on the way out
        tracker.close()
        cv2.destroyAllWindows()


if __name__ == "__main__":
    main()
