import math
from robotics.ik_solver import solve_ik, forward_kinematics, solve_ik_diagnostic
from robotics.ik_solver_dls import solve_ik_dls, solve_ik_dls_diagnostic

L1, L2, L3 = 0.25, 0.25, 0.10
TARGETS = [(0.3, 0.1, 0.2), (0.1, 0.3, 0.15), (-0.2, 0.2, 0.3), (0.35, 0.0, 0.05), (0.05, 0.05, 0.35)]


def test_closed_form_round_trip():
    for x, y, z in TARGETS:
        t0, t1, t2, t3 = solve_ik(x, y, z, L1, L2, L3)
        fx, fy, fz = forward_kinematics(t0, t1, t2, L1, L2, L3)
        assert math.dist((x, y, z), (fx, fy, fz)) < 1e-6


def test_dls_converges_close_to_target():
    guess = None
    for x, y, z in TARGETS:
        t0, t1, t2, t3 = solve_ik_dls(x, y, z, L1, L2, L3, initial_guess=guess)
        fx, fy, fz = forward_kinematics(t0, t1, t2, L1, L2, L3)
        assert math.dist((x, y, z), (fx, fy, fz)) < 1e-2
        guess = (t0, t1, t2, t3)


def test_unreachable_target_does_not_crash():
    # Way outside the arm's reach -- must clamp, not raise
    angles = solve_ik(10.0, 10.0, 10.0, L1, L2, L3)
    assert all(math.isfinite(a) for a in angles)


def test_diagnostics_report_success():
    d = solve_ik_diagnostic(0.3, 0.1, 0.2, L1, L2, L3)
    assert d.success
    assert d.error < 1e-6
    assert d.solver_used == "closed_form"

    d2 = solve_ik_dls_diagnostic(0.3, 0.1, 0.2, L1, L2, L3)
    assert d2.success
    assert d2.solver_used == "dls"


def test_singularity_distance_shrinks_near_full_extension():
    # Fully extended (d close to l1+l2) should report a small distance-to-singularity
    near_full_extension = solve_ik_diagnostic(L1 + L2 - 0.001, 0.0, L3, L1, L2, L3)
    mid_workspace = solve_ik_diagnostic(0.2, 0.1, 0.2, L1, L2, L3)
    assert near_full_extension.distance_to_singularity < mid_workspace.distance_to_singularity
