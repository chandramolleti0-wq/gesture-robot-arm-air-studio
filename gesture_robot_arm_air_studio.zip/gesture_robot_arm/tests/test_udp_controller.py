import time
from communication.udp_controller import UDPSender, UDPReceiver


def test_basic_send_receive():
    recv = UDPReceiver(port=15501, timeout=0.3)
    send = UDPSender(port=15501)
    try:
        send.send((0.1, 0.2, 0.3), (0.0, 0.0, 0.0), 0.5, "TRACKING", False)
        time.sleep(0.05)
        msg = recv.poll_latest()
        assert msg is not None
        assert msg["position"] == [0.1, 0.2, 0.3]
        assert msg["mode"] == "TRACKING"
    finally:
        send.close()
        recv.close()


def test_disconnected_before_any_message():
    recv = UDPReceiver(port=15502, timeout=0.3)
    try:
        assert not recv.is_connected()
    finally:
        recv.close()


def test_timeout_detection():
    recv = UDPReceiver(port=15503, timeout=0.2)
    send = UDPSender(port=15503)
    try:
        send.send((0, 0, 0), (0, 0, 0), 0.0, "IDLE", False)
        time.sleep(0.05)
        recv.poll_latest()
        assert recv.is_connected()
        time.sleep(0.25)
        assert not recv.is_connected()
    finally:
        send.close()
        recv.close()


def test_out_of_order_packet_rejected():
    recv = UDPReceiver(port=15504, timeout=0.3)
    send = UDPSender(port=15504)
    try:
        send._seq = 100
        send.send((1, 1, 1), (0, 0, 0), 1.0, "TRACKING", False)
        time.sleep(0.02)
        recv.poll_latest()

        send._seq = 5  # simulate a late, older packet
        send.send((9, 9, 9), (0, 0, 0), 1.0, "TRACKING", False)
        time.sleep(0.02)
        msg = recv.poll_latest()
        assert msg is None or msg["position"] != [9, 9, 9]
        assert recv._dropped_out_of_order >= 1
    finally:
        send.close()
        recv.close()


def test_emergency_stop_flag_propagates():
    recv = UDPReceiver(port=15505, timeout=0.3)
    send = UDPSender(port=15505)
    try:
        send.send((0, 0, 0), (0, 0, 0), 0.0, "EMERGENCY_STOP", True)
        time.sleep(0.05)
        msg = recv.poll_latest()
        assert msg["emergency_stop"] is True
    finally:
        send.close()
        recv.close()
