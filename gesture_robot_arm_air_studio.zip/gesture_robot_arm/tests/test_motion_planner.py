from robotics.safety_manager import SafetyManager
from robotics.motion_planner import MotionPlanner


def test_normal_move_is_safe_and_moves_toward_target():
    sm = SafetyManager()
    mp = MotionPlanner(sm)
    r1 = mp.plan((0.3, 0.1, 0.2), dt=0.016)
    assert r1.safe
    assert r1.ik_success
    r2 = mp.plan((0.3, 0.1, 0.2), dt=0.016)
    # angles should be strictly progressing toward target, not jumping straight there
    assert r2.angles != r1.angles


def test_out_of_range_target_is_clamped_not_crashed():
    sm = SafetyManager()
    mp = MotionPlanner(sm)
    result = mp.plan((100.0, 100.0, 100.0), dt=0.016)
    assert result.safe  # clamped, not rejected
    assert "Workspace boundary reached" in result.warnings


def test_estop_freezes_planner_output():
    sm = SafetyManager()
    mp = MotionPlanner(sm)
    mp.plan((0.2, 0.2, 0.2), dt=0.016)
    frozen_before = mp._prev_angles[:]
    sm.trigger_estop()
    result = mp.plan((0.0, 0.4, 0.3), dt=0.016)
    assert not result.safe
    assert result.reason == "EMERGENCY_STOP"
    assert list(result.angles) == frozen_before


def test_precision_mode_speed_scale_reduces_step_size():
    sm = SafetyManager()
    mp_normal = MotionPlanner(sm)
    r_normal = mp_normal.plan((0.3, 0.3, 0.3), dt=0.016, speed_scale=1.0)

    sm2 = SafetyManager()
    mp_precision = MotionPlanner(sm2)
    r_precision = mp_precision.plan((0.3, 0.3, 0.3), dt=0.016, speed_scale=0.35)

    step_normal = max(abs(a) for a in r_normal.angles)
    step_precision = max(abs(a) for a in r_precision.angles)
    assert step_precision < step_normal


def test_solver_mode_auto_falls_back_near_singularity():
    sm = SafetyManager()
    mp = MotionPlanner(sm, solver_mode="auto")
    # Fully-extended-ish target should trigger DLS fallback
    result = mp.plan((mp.l1 + mp.l2 - 0.005, 0.0, mp.l3), dt=0.016)
    assert result.ik_solver_used in ("closed_form", "dls")  # must not crash regardless of which
