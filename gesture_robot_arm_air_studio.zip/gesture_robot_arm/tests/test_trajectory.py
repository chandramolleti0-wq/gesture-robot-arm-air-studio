from robotics.trajectory import catmull_rom_spline, generate_joint_trajectory


def test_spline_passes_through_waypoints():
    wps = [(0, 0, 0, 0), (0.1, 0.2, 0.1, 0), (0.2, 0.1, 0.2, 1), (0.0, 0.3, 0.15, 0)]
    path = catmull_rom_spline(wps, samples_per_segment=5)
    assert path[-1] == wps[-1]
    assert len(path) > len(wps)


def test_spline_handles_two_waypoints():
    wps = [(0, 0, 0, 0), (1, 1, 1, 1)]
    path = catmull_rom_spline(wps, samples_per_segment=4)
    assert path[-1] == wps[-1]


def test_spline_handles_single_waypoint():
    wps = [(0.5, 0.5, 0.5, 0.5)]
    path = catmull_rom_spline(wps)
    assert path == wps


def test_joint_trajectory_converges_to_target():
    traj = generate_joint_trajectory((0, 0, 0, 0), (1.0, -0.5, 0.8, 0.2), max_rate=2.0, max_accel=5.0, dt=0.016)
    final = traj[-1]
    target = (1.0, -0.5, 0.8, 0.2)
    err = max(abs(f - t) for f, t in zip(final, target))
    assert err < 0.01


def test_joint_trajectory_respects_velocity_limit():
    traj = generate_joint_trajectory((0, 0, 0, 0), (1.0, 0, 0, 0), max_rate=1.0, max_accel=100.0, dt=0.016)
    max_step = max(abs(traj[i + 1][0] - traj[i][0]) for i in range(len(traj) - 1))
    assert max_step <= 1.0 * 0.016 + 1e-6
