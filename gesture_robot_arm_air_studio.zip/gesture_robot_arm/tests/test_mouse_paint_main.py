import numpy as np
import pytest

import main_mouse_paint as mmp
from apps.air_mouse import DryRunBackend
from tests.test_air_apps import ALL4, make_hand

W, H = 640, 480
DT = 1 / 30


class FakeLiveBackend(DryRunBackend):
    is_live = True


def feed(app, hand, seconds, t0):
    """Feed the same hand pose at 30 fps for `seconds`. Returns the next timestamp."""
    t = t0
    for _ in range(int(seconds / DT) + 1):
        app.step(hand, t)
        t += DT
    return t


def new_app(tmp_path, **kw):
    return mmp.MouseAndPaintApp(W, H, save_dir=str(tmp_path), **kw)


def test_starts_in_paint_mode_and_dry_run(tmp_path):
    app = new_app(tmp_path)
    assert app.mode == "paint" and app.live is False and not app.mouse.backend.is_live


def test_holding_three_fingers_switches_mode_once_then_rearms(tmp_path):
    app = new_app(tmp_path)
    three = make_hand(("index", "middle", "ring"))
    t = feed(app, three, 2.0, 0.0)                    # long hold: must toggle exactly once
    assert app.mode == "mouse"
    t = feed(app, make_hand(ALL4), 0.3, t)            # release
    feed(app, three, 2.0, t)
    assert app.mode == "paint"


def test_brief_three_fingers_does_not_switch(tmp_path):
    app = new_app(tmp_path)
    t = feed(app, make_hand(("index", "middle", "ring")), 0.5, 0.0)
    assert app.mode == "paint"


def test_switching_modes_releases_a_held_mouse_button(tmp_path):
    app = new_app(tmp_path, mode="mouse")
    t = feed(app, make_hand(ALL4), 0.2, 0.0)
    t = feed(app, make_hand(("index",), pinch_gap=0.05), 1.0, t)     # pinch-hold -> drag
    assert app.mouse._dragging
    app.handle_key("1")
    assert not app.mouse._dragging
    assert ("up", "left") in app.dry.events


def test_panic_fist_drops_live_mouse_back_to_dry_run(tmp_path, monkeypatch):
    monkeypatch.setattr(mmp, "make_backend", lambda live: (FakeLiveBackend(), "LIVE"))
    app = new_app(tmp_path, mode="mouse", live=True)
    assert app.live and app.mouse.backend.is_live
    t = feed(app, make_hand(ALL4), 0.2, 0.0)
    feed(app, make_hand(()), 2.0, t)                  # hold a fist > 1.5 s
    assert app.live is False and not app.mouse.backend.is_live
    assert "PANIC" in app.note


def test_short_fist_does_not_panic(tmp_path, monkeypatch):
    monkeypatch.setattr(mmp, "make_backend", lambda live: (FakeLiveBackend(), "LIVE"))
    app = new_app(tmp_path, mode="mouse", live=True)
    feed(app, make_hand(()), 0.6, 0.0)
    assert app.live is True


def test_panic_only_applies_to_live_mouse_mode(tmp_path):
    app = new_app(tmp_path, mode="paint")
    feed(app, make_hand(()), 2.0, 0.0)
    assert "PANIC" not in app.note


def test_going_live_without_pyautogui_stays_safe_and_says_why(tmp_path):
    try:
        import pyautogui  # noqa: F401
        pytest.skip("pyautogui installed here")
    except Exception:
        pass
    app = new_app(tmp_path)
    note = app.set_live(True)
    assert app.live is False and not app.mouse.backend.is_live and "unavailable" in note


def test_key_handling(tmp_path):
    app = new_app(tmp_path)
    assert app.handle_key("2") is None and app.mode == "mouse"
    assert app.handle_key("1") is None and app.mode == "paint"
    assert app.handle_key("r") == "rainbow_on"
    assert app.handle_key("q") == "quit"
    app.handle_key("2")
    assert app.handle_key("r") is None            # paint shortcuts are inert in mouse mode


def test_pointing_through_the_whole_stack_paints(tmp_path):
    app = new_app(tmp_path)
    t = 0.0
    for i in range(30):
        app.step(make_hand(("index",), shift=(-0.1 + i * 0.01, 0.0)), t)
        t += DT
    assert app.paint.canvas.layer.any()


def test_pointing_in_mouse_mode_moves_cursor_and_never_paints(tmp_path):
    app = new_app(tmp_path, mode="mouse")
    t = 0.0
    for i in range(30):
        app.step(make_hand(("index",), shift=(-0.1 + i * 0.01, 0.0)), t)
        t += DT
    assert any(e[0] == "move" for e in app.dry.events)
    assert not app.paint.canvas.layer.any()


def test_no_hand_is_handled_in_both_modes(tmp_path):
    app = new_app(tmp_path)
    for mode in ("paint", "mouse"):
        app.set_mode(mode)
        for i in range(5):
            app.step(None, i * DT)
    assert app.pose == "none"


@pytest.mark.parametrize("mode", ["paint", "mouse"])
def test_render_works_in_both_modes(tmp_path, mode):
    app = new_app(tmp_path, mode=mode)
    feed(app, make_hand(("index",)), 0.3, 0.0)
    frame = np.zeros((H, W, 3), np.uint8)
    out = app.render(frame, 0.5, fps=30)
    assert out.shape == (H, W, 3) and out.any()


def test_pick_hand_prefers_right():
    class O:
        def __init__(self, h, lm): self.handedness, self.landmarks = h, lm
    assert mmp.pick_hand([]) is None
    assert mmp.pick_hand([O("Left", "L"), O("Right", "R")]) == "R"
    assert mmp.pick_hand([O("Left", "L")]) == "L"


def test_shutdown_releases_held_button_and_returns_cursor_to_user(tmp_path, monkeypatch):
    live = FakeLiveBackend()
    monkeypatch.setattr(mmp, "make_backend", lambda l: (live, "LIVE"))
    app = new_app(tmp_path, mode="mouse", live=True)
    t = feed(app, make_hand(ALL4), 0.2, 0.0)
    feed(app, make_hand(("index",), pinch_gap=0.05), 1.0, t)       # mid-drag on the LIVE backend
    assert app.mouse._dragging and app.live
    app.shutdown()
    assert ("up", "left") in live.events           # button released on the live backend
    assert app.live is False and not app.mouse.backend.is_live
