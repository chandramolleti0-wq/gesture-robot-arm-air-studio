import time
from robotics.safety_manager import SafetyManager, SAFE, EMERGENCY_STOP


def test_workspace_clamping():
    sm = SafetyManager()
    (cx, cy, cz), clamped = sm.clamp_workspace(10.0, 0.2, 0.1)
    assert clamped
    assert cx == sm.safety_box["x"][1]


def test_workspace_no_clamp_when_in_range():
    sm = SafetyManager()
    (cx, cy, cz), clamped = sm.clamp_workspace(0.0, 0.2, 0.1)
    assert not clamped


def test_joint_limit_violation_detected():
    sm = SafetyManager()
    violations = sm.check_joint_limits([10.0, 0.0, 0.0, 0.0])
    assert 0 in violations


def test_joint_limit_clamped():
    sm = SafetyManager()
    clamped = sm.clamp_joint_limits([10.0, 0.0, 0.0, 0.0])
    lo, hi = sm.joint_limits[0]
    assert clamped[0] == hi


def test_velocity_limiting_caps_step_size():
    sm = SafetyManager()
    limited, was_limited = sm.limit_velocity((0, 0, 0, 0), (10, 10, 10, 10), dt=0.016)
    assert was_limited
    max_delta = sm.max_joint_rate * 0.016
    assert all(abs(a) <= max_delta + 1e-9 for a in limited)


def test_acceleration_limiting_prevents_instant_jump_to_max_speed():
    sm = SafetyManager()
    a1, _ = sm.limit_acceleration((0, 0, 0, 0), None, (0.01, 0, 0, 0), dt=0.016)
    a2, _ = sm.limit_acceleration(a1, (0, 0, 0, 0), (10, 0, 0, 0), dt=0.016)
    # step 2's displacement should still be constrained, not jump straight to max velocity step
    assert abs(a2[0] - a1[0]) < sm.max_joint_rate * 0.016


def test_estop_blocks_and_freezes():
    sm = SafetyManager()
    sm.trigger_estop()
    assert sm.is_estopped()
    status, xyz = sm.evaluate_target(0.1, 0.2, 0.1)
    assert not status.ok
    assert status.reason == EMERGENCY_STOP


def test_estop_requires_sustained_open_palm_to_clear():
    sm = SafetyManager()
    sm.trigger_estop()
    sm.update_estop_clear(open_palm_detected=True, hold_required=0.2)
    assert sm.is_estopped(), "must not clear on the very first frame"
    time.sleep(0.25)
    sm.update_estop_clear(open_palm_detected=True, hold_required=0.2)
    assert not sm.is_estopped()


def test_estop_clear_resets_if_palm_disappears_midway():
    sm = SafetyManager()
    sm.trigger_estop()
    sm.update_estop_clear(open_palm_detected=True, hold_required=0.3)
    time.sleep(0.15)
    sm.update_estop_clear(open_palm_detected=False, hold_required=0.3)  # interrupted
    time.sleep(0.2)
    sm.update_estop_clear(open_palm_detected=True, hold_required=0.3)
    assert sm.is_estopped(), "interrupted hold should have reset the timer"


def test_collision_provider_failure_defaults_to_unsafe():
    sm = SafetyManager()

    def broken_provider(trajectory):
        raise RuntimeError("simulated failure")

    sm.set_collision_provider(broken_provider)
    assert sm.check_collision([]) is False


def test_no_collision_provider_defaults_to_safe():
    sm = SafetyManager()
    assert sm.check_collision([]) is True
