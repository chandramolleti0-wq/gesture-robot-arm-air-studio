import math
import mediapipe as mp
from perception.gesture_classifier import classify, finger_states, pinch_distance

mp_hands = mp.solutions.hands
HL = mp_hands.HandLandmark
NUM_LANDMARKS = 21


class FakeLM:
    def __init__(self, x, y, z=0.0):
        self.x, self.y, self.z = x, y, z


def _base_hand():
    """A neutral hand with wrist at (0.5, 0.8) and fingers pointing up (small y)."""
    lm = [FakeLM(0.5, 0.8) for _ in range(NUM_LANDMARKS)]
    lm[HL.WRIST] = FakeLM(0.5, 0.8)
    return lm


def _extend(lm, tip_idx, pip_idx, x=0.5):
    lm[pip_idx] = FakeLM(x, 0.6)
    lm[tip_idx] = FakeLM(x, 0.4)  # tip well above pip -> extended


def _curl(lm, tip_idx, pip_idx, x=0.5):
    lm[pip_idx] = FakeLM(x, 0.6)
    lm[tip_idx] = FakeLM(x, 0.65)  # tip below pip -> curled


def _make_fist():
    lm = _base_hand()
    for tip, pip in [(HL.INDEX_FINGER_TIP, HL.INDEX_FINGER_PIP),
                      (HL.MIDDLE_FINGER_TIP, HL.MIDDLE_FINGER_PIP),
                      (HL.RING_FINGER_TIP, HL.RING_FINGER_PIP),
                      (HL.PINKY_TIP, HL.PINKY_PIP)]:
        _curl(lm, tip, pip)
    lm[HL.THUMB_TIP] = FakeLM(0.51, 0.79)  # thumb tucked close to wrist
    lm[HL.THUMB_IP] = FakeLM(0.55, 0.75)
    return lm


def _make_open_palm():
    lm = _base_hand()
    for tip, pip in [(HL.INDEX_FINGER_TIP, HL.INDEX_FINGER_PIP),
                      (HL.MIDDLE_FINGER_TIP, HL.MIDDLE_FINGER_PIP),
                      (HL.RING_FINGER_TIP, HL.RING_FINGER_PIP),
                      (HL.PINKY_TIP, HL.PINKY_PIP)]:
        _extend(lm, tip, pip)
    lm[HL.THUMB_TIP] = FakeLM(0.3, 0.8)   # far from wrist -> extended
    lm[HL.THUMB_IP] = FakeLM(0.4, 0.8)
    return lm


def _make_pinch():
    lm = _base_hand()
    lm[HL.THUMB_TIP] = FakeLM(0.5, 0.5)
    lm[HL.INDEX_FINGER_TIP] = FakeLM(0.5, 0.5)
    lm[HL.INDEX_FINGER_PIP] = FakeLM(0.5, 0.6)
    return lm


def test_fist_classified_correctly():
    label, conf = classify(_make_fist())
    assert label == "fist"
    assert conf > 0.5


def test_open_palm_classified_correctly():
    label, conf = classify(_make_open_palm())
    assert label == "open_palm"


def test_pinch_classified_correctly():
    label, conf = classify(_make_pinch())
    assert label == "pinch"


def test_pinch_distance_small_when_touching():
    lm = _make_pinch()
    assert pinch_distance(lm) < 0.01


def test_confidence_always_between_0_and_1():
    for maker in (_make_fist, _make_open_palm, _make_pinch):
        _, conf = classify(maker())
        assert 0.0 <= conf <= 1.0
