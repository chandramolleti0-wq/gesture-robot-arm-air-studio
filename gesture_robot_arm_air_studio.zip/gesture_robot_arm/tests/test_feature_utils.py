import numpy as np
from perception.feature_utils import landmarks_to_features, augment, FEATURE_DIM


class FakeLM:
    def __init__(self, x, y, z):
        self.x, self.y, self.z = x, y, z


def _make_landmarks(offset=(0, 0, 0), scale=1.0, seed=0):
    rng = np.random.default_rng(seed)
    pts = rng.normal(0, 0.05, (21, 3)) * scale + np.array(offset)
    return [FakeLM(*p) for p in pts]


def test_feature_vector_shape():
    lm = _make_landmarks()
    feats = landmarks_to_features(lm)
    assert feats.shape == (FEATURE_DIM,)


def test_translation_invariance():
    lm1 = _make_landmarks(offset=(0, 0, 0), seed=1)
    lm2 = _make_landmarks(offset=(0, 0, 0), seed=1)
    # shift every landmark by the same constant -> should produce identical features
    for l in lm2:
        l.x += 0.3
        l.y -= 0.2
    f1 = landmarks_to_features(lm1)
    f2 = landmarks_to_features(lm2)
    assert np.allclose(f1, f2, atol=1e-5)


def test_scale_invariance():
    lm1 = _make_landmarks(seed=2)
    lm2 = _make_landmarks(seed=2)
    for l in lm2:
        l.x *= 2.0
        l.y *= 2.0
        l.z *= 2.0
    f1 = landmarks_to_features(lm1)
    f2 = landmarks_to_features(lm2)
    assert np.allclose(f1, f2, atol=1e-4)


def test_augment_changes_but_preserves_shape():
    lm = _make_landmarks(seed=3)
    feats = landmarks_to_features(lm)
    rng = np.random.default_rng(0)
    augmented = augment(feats, rng)
    assert augmented.shape == feats.shape
    assert not np.allclose(feats, augmented)
