import math
import os

import numpy as np
import pytest

import config as C
from apps.hand_pose import (HandFeatures, HoldDetector, PoseDebouncer,
                            classify_pose, extract_features)
from apps.air_mouse import AirMouse, DryRunBackend, make_backend
from apps.air_paint import (PaintApp, PaintCanvas, SYM_MODES, toolbar_hit,
                            toolbar_items, toolbar_layout)


# ------------------------------------------------------------ synthetic hands
class LM:
    def __init__(self, x, y):
        self.x, self.y = x, y


def make_hand(extended=(), pinch_gap=None, middle_gap=None, shift=(0.0, 0.0), rotate_deg=0.0, scale=1.0):
    """21 landmarks, wrist at (0.5, 0.8), palm size 0.2. `extended` = finger names held up.
    pinch_gap / middle_gap = thumb-to-fingertip distance in palm-size units."""
    wrist = (0.5, 0.8)
    lm = [LM(*wrist) for _ in range(21)]
    fingers = {"index": (5, 0.45), "middle": (9, 0.50), "ring": (13, 0.55), "pinky": (17, 0.60)}
    for name, (m, x) in fingers.items():
        lm[m] = LM(x, 0.60)
        lm[m + 1] = LM(x, 0.53)                                    # PIP
        up = name in extended
        lm[m + 2] = LM(x, 0.45 if up else 0.60)                    # DIP
        lm[m + 3] = LM(x, 0.38 if up else 0.63)                    # tip
    lm[1], lm[2], lm[3], lm[4] = LM(0.42, 0.75), LM(0.38, 0.70), LM(0.35, 0.66), LM(0.30, 0.62)
    palm = 0.2
    if pinch_gap is not None:
        t = lm[8]
        lm[4] = LM(t.x + pinch_gap * palm, t.y)
    if middle_gap is not None:
        t = lm[12]
        lm[4] = LM(t.x + middle_gap * palm, t.y)
    a = math.radians(rotate_deg)
    ca, sa = math.cos(a), math.sin(a)
    for p in lm:
        dx, dy = (p.x - wrist[0]) * scale, (p.y - wrist[1]) * scale
        p.x = wrist[0] + dx * ca - dy * sa + shift[0]
        p.y = wrist[1] + dx * sa + dy * ca + shift[1]
    return lm


def feats(extended=(), **kw):
    return extract_features(make_hand(extended, **kw))


ALL4 = ("index", "middle", "ring", "pinky")


# ------------------------------------------------------------------ hand_pose
@pytest.mark.parametrize("ext,pose", [
    ((), "fist"), (("index",), "point"), (("index", "middle"), "peace"),
    (("index", "middle", "ring"), "three"), (ALL4, "open"), (("pinky",), "other"),
])
def test_pose_classification(ext, pose):
    assert feats(ext).pose == pose


def test_classify_pose_empty_is_fist():
    assert classify_pose({"index": False, "middle": False, "ring": False, "pinky": False}) == "fist"


def test_pinch_ratio_small_when_pinching_large_when_open():
    assert feats(("index",), pinch_gap=0.05).pinch_ratio < 0.1
    assert feats(ALL4).pinch_ratio > 1.0


def test_pose_survives_rotation():
    for deg in (-40, -20, 20, 40):
        assert feats(("index", "middle"), rotate_deg=deg).pose == "peace"


def test_features_are_distance_invariant():
    near = feats(ALL4, pinch_gap=0.3)
    far = feats(ALL4, pinch_gap=0.3, scale=0.5)
    assert near.pose == far.pose == "open"
    assert near.pinch_ratio == pytest.approx(far.pinch_ratio, rel=0.05)


def test_pose_debouncer_ignores_single_glitch():
    d = PoseDebouncer(3)
    for _ in range(3):
        d.update("point")
    assert d.stable == "point"
    d.update("fist")                     # one bad frame
    assert d.update("point") == "point"
    for _ in range(3):
        d.update("fist")
    assert d.stable == "fist"


def test_hold_detector_fires_once_then_rearms():
    h = HoldDetector("three", 1.0)
    assert not h.update("three", 0.0)
    assert not h.update("three", 0.5)
    assert h.update("three", 1.0)
    assert not h.update("three", 1.5)    # must not fire again while still held
    assert not h.update("open", 1.6)
    assert not h.update("three", 2.0)
    assert h.update("three", 3.0)        # re-armed after release
    assert h.progress(3.0) == 0.0


# ------------------------------------------------------------------ air mouse
def run(mouse, frames):
    """frames: list of (features_or_None, t). Returns all events."""
    out = []
    for f, t in frames:
        out += mouse.update(f, t).events
    return out


def new_mouse():
    return AirMouse(DryRunBackend((1000, 800)))


def test_cursor_follows_index_finger_and_stays_on_screen():
    m = new_mouse()
    xs = []
    for i in range(30):
        r = m.update(feats(("index",), shift=(-0.2 + i * 0.015, 0.0)), i * 0.03)
        xs.append(r.cursor[0])
    assert xs[-1] > xs[0] + 100
    assert all(0 <= x <= 999 for x in xs)
    assert any(e[0] == "move" for e in m.backend.events)


def test_active_region_edges_map_to_screen_edges():
    m = new_mouse()
    m.update(feats(("index",), shift=(-0.9, -0.9)), 0.0)     # far outside region, clamped
    assert m.cursor == (0.0, 0.0)


def test_quick_pinch_is_a_click():
    m = new_mouse()
    ev = run(m, [(feats(ALL4), 0.0), (feats(("index",), pinch_gap=0.05), 1.0),
                 (feats(("index",), pinch_gap=0.05), 1.1), (feats(ALL4), 1.2)])
    assert ev.count("click") == 1
    assert "drag_start" not in ev
    assert ("click", "left") in m.backend.events


def test_long_pinch_is_a_drag_not_a_click():
    m = new_mouse()
    frames = [(feats(ALL4), 0.0)] + [(feats(("index",), pinch_gap=0.05), 1.0 + i * 0.1) for i in range(8)]
    frames.append((feats(ALL4), 2.0))
    ev = run(m, frames)
    assert ev.count("drag_start") == 1 and ev.count("drag_end") == 1
    assert "click" not in ev
    kinds = [e[0] for e in m.backend.events if e[0] in ("down", "up")]
    assert kinds == ["down", "up"]


def test_losing_the_hand_mid_drag_releases_the_button():
    m = new_mouse()
    run(m, [(feats(ALL4), 0.0)] + [(feats(("index",), pinch_gap=0.05), 1.0 + i * 0.1) for i in range(6)])
    assert m._dragging
    ev = m.update(None, 2.0).events
    assert "drag_end" in ev
    assert ("up", "left") in m.backend.events
    assert not m._dragging


def test_fist_pauses_and_releases_drag():
    m = new_mouse()
    run(m, [(feats(ALL4), 0.0)] + [(feats(("index",), pinch_gap=0.05), 1.0 + i * 0.1) for i in range(6)])
    r = m.update(feats(()), 2.0)
    assert r.state == "PAUSED" and "drag_end" in r.events
    n = len(m.backend.events)
    m.update(feats((), shift=(0.1, 0.1)), 2.1)
    assert len(m.backend.events) == n          # no cursor movement while paused


def test_cursor_freezes_while_fingers_close_for_a_click():
    m = new_mouse()
    m.update(feats(("index",)), 0.0)
    n = len(m.backend.events)
    r = m.update(feats(("index",), pinch_gap=0.5, shift=(0.1, 0.0)), 0.1)   # ratio 0.5 < freeze 0.7
    assert r.state == "AIMING"
    assert len(m.backend.events) == n


def test_pinch_hysteresis_prevents_flicker():
    m = new_mouse()
    run(m, [(feats(ALL4), 0.0), (feats(("index",), pinch_gap=0.05), 1.0)])
    ev = m.update(feats(("index",), pinch_gap=0.32), 1.1).events    # between press (.25) and release (.40)
    assert "click" not in ev and m._pinching


def test_right_click_on_thumb_middle_pinch_with_cooldown():
    m = new_mouse()
    ev = run(m, [(feats(ALL4), 0.0), (feats(ALL4, middle_gap=0.05), 1.0)])
    assert ev.count("right_click") == 1
    assert ("click", "right") in m.backend.events
    ev2 = run(m, [(feats(ALL4), 1.05), (feats(ALL4, middle_gap=0.05), 1.1)])   # within cooldown
    assert "right_click" not in ev2


def test_peace_sign_scrolls_in_hand_direction():
    m = new_mouse()
    m.update(feats(("index", "middle")), 0.0)
    m.update(feats(("index", "middle"), shift=(0.0, -0.15)), 0.1)     # hand up
    ups = [e for e in m.backend.events if e[0] == "scroll"]
    assert ups and ups[-1][1] > 0
    m.backend.events.clear()
    m.update(feats(("index", "middle"), shift=(0.0, 0.15)), 0.2)      # hand back down
    downs = [e for e in m.backend.events if e[0] == "scroll"]
    assert downs and downs[-1][1] < 0


def test_swapping_backend_releases_held_button():
    m = new_mouse()
    old = m.backend
    run(m, [(feats(ALL4), 0.0)] + [(feats(("index",), pinch_gap=0.05), 1.0 + i * 0.1) for i in range(6)])
    m.set_backend(DryRunBackend())
    assert ("up", "left") in old.events


def test_make_backend_dry_run_is_not_live():
    b, note = make_backend(False)
    assert not b.is_live and "dry-run" in note


def test_make_backend_live_falls_back_gracefully_without_pyautogui():
    try:
        import pyautogui  # noqa: F401
        pytest.skip("pyautogui is installed here; fallback path not exercised")
    except Exception:
        pass
    b, note = make_backend(True)
    assert not b.is_live and "unavailable" in note


# ---------------------------------------------------------------- paint canvas
def canvas(w=640, h=480):
    return PaintCanvas(w, h)


def test_draw_segment_paints_requested_color():
    c = canvas()
    c.draw_segment((100, 200), (200, 200), (10, 20, 250), 4)
    assert tuple(c.layer[200, 150]) == (10, 20, 250)
    assert not c.layer[300, 150].any()


def test_symmetry_point_counts():
    c = canvas()
    for i, (name, count) in enumerate(SYM_MODES):
        c.sym_mode = i
        assert len(c.symmetric_points((123, 77))) == count, name


def test_mirror_reflects_across_center():
    c = canvas()
    c.sym_mode = 1
    pts = c.symmetric_points((100, 50))
    assert pts[1] == pytest.approx((540, 50))


def test_radial_symmetry_preserves_distance_from_center():
    c = canvas()
    c.sym_mode = 3
    cx, cy = 320, 240
    d0 = math.hypot(100 - cx, 80 - cy)
    for x, y in c.symmetric_points((100, 80)):
        assert math.hypot(x - cx, y - cy) == pytest.approx(d0)


def test_symmetric_drawing_paints_both_sides():
    c = canvas()
    c.sym_mode = 1
    c.draw_dot((100, 100), (255, 255, 255), 8)
    assert c.layer[100, 100].any() and c.layer[100, 540].any()


def test_cycle_symmetry_wraps():
    c = canvas()
    names = [c.cycle_symmetry() for _ in range(len(SYM_MODES))]
    assert names[-1] == "OFF"


def test_undo_restores_and_empty_undo_is_safe():
    c = canvas()
    assert c.undo() is False
    c.push_undo()
    c.draw_dot((50, 50), (255, 0, 0), 10)
    assert c.layer.any()
    assert c.undo() is True
    assert not c.layer.any()


def test_clear_is_undoable():
    c = canvas()
    c.draw_dot((50, 50), (255, 0, 0), 10)
    c.clear()
    assert not c.layer.any()
    c.undo()
    assert c.layer.any()


def test_undo_history_is_bounded():
    c = PaintCanvas(64, 64, undo_depth=3)
    for _ in range(10):
        c.push_undo()
    assert len(c._undo) == 3


def test_rainbow_color_cycles_with_distance():
    c = canvas()
    first = c.rainbow_color(0.0)
    later = c.rainbow_color(C.PAINT_RAINBOW_PX_PER_CYCLE / 3)
    assert first != later
    c.rainbow_color(C.PAINT_RAINBOW_PX_PER_CYCLE * 2 / 3)       # completes one full cycle
    assert c.rainbow_color(0.0) == first


def test_composite_without_glow_is_exact():
    c = canvas(100, 100)
    c.draw_dot((50, 50), (0, 255, 0), 10)
    frame = np.full((100, 100, 3), 7, np.uint8)
    c.composite(frame, glow=False)
    assert tuple(frame[50, 50]) == (0, 255, 0)
    assert tuple(frame[5, 5]) == (7, 7, 7)


def test_composite_glow_brightens_neighbourhood():
    c = canvas(100, 100)
    c.draw_dot((50, 50), (0, 255, 0), 10)
    frame = np.zeros((100, 100, 3), np.uint8)
    c.composite(frame, glow=True)
    assert frame[50, 62, 1] > 0          # glow bleeds past the stroke edge


def test_save_autonumbers_and_writes_valid_png(tmp_path):
    import cv2
    c = canvas(120, 90)
    c.draw_dot((60, 45), (0, 0, 255), 12)
    p1, p2 = c.save(str(tmp_path)), c.save(str(tmp_path))
    assert p1.endswith("painting_001.png") and p2.endswith("painting_002.png")
    img = cv2.imread(p1)
    assert img.shape == (90, 120, 3) and img.any()


# --------------------------------------------------------------------- toolbar
def test_toolbar_layout_spans_full_width_without_gaps():
    lay = toolbar_layout(640)
    assert lay[0][1] == 0 and lay[-1][2] == 640
    assert all(lay[i][2] == lay[i + 1][1] for i in range(len(lay) - 1))


def test_toolbar_hit_testing():
    assert toolbar_hit(5, 10, 640) == "color:0"
    assert toolbar_hit(635, 10, 640) == "save"
    assert toolbar_hit(100, C.PAINT_TOOLBAR_HEIGHT + 5, 640) is None
    assert len(toolbar_items()) == len(C.PAINT_COLORS) + 7


# ------------------------------------------------------------------- paint app
def hf(pose, x, y):
    return HandFeatures(pose=pose, index_tip=(x, y), thumb_tip=(x, y), middle_tip=(x, y),
                        palm_center=(x, y), palm_size=0.2, pinch_ratio=1.0, pinch_middle_ratio=1.0)


def new_app(tmp_path):
    return PaintApp(640, 480, save_dir=str(tmp_path))


def test_pointing_draws_and_start_of_stroke_is_undoable(tmp_path):
    app = new_app(tmp_path)
    for i in range(10):
        app.update(hf("point", 0.3 + i * 0.02, 0.5), i * 0.03)
    assert app.state == "DRAW" and app.canvas.layer.any()
    assert app.canvas.undo() and not app.canvas.layer.any()


def test_cannot_draw_on_the_toolbar(tmp_path):
    app = new_app(tmp_path)
    for i in range(5):
        app.update(hf("point", 0.3 + i * 0.02, 0.05), i * 0.03)
    assert not app.canvas.layer.any()


def test_hand_loss_breaks_the_stroke(tmp_path):
    app = new_app(tmp_path)
    app.update(hf("point", 0.2, 0.5), 0.0)
    app.update(hf("point", 0.25, 0.5), 0.03)
    app.update(None, 0.06)
    app.update(hf("point", 0.35, 0.5), 0.5)      # returns somewhere else
    app.update(hf("point", 0.36, 0.5), 0.53)
    gap_x = int(0.30 * 640)
    assert not app.canvas.layer[240, gap_x - 5: gap_x + 5].any()   # nothing joins the two strokes


def test_tracking_jump_does_not_draw_a_streak(tmp_path):
    app = new_app(tmp_path)
    app.update(hf("point", 0.1, 0.5), 0.0)
    app.update(hf("point", 0.12, 0.5), 0.03)
    # A full second later the tracker reports the finger on the far side. The
    # filter has had time to follow, so only the stroke-jump guard stands
    # between this and a straight streak across the canvas.
    app.update(hf("point", 0.9, 0.5), 1.0)
    app.update(hf("point", 0.91, 0.5), 1.03)
    mid = int(0.5 * 640)
    assert app.canvas.layer[240, int(0.9 * 640) - 12: int(0.9 * 640) + 12].any()   # it did draw at the new spot...
    assert not app.canvas.layer[240, mid - 20: mid + 20].any()                      # ...but no streak in between


def test_peace_sign_dwell_selects_color(tmp_path):
    app = new_app(tmp_path)
    _, x0, x1 = toolbar_layout(640)[2]
    x = (x0 + x1) / 2 / 640
    ev = []
    for t in (0.0, 0.2, 0.5):
        ev += app.update(hf("peace", x, 30 / 480), t)
    assert app.color_idx == 2 and "color" in ev and not app.canvas.layer.any()


def test_color_button_fires_once_per_dwell(tmp_path):
    app = new_app(tmp_path)
    _, x0, x1 = toolbar_layout(640)[1]
    x = (x0 + x1) / 2 / 640
    ev = []
    for t in (0.0, 0.5, 0.6, 0.7, 0.8):
        ev += app.update(hf("peace", x, 30 / 480), t)
    assert ev.count("color") == 1


def test_clear_requires_longer_dwell_than_other_buttons(tmp_path):
    app = new_app(tmp_path)
    app.canvas.draw_dot((300, 300), (255, 255, 255), 10)
    idx = toolbar_items().index("clear")
    _, x0, x1 = toolbar_layout(640)[idx]
    x = (x0 + x1) / 2 / 640
    app.update(hf("peace", x, 30 / 480), 0.0)
    app.update(hf("peace", x, 30 / 480), 0.6)          # long enough for a normal button...
    assert app.canvas.layer.any()                      # ...but CLEAR must not fire yet
    ev = app.update(hf("peace", x, 30 / 480), 1.3)
    assert "clear" in ev and not app.canvas.layer.any()


def test_open_palm_erases(tmp_path):
    app = new_app(tmp_path)
    app.canvas.draw_dot((320, 300), (255, 255, 255), 20)
    app.update(hf("open", 320 / 640, 300 / 480), 0.0)
    assert app.state == "ERASE" and not app.canvas.layer[300, 320].any()


def test_fist_lifts_the_brush(tmp_path):
    app = new_app(tmp_path)
    app.update(hf("point", 0.3, 0.5), 0.0)
    app.update(hf("fist", 0.3, 0.5), 0.1)
    assert app.state == "IDLE" and not app._drawing


def test_toolbar_actions(tmp_path):
    app = new_app(tmp_path)
    assert app.trigger("rainbow") == "rainbow_on" and app.rainbow
    assert app.trigger("rainbow") == "rainbow_off"
    assert app.trigger("sym").startswith("sym:")
    for _ in range(50):
        app.trigger("size+")
    assert app.size == C.PAINT_BRUSH_MAX
    for _ in range(50):
        app.trigger("size-")
    assert app.size == C.PAINT_BRUSH_MIN
    assert app.trigger("undo") == "undo_empty"
    assert app.trigger("save").startswith("saved:") and os.path.exists(app.last_saved)


def test_keyboard_shortcuts(tmp_path):
    app = new_app(tmp_path)
    assert app.handle_key("r") == "rainbow_on"
    assert app.handle_key("z") is None


def test_render_returns_frame_without_crashing(tmp_path):
    app = new_app(tmp_path)
    for i in range(6):
        app.update(hf("point", 0.3 + i * 0.03, 0.5), i * 0.03)
    frame = np.zeros((480, 640, 3), np.uint8)
    out = app.render(frame, 0.2)
    assert out.shape == (480, 640, 3) and out.any()


def test_particles_are_capped_and_die_out(tmp_path):
    app = new_app(tmp_path)
    for i in range(400):
        app.update(hf("point", 0.3 + (i % 20) * 0.005, 0.5), i * 0.01)
    assert len(app._particles) <= C.PAINT_MAX_PARTICLES
    for i in range(40):
        app.update(None, 10 + i * 0.01)
    assert len(app._particles) == 0
