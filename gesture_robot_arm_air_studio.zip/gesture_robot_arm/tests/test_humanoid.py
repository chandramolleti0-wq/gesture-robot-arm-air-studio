import math
import time

from robotics.joint_controller import JointController
from robotics.humanoid_controller import HumanoidState, neutral_pose
from robotics.inverse_kinematics import LEFT_ARM_IK, RIGHT_ARM_IK
from robotics.safety_controller import SafetyController, SAFE, EMERGENCY_STOP, TRACKING_LOST, LOW_CONFIDENCE
from control.motion_mapper import arm_angles_from_pose, hand_openness_to_grip
from control.humanoid_mode_manager import HumanoidModeManager, HumanoidMode
from communication.udp_sender import HumanoidCommand, ArmCommand, HumanoidUDPSender, HumanoidUDPReceiver
import config as C


class LM:
    def __init__(self, x, y, z=0.0):
        self.x, self.y, self.z = x, y, z


# ------------------------------------------------------------- joint_controller
def test_joint_controller_velocity_limit():
    jc = JointController(["a", "b"], max_rate=2.0, max_accel=100.0)
    result = jc.limit_velocity({"a": 1.0, "b": -1.0}, dt=0.016)
    assert all(abs(v) <= 2.0 * 0.016 + 1e-9 for v in result.values())


def test_joint_controller_acceleration_limit_prevents_instant_jump():
    jc = JointController(["a"], max_rate=10.0, max_accel=5.0)
    r1 = jc.limit_acceleration({"a": 0.01}, dt=0.016)
    r2 = jc.limit_acceleration({"a": 10.0}, dt=0.016)
    assert abs(r2["a"] - r1["a"]) < 10.0 * 0.016


# ------------------------------------------------------------- humanoid_controller
def test_neutral_pose_covers_active_joints():
    pose = neutral_pose()
    assert set(pose.keys()) == set(C.ACTIVE_HUMANOID_JOINTS)
    assert all(v == 0.0 for v in pose.values())


def test_humanoid_state_clamps_to_limits():
    state = HumanoidState()
    state.joint_angles["left_shoulder"] = 999.0
    state.clamp_to_limits()
    lo, hi = C.HUMANOID_JOINT_LIMITS["left_shoulder"]
    assert state.joint_angles["left_shoulder"] == hi


# ------------------------------------------------------------- inverse_kinematics
def test_arm_ik_returns_finite_angles():
    angles = LEFT_ARM_IK.solve(0.2, 0.1, 0.05)
    assert set(angles.keys()) == {"left_shoulder", "left_elbow", "left_wrist"}
    assert all(math.isfinite(v) for v in angles.values())


# ------------------------------------------------------------- safety_controller
def test_safety_controller_tracking_lost_before_first_frame():
    sc = SafetyController()
    status, _ = sc.evaluate({"left_shoulder": 0.1}, confidence=1.0)
    assert status == TRACKING_LOST


def test_safety_controller_safe_after_frame_received():
    sc = SafetyController()
    sc.frame_received()
    status, angles = sc.evaluate({"left_shoulder": 0.1}, confidence=1.0)
    assert status == SAFE
    assert angles["left_shoulder"] == 0.1


def test_safety_controller_rejects_low_confidence():
    sc = SafetyController()
    sc.frame_received()
    status, _ = sc.evaluate({"left_shoulder": 0.1}, confidence=0.1)
    assert status == LOW_CONFIDENCE


def test_safety_controller_estop_hold_to_clear():
    sc = SafetyController()
    sc.frame_received()
    sc.trigger_estop()
    status, _ = sc.evaluate({}, confidence=1.0)
    assert status == EMERGENCY_STOP
    sc.update_estop_clear(True, hold_required=0.1)
    assert sc.is_estopped()
    time.sleep(0.15)
    sc.update_estop_clear(True, hold_required=0.1)
    assert not sc.is_estopped()


# ------------------------------------------------------------- motion_mapper
def test_straight_arm_reads_zero_angles():
    shoulder, hip = LM(0, 0, 0), LM(0, 0.5, 0)
    elbow, wrist = LM(0, 0.25, 0), LM(0, 0.5, 0)
    angles = arm_angles_from_pose(shoulder, elbow, wrist, hip, "left")
    assert abs(angles["left_shoulder"]) < 0.1
    assert abs(angles["left_elbow"]) < 0.1


def test_horizontal_arm_reads_90deg_shoulder():
    shoulder, hip = LM(0, 0, 0), LM(0, 0.5, 0)
    elbow, wrist = LM(0.5, 0, 0), LM(1.0, 0, 0)
    angles = arm_angles_from_pose(shoulder, elbow, wrist, hip, "left")
    assert abs(angles["left_shoulder"] - math.pi / 2) < 0.15


def test_bent_elbow_reads_significant_angle():
    shoulder, hip = LM(0, 0, 0), LM(0, 0.5, 0)
    elbow, wrist = LM(0, 0.25, 0), LM(0.25, 0.25, 0)
    angles = arm_angles_from_pose(shoulder, elbow, wrist, hip, "left")
    assert angles["left_elbow"] > 1.0


def test_hand_openness_mapping_extremes():
    assert hand_openness_to_grip(0.25) < 0.1
    assert hand_openness_to_grip(0.03) > 0.9


# ------------------------------------------------------------- mode_manager
def test_default_mode_matches_config():
    hm = HumanoidModeManager()
    assert hm.mode == HumanoidMode(C.HUMANOID_MODE_DEFAULT)


def test_estop_cannot_be_cleared_by_plain_keypress():
    hm = HumanoidModeManager()
    hm.handle_key('e')
    assert hm.mode == HumanoidMode.EMERGENCY_STOP
    result = hm.handle_key('g')
    assert result is False
    assert hm.mode == HumanoidMode.EMERGENCY_STOP


def test_mode_switching():
    hm = HumanoidModeManager()
    hm.handle_key('m')
    assert hm.mode == HumanoidMode.MIRROR
    hm.handle_key('g')
    assert hm.mode == HumanoidMode.GESTURE


# ------------------------------------------------------------- udp_sender
def test_humanoid_command_round_trip():
    cmd = HumanoidCommand.from_joint_dict(
        {"left_shoulder": 0.2, "left_elbow": 0.7, "left_wrist": 0.1},
        mode="mirror", gesture="open_palm", confidence=0.96,
    )
    d = cmd.to_dict()
    cmd2 = HumanoidCommand.from_dict(d)
    assert cmd2.left_arm.shoulder == 0.2
    assert cmd2.mode == "mirror"


def test_humanoid_udp_send_receive():
    recv = HumanoidUDPReceiver(port=15701, timeout=0.3)
    send = HumanoidUDPSender(port=15701)
    try:
        cmd = HumanoidCommand(mode="gesture", gesture="pinch", confidence=0.8,
                               left_arm=ArmCommand(0.1, 0.2, 0.3))
        send.send(cmd)
        time.sleep(0.05)
        received = recv.poll_latest()
        assert received is not None
        assert received.gesture == "pinch"
        assert received.left_arm.shoulder == 0.1
    finally:
        send.close()
        recv.close()
